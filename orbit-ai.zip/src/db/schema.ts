import { pgTable, serial, text, integer, boolean, timestamp, jsonb, index } from "drizzle-orm/pg-core";

export const users = pgTable('users', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  createdAt: text('created_at').notNull(),
  preferences: jsonb('preferences').$type<any>()
});

export const tasks = pgTable('tasks', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text('title').notNull(),
  deadline: text('deadline'),
  importance: text('importance').notNull(),
  duration: integer('duration').notNull(),
  completed: boolean('completed').notNull().default(false),
  completedAt: text('completed_at'),
  createdAt: text('created_at').notNull(),
  aiPriorityScore: integer('ai_priority_score'),
  aiRank: integer('ai_rank'),
  aiOptimalTime: text('ai_optimal_time'),
  aiReasoning: text('ai_reasoning'),
  aiCategory: text('ai_category'),
  subtasks: jsonb('subtasks').$type<any[]>(),
  isRescheduled: boolean('is_rescheduled')
});

export const habits = pgTable('habits', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text('title').notNull(),
  frequency: text('frequency').notNull(),
  createdAt: text('created_at').notNull(),
  completedDays: jsonb('completed_days').$type<string[]>(),
  streak: integer('streak').notNull().default(0),
  bestStreak: integer('best_streak').notNull().default(0)
});

export const reflections = pgTable('reflections', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  date: text('date').notNull(),
  completionRate: integer('completion_rate').notNull(),
  habitConsistency: integer('habit_consistency').notNull(),
  focusScore: integer('focus_score').notNull(),
  momentumScore: integer('momentum_score').notNull(),
  missedWork: integer('missed_work').notNull(),
  extraWork: integer('extra_work').notNull(),
  dailyReflection: text('daily_reflection').notNull(),
  performanceAnalysis: text('performance_analysis').notNull(),
  improvementSuggestions: jsonb('improvement_suggestions').$type<string[]>(),
  personalizedCoaching: text('personalized_coaching').notNull(),
  positiveReinforcement: text('positive_reinforcement').notNull(),
  futurePlanningSuggestions: jsonb('future_planning_suggestions').$type<string[]>(),
  distractionPatterns: jsonb('distraction_patterns').$type<string[]>(),
  energyPatterns: jsonb('energy_patterns').$type<string[]>(),
  weeklyTrends: text('weekly_trends').notNull()
});

export const dailyPlans = pgTable('daily_plans', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  date: text('date').notNull(), // removed primary key from date since it needs id for uniqueness across users
  events: jsonb('events').$type<any[]>(),
  insights: jsonb('insights').$type<string[]>(),
  productivityScore: integer('productivity_score').notNull(),
  productivityTrend: text('productivity_trend').notNull()
});

export const reminders = pgTable('reminders', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  taskId: text('task_id').references(() => tasks.id, { onDelete: "cascade" }),
  type: text('type'), // "overdue", "upcoming", "briefing", etc.
  sentAt: text('sent_at').notNull()
}, (table) => {
  return {
    taskIdIdx: index('reminders_task_id_idx').on(table.taskId)
  };
});

export const directives = pgTable('directives', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  directive: text('directive').notNull()
});

export const focusSessions = pgTable('focus_sessions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  taskId: text('task_id').references(() => tasks.id, { onDelete: "cascade" }),
  startTime: text('start_time').notNull(),
  endTime: text('end_time'),
  durationMinutes: integer('duration_minutes').notNull(),
  completed: boolean('completed').notNull().default(false),
  createdAt: text('created_at').notNull()
}, (table) => {
  return {
    taskIdIdx: index('focus_sessions_task_id_idx').on(table.taskId)
  };
});

export const productivityDna = pgTable('productivity_dna', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  analysisDate: text('analysis_date').notNull(),
  bestWorkHours: text('best_work_hours').notNull(),
  productiveDay: text('productive_day').notNull(),
  completionRate: integer('completion_rate').notNull(),
  focusScore: integer('focus_score').notNull(),
  habitScore: integer('habit_score').notNull(),
  procrastinationScore: integer('procrastination_score').notNull(),
  recommendations: jsonb('recommendations').$type<string[]>().notNull()
});

export const journalInsights = pgTable('journal_insights', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  journalId: text('journal_id').notNull(),
  analysis: text('analysis').notNull(),
  improvements: jsonb('improvements').$type<string[]>().notNull(),
  score: integer('score').notNull(),
  createdAt: text('created_at').notNull()
});

export const userProfileSummary = pgTable('user_profile_summary', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: "cascade" }),
  summary: jsonb('summary').$type<any>().notNull(),
  updatedAt: text('updated_at').notNull()
});


