import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface LogoutSequenceProps {
  onComplete: () => void;
}

export default function LogoutSequence({ onComplete }: LogoutSequenceProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);
  const uiRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!canvasRef.current || !flashRef.current || !uiRef.current) return;

    const canvas = canvasRef.current;
    const flashOverlay = flashRef.current;
    const uiContainer = uiRef.current;
    
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 12;
    camera.position.y = 5;
    camera.lookAt(0, 0, 0);

    function createNoiseTexture() {
        const size = 256;
        const ctxCanvas = document.createElement('canvas');
        ctxCanvas.width = size;
        ctxCanvas.height = size;
        const ctx = ctxCanvas.getContext('2d');
        if (!ctx) return new THREE.CanvasTexture(ctxCanvas);
        const imgData = ctx.createImageData(size, size);
        for (let i = 0; i < imgData.data.length; i += 4) {
            const val = Math.random() * 255;
            imgData.data[i] = val;
            imgData.data[i+1] = val;
            imgData.data[i+2] = val;
            imgData.data[i+3] = 255;
        }
        ctx.putImageData(imgData, 0, 0);
        const tex = new THREE.CanvasTexture(ctxCanvas);
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        return tex;
    }
    const noiseTex = createNoiseTexture();

    const sunGeometry = new THREE.SphereGeometry(1.2, 64, 64);
    const sunMaterial = new THREE.MeshStandardMaterial({
      color: 0xffaa00,
      emissive: 0xff4400,
      emissiveIntensity: 2,
    });
    const sun = new THREE.Mesh(sunGeometry, sunMaterial);
    scene.add(sun);

    const coreLight = new THREE.PointLight(0xffffff, 10, 100);
    scene.add(coreLight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.1);
    scene.add(ambientLight);

    const planetData = [
      { radius: 3, size: 0.25, speed: 0.8, color: 0x47d6ff, angle: 0, hasRings: true },
      { radius: 5, size: 0.45, speed: 0.5, color: 0xff8a00, angle: 2, hasRings: false },
      { radius: 7.5, size: 0.6, speed: 0.3, color: 0x88ffaa, angle: 4, hasRings: false },
      { radius: 10, size: 0.4, speed: 0.2, color: 0xf4d1ff, angle: 5.5, hasRings: false }
    ];

    const planets: any[] = [];
    planetData.forEach(data => {
      const group = new THREE.Group();
      
      const geo = new THREE.SphereGeometry(data.size, 64, 64);
      const mat = new THREE.MeshStandardMaterial({ 
        color: data.color, 
        emissive: data.color, 
        emissiveIntensity: 0.3,
        roughness: 0.4,
        metalness: 0.6,
        bumpMap: noiseTex,
        bumpScale: 0.02
      });
      const mesh = new THREE.Mesh(geo, mat);
      group.add(mesh);

      const coronaGeo = new THREE.SphereGeometry(data.size * 1.15, 32, 32);
      const coronaMat = new THREE.MeshBasicMaterial({
        color: data.color,
        transparent: true,
        opacity: 0.15,
        side: THREE.BackSide,
        blending: THREE.AdditiveBlending
      });
      const corona = new THREE.Mesh(coronaGeo, coronaMat);
      group.add(corona);

      if (data.hasRings) {
        const ringGroup = new THREE.Group();
        ringGroup.rotation.x = Math.PI / 3;
        
        const ringGeo = new THREE.TorusGeometry(data.size * 1.8, 0.02, 16, 100);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0x47d6ff,
          blending: THREE.AdditiveBlending,
          transparent: true,
          opacity: 0.8
        });
        
        const r1 = new THREE.Mesh(ringGeo, ringMat);
        const r2 = new THREE.Mesh(ringGeo, ringMat);
        r2.scale.set(1.1, 1.1, 1);
        
        ringGroup.add(r1);
        ringGroup.add(r2);
        group.add(ringGroup);
      }

      const pivot = new THREE.Group();
      scene.add(pivot);
      pivot.add(group);
      group.position.x = data.radius;
      
      planets.push({ meshGroup: group, pivot, ...data, currentRadius: data.radius, mat, corona });
    });

    const pCount = 30000;
    const positions = new Float32Array(pCount * 3);
    const velocities = new Float32Array(pCount * 3);
    const colors = new Float32Array(pCount * 3);

    for (let i = 0; i < pCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 0.1;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 0.1;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 0.1;
      
      const angle = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      const v = 0.5 + Math.random() * 1.5;
      velocities[i * 3] = Math.sin(phi) * Math.cos(angle) * v;
      velocities[i * 3 + 1] = Math.sin(phi) * Math.sin(angle) * v;
      velocities[i * 3 + 2] = Math.cos(phi) * v;

      colors[i * 3] = 1;
      colors[i * 3 + 1] = 0.5;
      colors[i * 3 + 2] = 0.2;
    }

    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMaterial = new THREE.PointsMaterial({
      size: 0.06,
      vertexColors: true,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    let state = 'STABLE';
    let stateTimer = 0;
    const clock = new THREE.Clock();
    let reqId: number;

    function animate() {
      reqId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      stateTimer += delta;

      const posAttr = particleGeometry.attributes.position as THREE.BufferAttribute;
      let shake = 0;

      switch(state) {
        case 'STABLE':
          sun.scale.setScalar(1 + Math.sin(stateTimer * 2) * 0.05);
          planets.forEach(p => {
            p.angle += p.speed * delta;
            p.meshGroup.position.x = p.currentRadius;
            p.pivot.rotation.y = p.angle;
            p.meshGroup.rotation.y += 0.01;
          });
          if (stateTimer > 2) {
            state = 'COLLAPSING';
            stateTimer = 0;
          }
          break;

        case 'COLLAPSING':
          const collapseProgress = Math.min(stateTimer / 2.5, 1);
          const sunScale = 1.2 - collapseProgress * 1.1;
          sun.scale.setScalar(sunScale);
          sunMaterial.emissiveIntensity = 2 + (collapseProgress * 150); 
          sunMaterial.color.lerp(new THREE.Color(0xffffff), 0.05);
          
          planets.forEach(p => {
            p.angle += (p.speed + collapseProgress * 5) * delta;
            p.currentRadius = THREE.MathUtils.lerp(p.radius, 0.1, collapseProgress);
            p.meshGroup.position.x = p.currentRadius;
            p.pivot.rotation.y = p.angle;
            p.meshGroup.scale.setScalar(1 - collapseProgress);
          });

          if (stateTimer > 2.5) {
            state = 'SINGULARITY';
            stateTimer = 0;
            if (flashOverlay) {
                flashOverlay.style.opacity = '1';
                setTimeout(() => { if(flashOverlay) flashOverlay.style.opacity = '0'; }, 150);
            }
            if (uiContainer) {
                uiContainer.style.opacity = '1';
            }
          }
          break;

        case 'SINGULARITY':
          sun.scale.setScalar(0.01);
          planets.forEach(p => p.meshGroup.visible = false);
          particleMaterial.opacity = 1;
          shake = 0.25; 
          if (stateTimer > 0.8) {
            state = 'SUPERNOVA';
            stateTimer = 0;
            sun.visible = false;
          }
          break;

        case 'SUPERNOVA':
          shake = Math.max(0, 0.2 - stateTimer * 0.15);
          const speedMultiplier = 20.0; 
          for (let i = 0; i < pCount; i++) {
            posAttr.array[i * 3] += velocities[i * 3] * speedMultiplier * delta;
            posAttr.array[i * 3 + 1] += velocities[i * 3 + 1] * speedMultiplier * delta;
            posAttr.array[i * 3 + 2] += velocities[i * 3 + 2] * speedMultiplier * delta;
            
            colors[i * 3] *= 0.98;
            colors[i * 3 + 1] *= 0.99;
            colors[i * 3 + 2] += 0.015;
          }
          posAttr.needsUpdate = true;
          particleGeometry.attributes.color.needsUpdate = true;
          particleMaterial.opacity *= 0.985;

          if (stateTimer > 4) {
            state = 'REBIRTH';
            stateTimer = 0;
            if (uiContainer) {
                uiContainer.style.opacity = '0';
            }
            // Add a small delay before firing onComplete to let it fade slightly
            setTimeout(() => {
                onComplete();
            }, 500);
          }
          break;

        case 'REBIRTH':
            // we won't reach this if onComplete is fired, but keep it in case
          break;
      }

      if (shake > 0) {
        camera.position.x = (Math.random() - 0.5) * shake;
        camera.position.y = 5 + (Math.random() - 0.5) * shake;
      } else {
        camera.position.x = 0;
        camera.position.y = 5;
      }

      renderer.render(scene, camera);
    }

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);
    animate();

    return () => {
      cancelAnimationFrame(reqId);
      window.removeEventListener('resize', handleResize);
      scene.clear();
      renderer.dispose();
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] w-full h-screen overflow-hidden bg-black font-sans text-white">
      {/* Flash Overlay */}
      <div 
        ref={flashRef} 
        className="fixed inset-0 bg-white opacity-0 pointer-events-none z-50 transition-opacity duration-75 ease-out" 
      />
      
      {/* 3D Canvas */}
      <canvas 
        ref={canvasRef} 
        className="fixed inset-0 w-full h-full bg-transparent" 
      />
      
      {/* Glassmorphic UI Overlay */}
      <div className="fixed inset-0 pointer-events-none flex items-center justify-center z-10">
        <div 
          ref={uiRef} 
          className="bg-white/5 backdrop-blur-md border border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.8)] p-8 rounded-xl opacity-0 transition-opacity duration-1000 flex flex-col items-center gap-4"
        >
          <div className="text-cyan-400 uppercase tracking-[0.2em] font-medium text-[12px]">System Status</div>
          <h1 className="text-white text-3xl font-bold tracking-tight">Logged Out</h1>
          <div className="h-[1px] w-full bg-white/20"></div>
          <div className="text-gray-300 text-sm uppercase tracking-widest">Session Terminated Securely</div>
        </div>
      </div>
    </div>
  );
}
