import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

interface SceneContentProps {
  step: number;
  isWarping: boolean;
  isSpeaking: boolean;
}

function SceneContent({ step, isWarping, isSpeaking }: SceneContentProps) {
  const spacecraftRef = useRef<THREE.Group>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  const ring1Ref = useRef<THREE.Mesh>(null);
  const ring2Ref = useRef<THREE.Mesh>(null);
  const baseRef = useRef<THREE.Mesh>(null);
  const lightRef = useRef<THREE.Mesh>(null);
  const starsRef = useRef<any>(null);

  // Generate star field positions and scales
  const [starsData, starSpeeds] = useMemo(() => {
    const count = 1500;
    const positions = new Float32Array(count * 3);
    const speeds = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      // Create a tunnel/cylinder distribution of stars for cinematic warp feel
      const theta = Math.random() * Math.PI * 2;
      const radius = 2 + Math.random() * 30;
      positions[i * 3] = Math.cos(theta) * radius;
      positions[i * 3 + 1] = Math.sin(theta) * radius;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 80; // random depth

      speeds[i] = 0.05 + Math.random() * 0.15;
    }
    return [positions, speeds];
  }, []);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();

    // 1. Core Pulsing and Spacecraft floating animation
    if (spacecraftRef.current) {
      // Floating motion
      spacecraftRef.current.position.y = Math.sin(time * 1.5) * 0.15;
      
      // Rotate slowly based on active step
      if (isWarping) {
        // Spin fast during warp!
        spacecraftRef.current.rotation.z += 0.08;
        spacecraftRef.current.rotation.y += 0.04;
      } else {
        // Slow majestic rotation
        spacecraftRef.current.rotation.y = time * 0.2;
        spacecraftRef.current.rotation.x = Math.sin(time * 0.5) * 0.1;
      }

      // Voice Lip-Sync waveform scale feedback
      if (isSpeaking) {
        const voicePulse = 1 + Math.sin(time * 25) * 0.08;
        spacecraftRef.current.scale.set(voicePulse, voicePulse, voicePulse);
      } else {
        // Slow idle breath pulse
        const breath = 1 + Math.sin(time * 2) * 0.02;
        spacecraftRef.current.scale.set(breath, breath, breath);
      }
    }

    // 2. Animate core and rings
    if (coreRef.current) {
      coreRef.current.rotation.x = time * 1.2;
      coreRef.current.rotation.y = time * 0.8;
    }

    if (ring1Ref.current) {
      // Breathe and rotate
      ring1Ref.current.rotation.z = -time * 0.6;
      ring1Ref.current.rotation.x = Math.sin(time) * 0.3;
      const ringPulse = 1.3 + Math.sin(time * 3) * 0.05;
      ring1Ref.current.scale.set(ringPulse, ringPulse, 0.1);
    }

    if (ring2Ref.current) {
      // Counter-rotate
      ring2Ref.current.rotation.z = time * 0.9;
      ring2Ref.current.rotation.y = Math.cos(time * 1.2) * 0.3;
      const ringPulse = 1.8 + Math.cos(time * 3) * 0.05;
      ring2Ref.current.scale.set(ringPulse, ringPulse, 0.1);
    }

    // 3. Base energy platform rotating
    if (baseRef.current) {
      baseRef.current.rotation.y = -time * 0.1;
    }

    // 4. Volumetric cylinder light pulsing
    if (lightRef.current) {
      const pulseIntensity = 0.3 + Math.sin(time * 4) * 0.1;
      // If speaking, pulse intensity increases
      const activePulse = isSpeaking ? pulseIntensity + 0.15 : pulseIntensity;
      (lightRef.current.material as THREE.Material).opacity = activePulse;
    }

    // 5. Camera positioning based on current step
    let targetCamPos = new THREE.Vector3(0, 0, 7);
    let targetLookAt = new THREE.Vector3(0, 0, 0);

    if (isWarping) {
      // Camera zooms in close as if accelerating, then goes super wide!
      targetCamPos.set(0, 0, 1.5 + Math.sin(time * 10) * 0.05); // vibrating close-up
    } else {
      switch (step) {
        case 0: // Boot Screen
          targetCamPos.set(0, 3, 12);
          targetLookAt.set(0, -1, 0);
          break;
        case 1: // Welcome Screen
          targetCamPos.set(0, 0.8, 6.5);
          targetLookAt.set(0, 0, 0);
          break;
        case 2: // Work Parameters (Clock faces)
          // Pan to side, giving space for clock overlay
          targetCamPos.set(-2, 1, 6);
          targetLookAt.set(0.5, 0, 0);
          break;
        case 3: // Focus Engine (Duration options)
          // Look from top angle focusing on core
          targetCamPos.set(2, 2.5, 5.5);
          targetLookAt.set(-0.5, -0.5, 0);
          break;
        default:
          targetCamPos.set(0, 0, 7);
      }
    }

    state.camera.position.lerp(targetCamPos, 0.05);
    
    // Smoothly update camera matrix to track lookat
    const currentLook = new THREE.Vector3(0, 0, -1).applyQuaternion(state.camera.quaternion);
    const lerpedLook = new THREE.Vector3().lerpVectors(currentLook, targetLookAt, 0.05);
    state.camera.lookAt(lerpedLook);

    // 6. Star field animation (Warp particles effect)
    if (starsRef.current) {
      const positions = starsRef.current.geometry.attributes.position.array;
      const length = positions.length / 3;

      for (let i = 0; i < length; i++) {
        const zIdx = i * 3 + 2;
        
        if (isWarping) {
          // Hyper-speed warp flight (gushing past)
          positions[zIdx] += starSpeeds[i] * 12; // accelerate massively
          // Stretch particles visually by simulating depth reset
          if (positions[zIdx] > 40) {
            positions[zIdx] = -40;
          }
        } else {
          // Slow drifting stars
          positions[zIdx] += starSpeeds[i] * 0.5;
          if (positions[zIdx] > 40) {
            positions[zIdx] = -40;
          }
        }
      }
      starsRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1.5} color="#00f3ff" />
      <pointLight position={[-10, -10, -10]} intensity={0.8} color="#9d00ff" />
      <directionalLight position={[0, 5, 5]} intensity={1} color="#ffffff" />

      {/* Starfield Particles */}
      <points ref={starsRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[starsData, 3]}
            count={starsData.length / 3}
            array={starsData}
            itemSize={3}
          />
        </bufferGeometry>
        <PointMaterial
          transparent
          color="#a5e7ff"
          size={isWarping ? 0.08 : 0.04}
          sizeAttenuation
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* Cyber Energy Base Platform */}
      <mesh ref={baseRef} position={[0, -2, 0]} rotation={[0, 0, 0]}>
        <cylinderGeometry args={[2.5, 2.8, 0.4, 32]} />
        <meshStandardMaterial 
          color="#06121a" 
          roughness={0.1} 
          metalness={0.9} 
          emissive="#005a73" 
          emissiveIntensity={0.2}
          wireframe
        />
      </mesh>

      {/* Volumetric Cylinder Light Emission */}
      <mesh ref={lightRef} position={[0, 0.5, 0]}>
        <cylinderGeometry args={[1.5, 2.5, 5, 32, 1, true]} />
        <meshBasicMaterial 
          color="#00f3ff" 
          transparent 
          opacity={0.3} 
          side={THREE.DoubleSide}
          blending={THREE.AdditiveBlending}
        />
      </mesh>

      {/* Procedural High-Fidelity 3D AI Spacecraft Avatar */}
      <group ref={spacecraftRef} position={[0, 0, 0]}>
        
        {/* Central Core Sphere - Glowing Energy Grid */}
        <mesh ref={coreRef}>
          <icosahedronGeometry args={[0.7, 2]} />
          <meshStandardMaterial 
            color="#00f3ff" 
            emissive="#00f3ff" 
            emissiveIntensity={1.5}
            roughness={0.1}
            wireframe
          />
        </mesh>

        {/* Spacecraft command hull / pyramid pointer */}
        <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <coneGeometry args={[0.5, 1.6, 4]} />
          <meshStandardMaterial 
            color="#0b1b24" 
            roughness={0.2} 
            metalness={0.8}
            emissive="#003545"
            emissiveIntensity={0.5}
          />
        </mesh>

        {/* Side thrusters / solar winglets */}
        <mesh position={[1, 0, -0.2]} rotation={[0, -Math.PI / 6, 0]}>
          <boxGeometry args={[1.2, 0.12, 0.4]} />
          <meshStandardMaterial color="#0c202a" roughness={0.3} metalness={0.9} />
        </mesh>
        <mesh position={[-1, 0, -0.2]} rotation={[0, Math.PI / 6, 0]}>
          <boxGeometry args={[1.2, 0.12, 0.4]} />
          <meshStandardMaterial color="#0c202a" roughness={0.3} metalness={0.9} />
        </mesh>

        {/* Thrust Glow */}
        <mesh position={[0, 0, -1.1]} rotation={[Math.PI / 2, 0, 0]}>
          <coneGeometry args={[0.25, 0.8, 16]} />
          <meshBasicMaterial 
            color={isWarping ? "#ff9d00" : "#00f3ff"} 
            transparent 
            opacity={isWarping ? 0.9 : 0.4} 
            blending={THREE.AdditiveBlending}
          />
        </mesh>

        {/* Inner Pulsing Orbital Ring */}
        <mesh ref={ring1Ref} rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[1.2, 1.25, 64]} />
          <meshBasicMaterial 
            color="#00f3ff" 
            side={THREE.DoubleSide} 
            transparent 
            opacity={0.8}
            blending={THREE.AdditiveBlending}
          />
        </mesh>

        {/* Outer Pulsing Orbital Ring with Nodes */}
        <mesh ref={ring2Ref} rotation={[Math.PI / 4, Math.PI / 4, 0]}>
          <ringGeometry args={[1.7, 1.76, 64]} />
          <meshBasicMaterial 
            color="#9d00ff" 
            side={THREE.DoubleSide} 
            transparent 
            opacity={0.6}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
        
        {/* Mini satellite orbit nodes */}
        <mesh position={[1.7, 0, 0]}>
          <sphereGeometry args={[0.07, 16, 16]} />
          <meshBasicMaterial color="#9d00ff" />
        </mesh>
        <mesh position={[-1.7, 0, 0]}>
          <sphereGeometry args={[0.07, 16, 16]} />
          <meshBasicMaterial color="#9d00ff" />
        </mesh>

      </group>
    </>
  );
}

interface Onboarding3DSceneProps {
  step: number;
  isWarping: boolean;
  isSpeaking: boolean;
}

export default function Onboarding3DScene({ step, isWarping, isSpeaking }: Onboarding3DSceneProps) {
  return (
    <div className="w-full h-full relative overflow-hidden bg-black">
      {/* Background Star Overlay */}
      <div className="absolute inset-0 bg-radial-gradient from-transparent via-black/80 to-black pointer-events-none z-1" />
      
      {/* Canvas */}
      <Canvas
        camera={{ position: [0, 0, 7], fov: 60 }}
        gl={{ antialias: true, alpha: false }}
        className="w-full h-full"
      >
        <color attach="background" args={['#020408']} />
        <SceneContent step={step} isWarping={isWarping} isSpeaking={isSpeaking} />
      </Canvas>
    </div>
  );
}
