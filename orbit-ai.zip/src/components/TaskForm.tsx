import React, { useState } from 'react';
import { Calendar, Clock, CircleAlert, CirclePlus } from 'lucide-react';
import { Task } from '../types';

interface TaskFormProps {
  onAddTask: (taskData: Omit<Task, 'id' | 'completed' | 'createdAt'>) => void;
  editingTask?: Task | null;
  onCancelEdit?: () => void;
  onUpdateTask?: (id: string, taskData: Omit<Task, 'id' | 'completed' | 'createdAt'>) => void;
}

export default function TaskForm({ onAddTask, editingTask, onCancelEdit, onUpdateTask }: TaskFormProps) {
  const [title, setTitle] = useState('');
  const [deadline, setDeadline] = useState(() => {
    // Default to tomorrow at 9:00 AM
    const date = new Date();
    date.setDate(date.getDate() + 1);
    date.setHours(9, 0, 0, 0);
    // Format to yyyy-MM-ddThh:mm
    return date.toISOString().slice(0, 16);
  });
  const [importance, setImportance] = useState<'low' | 'medium' | 'high'>('medium');
  const [duration, setDuration] = useState<number>(30); // default 30 mins
  const [error, setError] = useState('');

  React.useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);
      setDeadline(editingTask.deadline);
      setImportance(editingTask.importance);
      setDuration(editingTask.duration);
    } else {
      setTitle('');
      const date = new Date();
      date.setDate(date.getDate() + 1);
      date.setHours(9, 0, 0, 0);
      setDeadline(date.toISOString().slice(0, 16));
      setImportance('medium');
      setDuration(30);
    }
  }, [editingTask]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError('Task Title is required.');
      return;
    }

    if (duration <= 0) {
      setError('Duration must be greater than 0 minutes.');
      return;
    }

    const taskData = {
      title: title.trim(),
      deadline,
      importance,
      duration,
    };

    if (editingTask && onUpdateTask) {
      onUpdateTask(editingTask.id, taskData);
    } else {
      onAddTask(taskData);
      setTitle('');
    }
  };

  return (
    <div id="task-creation-card" className="bg-[#0a0a0a] border border-[#1a1a1a] p-4 rounded-none">
      <div className="flex items-center gap-2 mb-4">
        <span className="w-2.5 h-2.5 bg-blue-500 rounded-full shrink-0"></span>
        <h3 className="font-semibold text-[10px] tracking-widest uppercase text-[#e0e0e0]">
          {editingTask ? 'Update Task Details' : 'Initialize New Task'}
        </h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="flex items-center gap-2 text-[10px] text-rose-400 bg-rose-950/10 border border-rose-900/30 p-2 rounded-none font-mono">
            <CircleAlert className="w-3.5 h-3.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label htmlFor="task-title-input" className="block text-[8px] font-bold text-[#555] uppercase tracking-[0.2em] mb-1">
            Task Name / Objective
          </label>
          <input
            id="task-title-input"
            type="text"
            className="w-full bg-[#050505] border border-[#1a1a1a] focus:border-[#444] rounded-none px-2 py-2 text-[11px] text-slate-100 placeholder-[#444] outline-none transition-colors"
            placeholder="e.g. Conduct Spanner migration analysis"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="task-deadline-input" className="block text-[8px] font-bold text-[#555] uppercase tracking-[0.2em] mb-1">
              Target Deadline
            </label>
            <div className="relative">
              <Calendar className="absolute left-2.5 top-2 w-3.5 h-3.5 text-[#444]" />
              <input
                id="task-deadline-input"
                type="datetime-local"
                className="w-full bg-[#050505] border border-[#1a1a1a] focus:border-[#444] rounded-none pl-8 pr-2 py-1.5 text-[11px] text-slate-100 outline-none font-mono"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label htmlFor="task-duration-input" className="block text-[8px] font-bold text-[#555] uppercase tracking-[0.2em] mb-1">
              Est. Duration (Mins)
            </label>
            <div className="relative">
              <Clock className="absolute left-2.5 top-2 w-3.5 h-3.5 text-[#444]" />
              <input
                id="task-duration-input"
                type="number"
                min="1"
                className="w-full bg-[#050505] border border-[#1a1a1a] focus:border-[#444] rounded-none pl-8 pr-2 py-1.5 text-[11px] text-slate-100 outline-none font-mono"
                placeholder="Minutes"
                value={duration || ''}
                onChange={(e) => setDuration(parseInt(e.target.value, 10) || 0)}
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-[8px] font-bold text-[#555] uppercase tracking-[0.2em] mb-1">
            Priority Tier (Importance)
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['low', 'medium', 'high'] as const).map((lvl) => (
              <button
                key={lvl}
                type="button"
                className={`py-1.5 rounded-none text-[8px] font-bold uppercase tracking-widest border transition-all cursor-pointer ${
                  importance === lvl
                    ? lvl === 'high'
                      ? 'bg-[#1a0f12] border-rose-800 text-rose-400'
                      : lvl === 'medium'
                      ? 'bg-[#1a150f] border-amber-800 text-amber-400'
                      : 'bg-[#0f1a14] border-emerald-800 text-emerald-400'
                    : 'bg-[#050505] border-[#1a1a1a] text-[#555] hover:text-[#bbb] hover:bg-[#0a0a0a]'
                }`}
                onClick={() => setImportance(lvl)}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-2 mt-2">
          {editingTask && onCancelEdit && (
            <button
              type="button"
              onClick={onCancelEdit}
              className="w-1/3 py-2 border border-[#444] text-[#bbb] hover:text-white uppercase text-[9px] font-bold tracking-widest hover:border-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
          )}
          <button
            id="task-submit-btn"
            type="submit"
            className={`${editingTask ? 'flex-1' : 'w-full'} py-2 border border-[#e0e0e0] text-black bg-[#e0e0e0] uppercase text-[9px] font-bold tracking-widest hover:bg-transparent hover:text-white transition-colors cursor-pointer flex items-center justify-center gap-1.5`}
          >
            {editingTask ? 'Save Changes' : (
              <>
                <CirclePlus className="w-3 h-3" /> Initialize Goal
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
