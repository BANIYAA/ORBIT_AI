import React, { useState } from 'react';
import { Activity, CirclePlus, CircleAlert } from 'lucide-react';
import { Habit } from '../types';

interface HabitFormProps {
  onAddHabit: (habitData: Omit<Habit, 'id' | 'createdAt' | 'completedDays' | 'streak' | 'bestStreak'>) => void;
}

export default function HabitForm({ onAddHabit }: HabitFormProps) {
  const [title, setTitle] = useState('');
  const [frequency, setFrequency] = useState<'daily' | 'weekly'>('daily');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError('Habit Title is required.');
      return;
    }

    onAddHabit({
      title: title.trim(),
      frequency,
    });

    setTitle('');
  };

  return (
    <div id="habit-creation-card" className="bg-[#0a0a0a] border border-[#1a1a1a] p-4 rounded-none">
      <div className="flex items-center gap-2 mb-4">
        <span className="w-2.5 h-2.5 bg-green-500 rounded-full shrink-0"></span>
        <h3 className="font-semibold text-[10px] tracking-widest uppercase text-[#e0e0e0]">Register Habit Routine</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="flex items-center gap-2 text-[10px] text-rose-400 bg-rose-950/10 border border-rose-900/30 p-2 rounded-none font-mono">
            <CircleAlert className="w-3.5 h-3.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label htmlFor="habit-title-input" className="block text-[8px] font-bold text-[#555] uppercase tracking-[0.2em] mb-1">
            Habit Routine Name
          </label>
          <input
            id="habit-title-input"
            type="text"
            className="w-full bg-[#050505] border border-[#1a1a1a] focus:border-[#444] rounded-none px-2 py-2 text-[11px] text-slate-100 placeholder-[#444] outline-none transition-colors"
            placeholder="e.g. 20-min daily Deep Reading block"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div>
          <label className="block text-[8px] font-bold text-[#555] uppercase tracking-[0.2em] mb-1">
            Target Frequency
          </label>
          <div className="grid grid-cols-2 gap-2">
            {(['daily', 'weekly'] as const).map((freq) => (
              <button
                key={freq}
                type="button"
                className={`py-1.5 rounded-none text-[8px] font-bold uppercase tracking-widest border transition-all cursor-pointer ${
                  frequency === freq
                    ? 'bg-[#0f1a14] border-emerald-800 text-emerald-400'
                    : 'bg-[#050505] border-[#1a1a1a] text-[#555] hover:text-[#bbb] hover:bg-[#0a0a0a]'
                }`}
                onClick={() => setFrequency(freq)}
              >
                {freq}
              </button>
            ))}
          </div>
          <span className="text-[9px] text-[#555] block mt-1.5 lowercase italic">
            * {frequency === 'daily'
              ? 'refreshes every morning. perfect for daily rituals.'
              : 'track completion of goals across the weekly calendar cycle.'}
          </span>
        </div>

        <button
          id="habit-submit-btn"
          type="submit"
          className="w-full py-2 border border-[#e0e0e0] text-black bg-[#e0e0e0] uppercase text-[9px] font-bold tracking-widest hover:bg-transparent hover:text-white transition-colors cursor-pointer flex items-center justify-center gap-1.5"
        >
          <CirclePlus className="w-3 h-3" /> Initialize Ritual
        </button>
      </form>
    </div>
  );
}
