import React from 'react';
import { UserSettings } from '../types';
import { Settings, Volume2, Bell, Clock, Sunrise, Sunset } from 'lucide-react';

interface SettingsPanelProps {
  settings: UserSettings;
  onUpdate: (settings: UserSettings) => void;
}

export default function SettingsPanel({ settings, onUpdate }: SettingsPanelProps) {
  const toggleSetting = (key: keyof UserSettings) => {
    if (key === 'notificationsEnabled') {
      if (!settings.notificationsEnabled) {
        if ('Notification' in window) {
          Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
              onUpdate({ ...settings, notificationsEnabled: true });
            }
          });
          return;
        }
      }
    }
    
    onUpdate({
      ...settings,
      [key]: !settings[key]
    });
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl overflow-hidden shadow-2xl w-full">
      <div className="p-6 border-b border-[#222] flex items-center justify-between">
        <div>
          <h2 className="text-xl font-serif italic text-white flex items-center gap-3">
            <Settings className="w-5 h-5 text-indigo-400" />
            System Preferences
          </h2>
          <p className="text-xs text-[#666] mt-1 tracking-wider uppercase">Configure Orbit's Neural Coaching Engine</p>
        </div>
      </div>
      
      <div className="p-6 space-y-6">
        <div className="space-y-4">
          <h3 className="text-xs font-mono text-[#888] uppercase tracking-wider mb-4 border-b border-[#222] pb-2">Active Notifications</h3>
          
          <div 
            className="flex items-center justify-between group cursor-pointer py-2 -my-2"
            onClick={() => toggleSetting('voiceEnabled')}
          >
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg transition-colors ${settings.voiceEnabled ? 'bg-indigo-500/10 text-indigo-400' : 'bg-[#111] text-[#555]'}`}>
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#ddd] group-hover:text-white transition-colors">AI Voice Announcements</p>
                <p className="text-[11px] text-[#666]">Orbit will speak reminders aloud</p>
              </div>
            </div>
            <button 
              className={`w-11 h-6 shrink-0 rounded-full transition-colors relative pointer-events-none ${settings.voiceEnabled ? 'bg-indigo-500' : 'bg-[#333]'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${settings.voiceEnabled ? 'left-6' : 'left-1'}`} />
            </button>
          </div>

          <div 
            className="flex items-center justify-between group cursor-pointer py-2 -my-2"
            onClick={() => toggleSetting('notificationsEnabled')}
          >
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg transition-colors ${settings.notificationsEnabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-[#111] text-[#555]'}`}>
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#ddd] group-hover:text-white transition-colors">Browser Notifications</p>
                <p className="text-[11px] text-[#666]">System-level push alerts</p>
              </div>
            </div>
            <button 
              className={`w-11 h-6 shrink-0 rounded-full transition-colors relative pointer-events-none ${settings.notificationsEnabled ? 'bg-emerald-500' : 'bg-[#333]'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${settings.notificationsEnabled ? 'left-6' : 'left-1'}`} />
            </button>
          </div>
        </div>

        <div className="space-y-4 pt-4">
          <h3 className="text-xs font-mono text-[#888] uppercase tracking-wider mb-4 border-b border-[#222] pb-2">Daily Briefings</h3>
          
          <div 
            className="flex items-center justify-between group cursor-pointer py-2 -my-2"
            onClick={() => toggleSetting('morningBriefingEnabled')}
          >
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg transition-colors ${settings.morningBriefingEnabled ? 'bg-amber-500/10 text-amber-400' : 'bg-[#111] text-[#555]'}`}>
                <Sunrise className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#ddd] group-hover:text-white transition-colors">Morning Briefing</p>
                <p className="text-[11px] text-[#666]">Daily workload projection at start of day</p>
              </div>
            </div>
            <button 
              className={`w-11 h-6 shrink-0 rounded-full transition-colors relative pointer-events-none ${settings.morningBriefingEnabled ? 'bg-amber-500' : 'bg-[#333]'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${settings.morningBriefingEnabled ? 'left-6' : 'left-1'}`} />
            </button>
          </div>

          <div 
            className="flex items-center justify-between group cursor-pointer py-2 -my-2"
            onClick={() => toggleSetting('eveningReviewEnabled')}
          >
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg transition-colors ${settings.eveningReviewEnabled ? 'bg-purple-500/10 text-purple-400' : 'bg-[#111] text-[#555]'}`}>
                <Sunset className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#ddd] group-hover:text-white transition-colors">Evening Review</p>
                <p className="text-[11px] text-[#666]">End of day achievement analysis at 8 PM</p>
              </div>
            </div>
            <button 
              className={`w-11 h-6 shrink-0 rounded-full transition-colors relative pointer-events-none ${settings.eveningReviewEnabled ? 'bg-purple-500' : 'bg-[#333]'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${settings.eveningReviewEnabled ? 'left-6' : 'left-1'}`} />
            </button>
          </div>
        </div>

        <div className="space-y-4 pt-4">
          <h3 className="text-xs font-mono text-[#888] uppercase tracking-wider mb-4 border-b border-[#222] pb-2">Reminder Frequency</h3>
          
          <div className="flex items-center justify-between group">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#111] text-[#aaa]">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#ddd] group-hover:text-white transition-colors">Frequency Mode</p>
                <p className="text-[11px] text-[#666]">Determines how often the AI intervenes</p>
              </div>
            </div>
            <select 
              value={settings.reminderFrequency}
              onChange={(e) => onUpdate({ ...settings, reminderFrequency: e.target.value as 'low'|'medium'|'high' })}
              className="bg-[#111] border border-[#333] text-sm text-white rounded px-3 py-1.5 focus:outline-none focus:border-indigo-500"
            >
              <option value="low">Low (Crucial Only)</option>
              <option value="medium">Medium (Standard)</option>
              <option value="high">High (Strict Coach)</option>
            </select>
          </div>
        </div>
        <div className="space-y-4 pt-4">
          <h3 className="text-xs font-mono text-[#888] uppercase tracking-wider mb-4 border-b border-[#222] pb-2">Voice Configuration</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-[#ddd]">Voice Gender</label>
              <select 
                value={settings.voiceGender || 'neutral'}
                onChange={(e) => onUpdate({ ...settings, voiceGender: e.target.value as 'male'|'female'|'neutral' })}
                className="bg-[#111] border border-[#333] text-sm text-white rounded px-3 py-1.5 focus:outline-none focus:border-indigo-500"
              >
                <option value="neutral">Auto / Default</option>
                <option value="female">Female</option>
                <option value="male">Male</option>
              </select>
            </div>
            
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-[#ddd]">Speech Speed: <span className="text-indigo-400 font-mono ml-2">{(settings.voiceSpeed || 1).toFixed(1)}x</span></label>
              <input 
                type="range" 
                min="0.5" max="2.0" step="0.1"
                value={settings.voiceSpeed || 1.0}
                onChange={(e) => onUpdate({ ...settings, voiceSpeed: parseFloat(e.target.value) })}
                className="w-32 accent-indigo-500"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-[#ddd]">Speech Volume: <span className="text-indigo-400 font-mono ml-2">{Math.round((settings.voiceVolume ?? 1) * 100)}%</span></label>
              <input 
                type="range" 
                min="0.0" max="1.0" step="0.1"
                value={settings.voiceVolume ?? 1.0}
                onChange={(e) => onUpdate({ ...settings, voiceVolume: parseFloat(e.target.value) })}
                className="w-32 accent-indigo-500"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
