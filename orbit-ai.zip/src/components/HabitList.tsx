import React from 'react';
import { Flame, Star, Trash2, CalendarHeart, Check, Plus } from 'lucide-react';
import { Habit } from '../types';

interface HabitListProps {
  habits: Habit[];
  onToggleHabitDay: (habitId: string, dateStr: string) => void;
  onDeleteHabit: (id: string) => void;
}

// Format Date as simple ISO YYYY-MM-DD key without timezone errors
const toDateKey = (date: Date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

export default function HabitList({ habits, onToggleHabitDay, onDeleteHabit }: HabitListProps) {
  
  // Generate date array for the trailing 7 days
  const getLast7Days = () => {
    const arr = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      arr.push(d);
    }
    return arr;
  };

  const trailingDays = getLast7Days();
  const todayKey = toDateKey(new Date());

  const getWeekDayInitials = (date: Date) => {
    return date.toLocaleDateString([], { weekday: 'narrow' });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between border-b border-[#1a1a1a] pb-2">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-green-500 rounded-full shrink-0"></span>
          <h3 className="font-semibold text-xs text-[#e0e0e0] uppercase tracking-widest">Ritual Cycles & Habits</h3>
        </div>
        <span className="text-[10px] text-white bg-[#111] border border-[#222] px-2.5 py-0.5 rounded-none font-mono uppercase tracking-wider">
          {habits.length} Tracking
        </span>
      </div>

      {habits.length === 0 ? (
        <div className="text-center py-12 bg-[#0a0a0a] border border-[#1a1a1a] rounded-none">
          <CalendarHeart className="w-6 h-6 text-[#444] mx-auto mb-2" />
          <p className="text-[#666] text-xs uppercase tracking-widest">No regular habits found. Create a ritual loop to get started.</p>
        </div>
      ) : (
        <div className="space-y-3" id="habits-timeline-list">
          {habits.map((habit) => {
            const isTodayCompleted = Array.isArray(habit.completedDays) ? habit.completedDays.includes(todayKey) : false;

            return (
              <div
                key={habit.id}
                id={`habit-item-${habit.id}`}
                className="glass-card p-5 rounded-2xl space-y-4 border border-white/5 bg-white/[0.02] hover:border-purple-500/30 transition-all duration-300 hover:scale-[1.01] hover:shadow-[0_0_20px_rgba(168,85,247,0.15)]"
              >
                {/* Title + Stats Headers */}
                <div className="flex items-start justify-between gap-3 flex-wrap sm:flex-nowrap">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="font-semibold text-white text-base tracking-wide">{habit.title}</h4>
                      <span className="text-[10px] font-mono font-bold uppercase bg-purple-950/40 border border-purple-800/40 text-purple-400 px-2.5 py-0.5 rounded">
                        {habit.frequency}
                      </span>
                    </div>
                    <p className="text-[10px] text-white/50 uppercase tracking-wider font-mono">
                      Toggle days in the grid below to mark completed actions.
                    </p>
                  </div>

                  {/* Actions & Streaks */}
                  <div className="flex items-center gap-2.5 shrink-0 ml-auto sm:ml-0">
                    {/* Streaks Widget */}
                    <div className="flex items-center gap-2 text-white bg-white/[0.03] border border-white/5 px-3 py-1.5 rounded-xl font-mono">
                      <Flame className={`w-4 h-4 shrink-0 ${habit.streak > 0 ? 'text-orange-500 animate-pulse' : 'text-white/20'}`} />
                      <div className="text-left">
                        <span className="text-xs font-bold block leading-none">{habit.streak}d</span>
                        <span className="text-[8px] text-white/40 uppercase tracking-widest block font-sans mt-0.5">
                          BEST: {habit.bestStreak}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onDeleteHabit(habit.id)}
                      className="text-white/40 hover:text-red-400 p-2.5 rounded-xl border border-white/5 hover:border-red-500/30 bg-white/[0.01] hover:bg-red-950/10 transition-all cursor-pointer"
                      title="Erase habit tracking statistics"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* 7-Day Completion Calendars Grid */}
                <div className="space-y-2">
                  <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-white/40 block">
                    7-DAY COMPLETION HISTOLOGY
                  </span>
                  
                  <div className="grid grid-cols-7 gap-1.5 bg-white/[0.01] p-2.5 rounded-xl border border-white/5">
                    {trailingDays.map((day) => {
                      const dayKey = toDateKey(day);
                      const isCompleted = Array.isArray(habit.completedDays) ? habit.completedDays.includes(dayKey) : false;
                      const isToday = dayKey === todayKey;

                      return (
                        <button
                          key={dayKey}
                          onClick={() => onToggleHabitDay(habit.id, dayKey)}
                          className={`flex flex-col items-center justify-between p-2 min-h-[46px] rounded-lg border transition-all cursor-pointer ${
                            isCompleted
                              ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-400 hover:bg-emerald-950/30'
                              : isToday
                              ? 'bg-white/5 border-white/20 text-white hover:bg-white/10'
                              : 'bg-transparent border-white/[0.03] text-white/30 hover:text-white/70 hover:border-white/10'
                          }`}
                          title={`Toggle checking on ${day.toDateString()}`}
                        >
                          <span className="text-[8px] uppercase tracking-widest font-mono block opacity-60">
                            {getWeekDayInitials(day)}
                          </span>

                          <div className="flex items-center justify-center my-0.5">
                            {isCompleted ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            ) : (
                              <span className="text-[10px] font-mono leading-none block font-medium">
                                {day.getDate()}
                              </span>
                            )}
                          </div>

                          <span className={`text-[7px] font-mono block ${isToday ? 'text-white font-bold' : 'opacity-30'}`}>
                            {isToday ? 'TOD' : `${day.getMonth() + 1}/${day.getDate()}`}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
