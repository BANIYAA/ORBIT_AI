import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Mic, 
  Settings, 
  LogOut, 
  Sparkles, 
  ChevronDown, 
  LayoutDashboard, 
  ListTodo, 
  Flame, 
  BrainCircuit, 
  Zap, 
  Compass,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { Task, Habit } from '../types';
import { apiFetch } from '../utils/apiFetch';

interface OrbitTopBarProps {
  userName?: string;
  productivityScore?: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isFocusMode?: boolean;
  setIsFocusMode?: (focus: boolean) => void;
  onLogout: () => void;
  tasks: Task[];
  habits: Habit[];
  onCommandResult: (action: string, payload: any) => any;
}

export default function OrbitTopBar({
  userName = 'Commander',
  productivityScore = 78,
  activeTab,
  setActiveTab,
  isFocusMode = false,
  setIsFocusMode,
  onLogout,
  tasks,
  habits,
  onCommandResult,
}: OrbitTopBarProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [commandText, setCommandText] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchStatus, setSearchStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [searchFeedback, setSearchFeedback] = useState('');
  
  // Speech recognition sync states
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [isVoiceProcessing, setIsVoiceProcessing] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync with VoiceAssistant speech events
  useEffect(() => {
    const handleVoiceUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        setIsVoiceListening(!!customEvent.detail.isListening);
        setIsVoiceProcessing(!!customEvent.detail.isProcessing);
      }
    };

    window.addEventListener('orbit-voice-state-update', handleVoiceUpdate);
    return () => {
      window.removeEventListener('orbit-voice-state-update', handleVoiceUpdate);
    };
  }, []);

  // Handle outside click for profile dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Trigger search / command submission
  const handleCommandSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandText.trim()) return;

    setIsSearching(true);
    setSearchStatus('idle');
    setSearchFeedback('');

    try {
      const response = await apiFetch('/api/command', {
        method: 'POST',
        body: JSON.stringify({ 
          command: commandText, 
          context: { 
            currentTasks: tasks,
            currentHabits: habits 
          } 
        })
      });
      const data = await response.json();
      
      setSearchStatus('success');
      setSearchFeedback(data.responseMessage || 'Command executed successfully!');
      
      // Update application state
      onCommandResult(data.action, data.payload);
      setCommandText('');

      // Auto-clear success message after 4 seconds
      setTimeout(() => {
        setSearchStatus('idle');
        setSearchFeedback('');
      }, 4000);
    } catch (err) {
      setSearchStatus('error');
      setSearchFeedback('Failed to process. Please try again.');
      setTimeout(() => {
        setSearchStatus('idle');
        setSearchFeedback('');
      }, 4000);
    } finally {
      setIsSearching(false);
    }
  };

  const toggleVoiceListening = () => {
    const event = new CustomEvent('toggle-orbit-voice');
    window.dispatchEvent(event);
  };

  // Map active tab to status text
  const getActiveStatusText = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'ORBIT DASHBOARD';
      case 'tasks':
        return 'ORBIT TASKS';
      case 'habits':
        return 'ORBIT HABITS';
      case 'reflection':
        return 'ORBIT REFLECTION';
      case 'dna':
        return 'ORBIT INTEL';
      case 'settings':
        return 'ORBIT SETTINGS';
      default:
        return 'ORBIT SYSTEM';
    }
  };

  return (
    <header 
      id="orbit-top-navigation-bar"
      className="bg-[#050507]/65 border-b border-white/5 sticky top-0 z-50 backdrop-blur-xl pointer-events-auto w-full"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        
        {/* Left-Aligned Brand Core */}
        <div 
          id="brand-core-container"
          onClick={() => setActiveTab('dashboard')}
          className="flex items-center gap-3 shrink-0 cursor-pointer group select-none"
        >
          {/* 3D orbital glowing ring logo featuring outer dashed rotation and core star */}
          <div className="relative w-11 h-11 flex items-center justify-center">
            {/* Outer dashed spinning ring */}
            <div className="absolute inset-0 border border-dashed border-[#3b82f6]/40 rounded-full animate-spin-slow"></div>
            
            {/* Middle glowing orb structure */}
            <div className="absolute w-8 h-8 rounded-full border border-white/10 bg-black/40 shadow-[0_0_15px_rgba(59,130,246,0.35)] flex items-center justify-center group-hover:shadow-[0_0_20px_rgba(59,130,246,0.6)] transition-all duration-300">
              {/* Inner glowing layer */}
              <div className="absolute w-5 h-5 rounded-full border border-white/5 bg-gradient-to-tr from-[#1d4ed8]/40 to-[#a855f7]/30 animate-pulse"></div>
              
              {/* Pulsating core star */}
              <Sparkles className="w-3.5 h-3.5 text-white animate-pulse relative z-10" />
            </div>
          </div>

          <div className="flex flex-col">
            <h1 className="text-lg font-bold tracking-[0.22em] uppercase italic text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] flex items-center gap-1.5 leading-none">
              Orbit AI
            </h1>
            <span className="text-[8px] tracking-[0.25em] font-black uppercase text-[#3b82f6] mt-1 leading-none">
              COMMAND CENTER
            </span>
          </div>
        </div>

        {/* Unified Central Command Bar */}
        <div 
          id="unified-command-console"
          className="flex-1 max-w-xl hidden md:flex items-center gap-3 relative"
        >
          <form 
            onSubmit={handleCommandSubmit}
            className="w-full bg-[#0d0d11]/80 border border-white/10 hover:border-white/20 focus-within:border-[#3b82f6]/50 focus-within:shadow-[0_0_20px_rgba(59,130,246,0.15)] rounded-full pl-4 pr-1.5 py-1.5 flex items-center gap-2.5 backdrop-blur-xl transition-all duration-300"
          >
            {/* Search Input field with magnifying glass icon */}
            <Search className="w-4 h-4 text-white/40 shrink-0" />
            
            <input 
              type="text" 
              value={commandText}
              onChange={(e) => setCommandText(e.target.value)}
              placeholder="Search anything or issue AI command..." 
              className="bg-transparent text-sm text-white placeholder:text-white/30 outline-none w-full border-none py-0"
              disabled={isSearching}
            />

            {/* Dynamic Monospace Status Indicator matching active system */}
            <div className="shrink-0 flex items-center font-mono text-[9px] font-semibold text-[#3b82f6] tracking-[0.12em] bg-[#3b82f6]/10 px-2.5 py-1.5 border border-[#3b82f6]/20 rounded-full select-none max-w-[130px] sm:max-w-none truncate">
              {getActiveStatusText()}
            </div>

            {/* Glowing 3D Voice Orb Button with morphing fluid wave animation */}
            <button
              id="nav-voice-orb-button"
              type="button"
              onClick={toggleVoiceListening}
              disabled={isVoiceProcessing}
              className={`relative w-8 h-8 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 shrink-0 select-none overflow-visible ${
                isVoiceListening 
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                  : isVoiceProcessing 
                  ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                  : 'bg-white/5 text-white/70 border border-white/10 hover:border-[#3b82f6]/40 hover:text-white hover:bg-[#3b82f6]/10'
              }`}
            >
              {/* Morphing fluid wave shader-like animation when actively listening or processing */}
              {isVoiceListening && (
                <>
                  <span className="absolute inset-[-4px] rounded-full bg-emerald-500/20 animate-ping opacity-75"></span>
                  <span className="absolute inset-[-8px] rounded-full bg-emerald-500/10 animate-pulse opacity-40"></span>
                  {/* Fluid Wave Layers */}
                  <motion.div 
                    className="absolute inset-0 rounded-full bg-gradient-to-tr from-emerald-500/30 to-teal-500/20"
                    animate={{
                      borderRadius: ["42% 58% 70% 30% / 45% 45% 55% 55%", "70% 30% 52% 48% / 60% 40% 60% 40%", "42% 58% 70% 30% / 45% 45% 55% 55%"]
                    }}
                    transition={{
                      duration: 2.5,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                  <motion.div 
                    className="absolute inset-1 rounded-full bg-gradient-to-bl from-emerald-400/20 to-cyan-500/30"
                    animate={{
                      borderRadius: ["70% 30% 52% 48% / 60% 40% 60% 40%", "30% 70% 70% 30% / 50% 60% 40% 50%", "70% 30% 52% 48% / 60% 40% 60% 40%"]
                    }}
                    transition={{
                      duration: 2.0,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                </>
              )}

              {isVoiceProcessing && (
                <>
                  <span className="absolute inset-[-4px] rounded-full bg-purple-500/20 animate-ping opacity-75"></span>
                  {/* Rotating processing ring */}
                  <motion.div 
                    className="absolute inset-0 border border-t-purple-400 border-r-transparent border-b-transparent border-l-transparent rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  />
                </>
              )}

              {/* Inside Icon */}
              <Mic className="w-3.5 h-3.5 relative z-10" />
            </button>
          </form>

          {/* Toast feedback layer for command processing */}
          <AnimatePresence>
            {searchStatus !== 'idle' && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 5, scale: 0.95 }}
                className={`absolute left-4 -bottom-11 z-50 text-[10px] tracking-wide font-mono px-3.5 py-1.5 border backdrop-blur-md rounded-lg flex items-center gap-1.5 shadow-lg ${
                  searchStatus === 'success' 
                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30' 
                    : 'bg-red-950/80 text-red-300 border-red-500/30'
                }`}
              >
                {searchStatus === 'success' ? (
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                )}
                <span>{searchFeedback}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Pill-Shaped Profile Widget & Dropdown */}
        <div 
          ref={dropdownRef}
          id="profile-widget-dropdown-container"
          className="relative shrink-0"
        >
          {/* Pill-Shaped Profile Widget */}
          <button
            id="profile-pill-trigger"
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className={`flex items-center gap-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full pl-1.5 pr-3.5 py-1.5 backdrop-blur-md cursor-pointer transition-all duration-200 select-none ${
              dropdownOpen ? 'border-[#3b82f6]/50 bg-white/10' : ''
            }`}
          >
            {/* Purple-to-blue gradient avatar with standard first letter */}
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#3b82f6] to-[#a855f7] flex items-center justify-center text-xs font-extrabold shadow-[inset_0_1px_3px_rgba(255,255,255,0.4)] text-white">
              {userName.charAt(0).toUpperCase()}
            </div>

            <div className="flex flex-col items-start text-left">
              <span className="text-xs font-bold text-white/90 truncate max-w-[100px] sm:max-w-none">
                {userName}
              </span>
              {/* Green Productivity Score Indicator */}
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-[9px] font-black uppercase text-emerald-400 tracking-wider font-mono">
                  Score {productivityScore}%
                </span>
              </div>
            </div>

            <ChevronDown className={`w-3.5 h-3.5 text-white/50 transition-transform duration-300 ${dropdownOpen ? 'rotate-180 text-[#3b82f6]' : ''}`} />
          </button>

          {/* Professional dropdown menu containing Settings, Log Out, and navigation shortcuts */}
          <AnimatePresence>
            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: 15, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.96 }}
                transition={{ duration: 0.15, ease: 'easeOut' }}
                className="absolute right-0 mt-2.5 w-60 bg-[#0d0d11]/95 border border-white/10 rounded-2xl shadow-2xl backdrop-blur-2xl py-2.5 z-50 overflow-hidden font-sans"
              >
                {/* Header Information Section */}
                <div className="px-4 py-2 border-b border-white/5 mb-2">
                  <p className="text-[10px] font-mono uppercase tracking-widest text-[#3b82f6]">AUTHORIZED USER</p>
                  <p className="text-xs font-extrabold text-white truncate mt-0.5">{userName}</p>
                </div>

                {/* Navigation Shortcuts */}
                <div className="px-2 space-y-0.5">
                  <p className="text-[8px] font-mono text-[#666] tracking-widest uppercase px-2 py-1 select-none">Quick Navigation</p>
                  
                  <button
                    onClick={() => {
                      setActiveTab('dashboard');
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                      activeTab === 'dashboard' 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4 text-[#3b82f6]" />
                    <span>Dashboard Grid</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('tasks');
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                      activeTab === 'tasks' 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <ListTodo className="w-4 h-4 text-[#3b82f6]" />
                    <span>Tasks Desk ({tasks.filter(t => !t.completed).length})</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('habits');
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                      activeTab === 'habits' 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Flame className="w-4 h-4 text-orange-500" />
                    <span>Habits Vault ({habits.length})</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('reflection');
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                      activeTab === 'reflection' 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Compass className="w-4 h-4 text-emerald-500" />
                    <span>Reflection Terminal</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('dna');
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                      activeTab === 'dna' 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <BrainCircuit className="w-4 h-4 text-purple-400" />
                    <span>Productivity Intel</span>
                  </button>
                </div>

                <div className="h-[1px] bg-white/5 my-2"></div>

                {/* Focus mode and utilities */}
                <div className="px-2 space-y-0.5">
                  <button
                    onClick={() => {
                      if (setIsFocusMode) setIsFocusMode(true);
                      setDropdownOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/10 transition-all"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Trigger Focus Mode</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('settings');
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                      activeTab === 'settings' 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Settings className="w-4 h-4 text-white/40" />
                    <span>System Settings</span>
                  </button>
                </div>

                <div className="h-[1px] bg-white/5 my-2"></div>

                {/* Log Out button */}
                <div className="px-2">
                  <button
                    onClick={() => {
                      setDropdownOpen(false);
                      onLogout();
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold tracking-wide text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-all text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>System Log Out</span>
                  </button>
                </div>

              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </header>
  );
}
