import React, { useMemo, useState, useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { CameraControls } from '@react-three/drei';
import SpaceBackground from './SpaceBackground';
import Sun from './Sun';
import Planet from './Planet';
import LiveAIAvatar from './LiveAIAvatar';
import HoloDrone from './HoloDrone';
import DnaLab from './DnaLab';
import MemoryCrystal from './MemoryCrystal';
import * as THREE from 'three';
import { Task, Habit } from '../../types';

function CameraHandler({ activeNodeId, planets }: { activeNodeId: string | null, planets: any[] }) {
  const controlsRef = useRef<any>(null);

  useEffect(() => {
    if (controlsRef.current) {
      if (activeNodeId) {
        const planet = planets.find(p => p.id === activeNodeId);
        if (planet) {
          // We don't have the exact moving position easily accessible here without a context or ref map,
          // but we can estimate the position using the initial angle for simplicity, or just zoom in.
          // For a true transition, we would track the object's world position.
          // Let's just do a nice zoom in towards the radius.
          const angle = (planets.indexOf(planet) / 8) * Math.PI * 2;
          const x = Math.cos(angle) * planet.radius;
          const z = Math.sin(angle) * planet.radius;
          
          controlsRef.current.setLookAt(
            x * 1.5, 10, z * 1.5, // position
            x, 0, z, // target
            true // animate
          );
        }
      } else {
        controlsRef.current.setLookAt(0, 15, 45, 0, 0, 0, true);
      }
    }
  }, [activeNodeId, planets]);

  return (
    <CameraControls 
      ref={controlsRef} 
      minDistance={5} 
      maxDistance={100}
      dollySpeed={0.5}
      smoothTime={0.8}
    />
  );
}

export default function OrbitCanvas(props: any) {
  const { tasks, habits, dailyPlan, onNavigate, onStartFocusMode, activeTab } = props;
  const [activeNodeId, setActiveNodeId] = useState<string | null>(null);
  const [drones, setDrones] = useState<{id: number, message: string}[]>([]);

  // Simulate incoming notification
  useEffect(() => {
    const timer = setTimeout(() => {
      setDrones(prev => [...prev, { id: Date.now(), message: "System Initialized" }]);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  // Sync activeTab to activeNodeId
  useEffect(() => {
    if (activeTab === 'dashboard') {
      setActiveNodeId(null);
    } else {
      setActiveNodeId(activeTab);
    }
  }, [activeTab]);

  // Config
  const planets = useMemo(() => [
    { id: 'tasks', name: 'Tasks Station', color: '#00f5ff', icon: 'CheckSquare', radius: 14, count: (tasks || []).filter((t:any)=>!t.completed).length },
    { id: 'habits', name: 'Habits Station', color: '#bd00ff', icon: 'Target', radius: 19, count: (habits || []).filter((h:any)=>h.streak > 0).length },
    { id: 'reflection', name: 'Daily Plan', color: '#00ff87', icon: 'Calendar', radius: 24 },
    { id: 'aiCoach', name: 'AI Coach', color: '#ff007f', icon: 'Brain', radius: 29 },
    { id: 'dna', name: 'DNA Lab', color: '#06b6d4', icon: 'Dna', radius: 34 },
    { id: 'focusMode', name: 'Focus Mode', color: '#ff5a00', icon: 'Zap', radius: 39 },
  ], [tasks, habits]);

  const prodScore = dailyPlan?.productivityScore || 78;

  const handleNodeClick = (id: string) => {
    setActiveNodeId(id);
    if (id === 'focusMode' && onStartFocusMode) onStartFocusMode();
    else if (onNavigate) onNavigate(id);
  };

  const handlePointerMissed = () => {
    setActiveNodeId(null);
    if (onNavigate) onNavigate('dashboard');
  };

  return (
    <Canvas camera={{ position: [0, 15, 45], fov: 60 }} dpr={[1, 2]} onPointerMissed={handlePointerMissed}>
      <fog attach="fog" args={['#000000', 30, 100]} />
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[0, 0, 0]} intensity={2} color="#ffaa00" />
      
      <SpaceBackground />
      
      <Sun score={prodScore} />
      
      {planets.map((planet, index) => (
        <Planet 
          key={planet.id} 
          {...planet} 
          index={index}
          onClick={() => handleNodeClick(planet.id)}
          tasks={planet.id === 'tasks' ? tasks : undefined}
          habits={planet.id === 'habits' ? habits : undefined}
          isActive={activeNodeId === planet.id}
        />
      ))}

      <LiveAIAvatar isThinking={false} />

      {drones.map(drone => (
        <HoloDrone 
          key={drone.id} 
          message={drone.message} 
          onComplete={() => setDrones(prev => prev.filter(d => d.id !== drone.id))} 
        />
      ))}

      {activeNodeId === 'productivityDna' && <DnaLab />}
      {activeNodeId === 'reflection' && (
        <group position={[
          Math.cos(2 * 137.5 * Math.PI / 180) * 24,
          0,
          Math.sin(2 * 137.5 * Math.PI / 180) * 24 * 0.8
        ]}>
          <MemoryCrystal position={[-2, 1.5, 0]} text="Completed priority tasks" color="#00ff87" />
          <MemoryCrystal position={[2, -0.8, 1.5]} text="Aligned morning routines" color="#bd00ff" />
          <MemoryCrystal position={[0, 3, -1.5]} text="Maintained peak energy" color="#06b6d4" />
        </group>
      )}

      <CameraHandler activeNodeId={activeNodeId} planets={planets} />
    </Canvas>
  );
}
