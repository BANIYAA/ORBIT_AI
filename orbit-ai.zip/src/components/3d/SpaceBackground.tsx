import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export default function SpaceBackground() {
  const nebulaRef = useRef<THREE.Mesh>(null);
  const nebula2Ref = useRef<THREE.Mesh>(null);

  const farRef = useRef<THREE.Points>(null);
  const midRef = useRef<THREE.Points>(null);
  const nearRef = useRef<THREE.Points>(null);

  // Mouse offset smooth lerping references
  const farMouse = useRef({ x: 0, y: 0 });
  const midMouse = useRef({ x: 0, y: 0 });
  const nearMouse = useRef({ x: 0, y: 0 });

  // Generate 3 distinct layers of stars for true 3D parallax depth
  const farStars = useMemo(() => {
    const count = 3000;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const colorOptions = [
      new THREE.Color('#ffffff'),
      new THREE.Color('#cbd5e1'), // slate-300
      new THREE.Color('#c084fc'), // purple-400
    ];

    for (let i = 0; i < count; i++) {
      // Spherical distribution at a very distant shell (radius 100 to 140)
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 100 + Math.random() * 40;

      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);

      const color = colorOptions[Math.floor(Math.random() * colorOptions.length)];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }
    return { positions, colors };
  }, []);

  const midStars = useMemo(() => {
    const count = 1500;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const colorOptions = [
      new THREE.Color('#38bdf8'), // sky-400
      new THREE.Color('#a855f7'), // purple-500
      new THREE.Color('#e0f2fe'), // sky-100
    ];

    for (let i = 0; i < count; i++) {
      // Mid distance shell (radius 50 to 90)
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 50 + Math.random() * 40;

      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);

      const color = colorOptions[Math.floor(Math.random() * colorOptions.length)];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }
    return { positions, colors };
  }, []);

  const nearStars = useMemo(() => {
    const count = 500;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const colorOptions = [
      new THREE.Color('#22d3ee'), // cyan-400
      new THREE.Color('#fbbf24'), // amber-400
      new THREE.Color('#34d399'), // emerald-400
    ];

    for (let i = 0; i < count; i++) {
      // Near distance shell (radius 15 to 45)
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 15 + Math.random() * 30;

      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);

      const color = colorOptions[Math.floor(Math.random() * colorOptions.length)];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }
    return { positions, colors };
  }, []);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();

    // 1. Nebula standard majestic rotation
    if (nebulaRef.current) {
      nebulaRef.current.rotation.y = time * 0.015;
      nebulaRef.current.rotation.z = time * 0.008;
    }
    if (nebula2Ref.current) {
      nebula2Ref.current.rotation.y = time * -0.012;
      nebula2Ref.current.rotation.x = time * 0.006;
    }

    // 2. Smoothly interpolate pointer offsets for mouse parallax
    const targetFarX = -state.pointer.x * 0.8;
    const targetFarY = -state.pointer.y * 0.8;
    farMouse.current.x += (targetFarX - farMouse.current.x) * 0.05;
    farMouse.current.y += (targetFarY - farMouse.current.y) * 0.05;

    const targetMidX = -state.pointer.x * 2.5;
    const targetMidY = -state.pointer.y * 2.5;
    midMouse.current.x += (targetMidX - midMouse.current.x) * 0.05;
    midMouse.current.y += (targetMidY - midMouse.current.y) * 0.05;

    const targetNearX = -state.pointer.x * 5.0;
    const targetNearY = -state.pointer.y * 5.0;
    nearMouse.current.x += (targetNearX - nearMouse.current.x) * 0.05;
    nearMouse.current.y += (targetNearY - nearMouse.current.y) * 0.05;

    // 3. Multi-layer camera tracking to simulate optical lens depth / stellar distance scale
    // Far stars follow the camera closely (95%), so they have negligible perspective parallax
    if (farRef.current) {
      farRef.current.position.x = state.camera.position.x * 0.95 + farMouse.current.x;
      farRef.current.position.y = state.camera.position.y * 0.95 + farMouse.current.y;
      farRef.current.position.z = state.camera.position.z * 0.95;
      // Faint slow rotation
      farRef.current.rotation.y = time * 0.002;
    }

    // Mid stars follow at 75% tracking
    if (midRef.current) {
      midRef.current.position.x = state.camera.position.x * 0.75 + midMouse.current.x;
      midRef.current.position.y = state.camera.position.y * 0.75 + midMouse.current.y;
      midRef.current.position.z = state.camera.position.z * 0.75;
      midRef.current.rotation.y = -time * 0.004;
    }

    // Near stars follow at 30% tracking, meaning they whip past when camera shifts
    if (nearRef.current) {
      nearRef.current.position.x = state.camera.position.x * 0.30 + nearMouse.current.x;
      nearRef.current.position.y = state.camera.position.y * 0.30 + nearMouse.current.y;
      nearRef.current.position.z = state.camera.position.z * 0.30;
      nearRef.current.rotation.y = time * 0.008;
    }
  });

  return (
    <group>
      {/* 1. Far Star-Field Layer */}
      <points ref={farRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[farStars.positions, 3]}
            count={farStars.positions.length / 3}
            array={farStars.positions}
            itemSize={3}
          />
          <bufferAttribute
            attach="attributes-color"
            args={[farStars.colors, 3]}
            count={farStars.colors.length / 3}
            array={farStars.colors}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.06}
          vertexColors
          transparent
          opacity={0.4}
          sizeAttenuation
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* 2. Mid Star-Field Layer */}
      <points ref={midRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[midStars.positions, 3]}
            count={midStars.positions.length / 3}
            array={midStars.positions}
            itemSize={3}
          />
          <bufferAttribute
            attach="attributes-color"
            args={[midStars.colors, 3]}
            count={midStars.colors.length / 3}
            array={midStars.colors}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.12}
          vertexColors
          transparent
          opacity={0.6}
          sizeAttenuation
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* 3. Near Star-Field Layer */}
      <points ref={nearRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[nearStars.positions, 3]}
            count={nearStars.positions.length / 3}
            array={nearStars.positions}
            itemSize={3}
          />
          <bufferAttribute
            attach="attributes-color"
            args={[nearStars.colors, 3]}
            count={nearStars.colors.length / 3}
            array={nearStars.colors}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.25}
          vertexColors
          transparent
          opacity={0.85}
          sizeAttenuation
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* Nebula Layer 1 */}
      <mesh ref={nebulaRef} scale={100}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial 
          color="#3b82f6" 
          transparent 
          opacity={0.03} 
          side={THREE.BackSide}
          blending={THREE.AdditiveBlending}
        />
      </mesh>

      {/* Nebula Layer 2 */}
      <mesh ref={nebula2Ref} scale={90}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial 
          color="#a855f7" 
          transparent 
          opacity={0.02} 
          side={THREE.BackSide}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </group>
  );
}

