import React, { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars, Text, Float, Billboard, Sphere, Trail, MeshDistortMaterial, Html } from '@react-three/drei';
import * as THREE from 'three';
import { Task, Habit } from '../../types';

interface OrbitCommandHubProps {
  tasks: Task[];
  habits: Habit[];
  activeTab: string;
  onTaskComplete: (id: string) => void;
  onNavigate: React.Dispatch<React.SetStateAction<"tasks" | "habits" | "settings" | "dashboard" | "reflection" | "dna">>;
}

export default function OrbitCommandHub({ tasks, habits, activeTab, onTaskComplete, onNavigate }: OrbitCommandHubProps) {
  return (
    <div className="w-full h-[800px] max-h-screen bg-black relative rounded-2xl overflow-hidden border border-[#222]">
      <Canvas camera={{ position: [0, 5, 20], fov: 60 }}>
        <ambientLight intensity={0.2} />
        <pointLight position={[10, 10, 10]} intensity={1.5} color="#4f46e5" />
        <pointLight position={[-10, -10, -10]} intensity={1} color="#e11d48" />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        
        <SceneController activeTab={activeTab} tasks={tasks} habits={habits} onTaskComplete={onTaskComplete} onNavigate={onNavigate} />
        
        <OrbitControls 
          enablePan={false} 
          maxDistance={50} 
          minDistance={5} 
          makeDefault
        />
      </Canvas>
      <div className="absolute top-4 left-4 z-10 pointer-events-none text-white/50 text-[10px] font-mono tracking-widest uppercase">
        Spatial Navigation Active • Drag to Rotate • Scroll to Zoom
      </div>
    </div>
  );
}

function SceneController({ activeTab, tasks, habits, onTaskComplete, onNavigate }: any) {
  // Move camera based on active tab
  useFrame((state) => {
    const targetPos = new THREE.Vector3(0, 5, 20);
    const lookAtPos = new THREE.Vector3(0, 0, 0);

    if (activeTab === 'dashboard') {
      targetPos.set(0, 8, 25);
    } else if (activeTab === 'tasks') {
      targetPos.set(-15, 5, 10);
      lookAtPos.set(-15, 0, 0);
    } else if (activeTab === 'habits') {
      targetPos.set(15, 5, 10);
      lookAtPos.set(15, 0, 0);
    } else if (activeTab === 'dna') {
      targetPos.set(0, 15, 0);
      lookAtPos.set(0, 0, 0);
    } else if (activeTab === 'reflection') {
      targetPos.set(0, 0, -20);
      lookAtPos.set(0, 0, -30);
    }

    state.camera.position.lerp(targetPos, 0.05);
    state.camera.lookAt(lookAtPos);
  });

  return (
    <group>
      {/* Central Hub (Dashboard) */}
      <ProductivityCore score={85} />
      <SolarSystemRegion tasks={tasks} onTaskComplete={onTaskComplete} onNavigate={onNavigate} />

      {/* Task Sector (-15, 0, 0) */}
      <group position={[-15, 0, 0]}>
        <TaskSector tasks={tasks} onTaskComplete={onTaskComplete} />
      </group>

      {/* Habit Galaxy (15, 0, 0) */}
      <group position={[15, 0, 0]}>
        <HabitGalaxy habits={habits} />
      </group>

      {/* DNA Lab (0, 10, 0) */}
      <group position={[0, 10, 0]}>
        <DnaLab />
      </group>

      {/* Reflection Vault (0, 0, -30) */}
      <group position={[0, 0, -30]}>
        <ReflectionVault />
      </group>
    </group>
  );
}

function ProductivityCore({ score }: { score: number }) {
  const coreRef = useRef<THREE.Mesh>(null);
  
  // Color based on score
  let color = "#ef4444"; // Red
  if (score >= 20) color = "#f97316"; // Orange
  if (score >= 40) color = "#eab308"; // Yellow
  if (score >= 60) color = "#3b82f6"; // Blue
  if (score >= 80) color = "#eab308"; // Golden

  useFrame(({ clock }) => {
    if (coreRef.current) {
      coreRef.current.rotation.y = clock.getElapsedTime() * 0.5;
      coreRef.current.rotation.x = Math.sin(clock.getElapsedTime() * 0.5) * 0.2;
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
      <mesh ref={coreRef}>
        <sphereGeometry args={[2, 64, 64]} />
        <MeshDistortMaterial 
          color={color}
          emissive={color}
          emissiveIntensity={2}
          distort={0.3} 
          speed={2} 
          roughness={0.2}
          metalness={0.8}
        />
      </mesh>
      <Billboard position={[0, 3.5, 0]}>
        <Text fontSize={0.8} color="white" font="/Inter-Bold.woff" anchorX="center" anchorY="middle">
          {score}%
        </Text>
        <Text position={[0, -0.6, 0]} fontSize={0.3} color="#aaaaaa" font="/Inter-Regular.woff" anchorX="center" anchorY="middle" letterSpacing={0.2}>
          PRODUCTIVITY CORE
        </Text>
      </Billboard>
    </Float>
  );
}

function SolarSystemRegion({ tasks, onTaskComplete, onNavigate }: any) {
  const activeTasks = tasks.filter((t: Task) => !t.completed);
  
  return (
    <group>
      {activeTasks.slice(0, 6).map((task: Task, idx: number) => {
        const radius = 5 + idx * 3;
        const speed = 0.2 - idx * 0.02;
        return (
          <OrbitingObject 
            key={task.id} 
            radius={radius} 
            speed={speed} 
            task={task} 
            onTaskComplete={onTaskComplete}
            onClick={() => onNavigate('tasks')}
          />
        );
      })}
    </group>
  );
}

function OrbitingObject({ radius, speed, task, onTaskComplete, onClick }: any) {
  const groupRef = useRef<THREE.Group>(null);
  const offset = useMemo(() => Math.random() * Math.PI * 2, []);

  useFrame(({ clock }) => {
    if (groupRef.current) {
      const t = clock.getElapsedTime() * speed + offset;
      groupRef.current.position.x = Math.cos(t) * radius;
      groupRef.current.position.z = Math.sin(t) * radius;
    }
  });

  const isOverdue = task.deadline && new Date(task.deadline) < new Date();
  const color = isOverdue ? "#ef4444" : "#818cf8";

  return (
    <group>
      {/* Orbit ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[radius - 0.02, radius + 0.02, 64]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.05} side={THREE.DoubleSide} />
      </mesh>

      <group ref={groupRef}>
        <Trail width={1} length={8} color={new THREE.Color(color)} attenuation={(t) => t * t}>
          <mesh onClick={onClick} onPointerOver={() => document.body.style.cursor='pointer'} onPointerOut={() => document.body.style.cursor='auto'}>
            <sphereGeometry args={[0.5, 32, 32]} />
            <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} roughness={0.2} metalness={0.8} />
          </mesh>
        </Trail>
        <Html distanceFactor={15} position={[0, 1, 0]} center>
          <div className="px-2 py-1 bg-black/80 backdrop-blur-md text-white text-[10px] whitespace-nowrap rounded border border-white/10 opacity-80 hover:opacity-100 transition-opacity font-mono pointer-events-none">
            {task.title.substring(0, 20)}
          </div>
        </Html>
      </group>
    </group>
  );
}

function TaskSector({ tasks }: any) {
  const activeTasks = tasks.filter((t: Task) => !t.completed);
  return (
    <group>
      <Billboard position={[0, 6, 0]}>
        <Text fontSize={1.5} color="white" anchorX="center" anchorY="middle">TASK SECTOR</Text>
      </Billboard>
      {activeTasks.map((task: Task, i: number) => {
        const x = (i % 3) * 3 - 3;
        const y = Math.floor(i / 3) * -3 + 3;
        return (
          <Float key={task.id} position={[x, y, 0]} speed={2} floatIntensity={0.5}>
            <mesh>
              <boxGeometry args={[2, 1, 0.2]} />
              <meshStandardMaterial color="#312e81" roughness={0.1} metalness={0.8} />
            </mesh>
            <Text position={[0, 0, 0.15]} fontSize={0.2} color="white" maxWidth={1.8} anchorX="center" anchorY="middle">
              {task.title}
            </Text>
          </Float>
        );
      })}
    </group>
  );
}

function HabitGalaxy({ habits }: any) {
  return (
    <group>
      <Billboard position={[0, 6, 0]}>
        <Text fontSize={1.5} color="white" anchorX="center" anchorY="middle">HABIT GALAXY</Text>
      </Billboard>
      {habits.map((habit: Habit, i: number) => {
        const radius = 3 + Math.random() * 5;
        const angle = (i / habits.length) * Math.PI * 2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        const y = (Math.random() - 0.5) * 4;
        const intensity = Math.min(1 + habit.streak * 0.2, 5);
        return (
          <Float key={habit.id} position={[x, y, z]} speed={1}>
            <mesh>
              <sphereGeometry args={[0.3 + habit.streak * 0.05, 16, 16]} />
              <meshStandardMaterial color="#34d399" emissive="#10b981" emissiveIntensity={intensity} />
            </mesh>
            <Html distanceFactor={15} position={[0, -0.8, 0]} center>
              <div className="text-emerald-400 text-[10px] font-mono bg-black/50 px-1 rounded backdrop-blur-sm pointer-events-none">
                {habit.title} ({habit.streak}🔥)
              </div>
            </Html>
          </Float>
        );
      })}
    </group>
  );
}

function DnaLab() {
  const points = useMemo(() => {
    const pts = [];
    for (let i = 0; i < 50; i++) {
      const t = i * 0.2;
      pts.push(
        new THREE.Vector3(Math.cos(t) * 2, i * 0.2 - 5, Math.sin(t) * 2),
        new THREE.Vector3(Math.cos(t + Math.PI) * 2, i * 0.2 - 5, Math.sin(t + Math.PI) * 2)
      );
    }
    return pts;
  }, []);

  return (
    <group>
      <Billboard position={[0, 6, 0]}>
        <Text fontSize={1.5} color="white" anchorX="center" anchorY="middle">PRODUCTIVITY DNA</Text>
      </Billboard>
      <group rotation={[0, 0, 0]}>
        {points.map((v, i) => (
          <mesh key={i} position={v}>
            <sphereGeometry args={[0.15, 16, 16]} />
            <meshStandardMaterial color={i % 2 === 0 ? "#818cf8" : "#c084fc"} emissive={i % 2 === 0 ? "#4f46e5" : "#9333ea"} emissiveIntensity={2} />
          </mesh>
        ))}
        {/* Strands connecting them */}
        {Array.from({ length: 50 }).map((_, i) => (
          <mesh key={'strand'+i} position={[0, i * 0.2 - 5, 0]} rotation={[0, -i * 0.2, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 4, 8]} />
            <meshStandardMaterial color="#ffffff" transparent opacity={0.2} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

function ReflectionVault() {
  return (
    <group>
      <Billboard position={[0, 6, 0]}>
        <Text fontSize={1.5} color="white" anchorX="center" anchorY="middle">JOURNAL VAULT</Text>
      </Billboard>
      {Array.from({ length: 8 }).map((_, i) => (
        <Float key={i} position={[(Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 5]} speed={0.5} rotationIntensity={1}>
          <mesh>
            <octahedronGeometry args={[0.8, 0]} />
            <meshPhysicalMaterial 
              color="#d8b4fe" 
              transmission={0.9} 
              opacity={1} 
              metalness={0} 
              roughness={0} 
              ior={1.5} 
              thickness={0.5} 
            />
          </mesh>
        </Float>
      ))}
    </group>
  );
}
