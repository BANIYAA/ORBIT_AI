import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, PointMaterial, Points } from '@react-three/drei';
import * as THREE from 'three';

const plasmaVertexShader = `
uniform float time;
uniform float pulse;
varying vec2 vUv;
varying vec3 vPosition;
varying vec3 vNormal;

// Simplex 3D Noise 
vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}

float snoise(vec3 v){ 
  const vec2  C = vec2(1.0/6.0, 1.0/3.0) ;
  const vec4  D = vec4(0.0, 0.5, 1.0, 2.0);

  vec3 i  = floor(v + dot(v, C.yyy) );
  vec3 x0 = v - i + dot(i, C.xxx) ;

  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min( g.xyz, l.zxy );
  vec3 i2 = max( g.xyz, l.zxy );

  vec3 x1 = x0 - i1 + 1.0 * C.xxx;
  vec3 x2 = x0 - i2 + 2.0 * C.xxx;
  vec3 x3 = x0 - 1.0 + 3.0 * C.xxx;

  i = mod(i, 289.0 ); 
  vec4 p = permute( permute( permute( 
             i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0 )) 
           + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));

  float n_ = 1.0/7.0;
  vec3  ns = n_ * D.wyz - D.xzx;

  vec4 j = p - 49.0 * floor(p * ns.z *ns.z);

  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_ );

  vec4 x = x_ *ns.x + ns.yyyy;
  vec4 y = y_ *ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);

  vec4 b0 = vec4( x.xy, y.xy );
  vec4 b1 = vec4( x.zw, y.zw );

  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));

  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy ;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww ;

  vec3 p0 = vec3(a0.xy,h.x);
  vec3 p1 = vec3(a0.zw,h.y);
  vec3 p2 = vec3(a1.xy,h.z);
  vec3 p3 = vec3(a1.zw,h.w);

  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
  p0 *= norm.x;
  p1 *= norm.y;
  p2 *= norm.z;
  p3 *= norm.w;

  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot( m*m, vec4( dot(p0,x0), dot(p1,x1), 
                                dot(p2,x2), dot(p3,x3) ) );
}

void main() {
  vUv = uv;
  vNormal = normalize(normalMatrix * normal);
  
  float noise = snoise(position * 1.5 + time * 0.5) * 0.2;
  vec3 newPosition = position + normal * noise * pulse;
  
  vPosition = (modelMatrix * vec4(newPosition, 1.0)).xyz;
  gl_Position = projectionMatrix * viewMatrix * vec4(vPosition, 1.0);
}
`;

const plasmaFragmentShader = `
uniform float time;
uniform vec3 color;
uniform float intensity;
varying vec2 vUv;
varying vec3 vPosition;
varying vec3 vNormal;

void main() {
  vec3 viewDirection = normalize(cameraPosition - vPosition);
  float fresnel = dot(viewDirection, vNormal);
  fresnel = clamp(1.0 - fresnel, 0.0, 1.0);
  fresnel = pow(fresnel, 1.5);
  
  // Create a turbulent plasma look combining fresnel and base color
  vec3 finalColor = mix(color * 0.5, color * 2.0, fresnel) * intensity;
  gl_FragColor = vec4(finalColor, 1.0);
}
`;

const haloVertexShader = `
varying vec3 vNormal;
varying vec3 vPosition;
void main() {
  vNormal = normalize(normalMatrix * normal);
  vPosition = (modelMatrix * vec4(position, 1.0)).xyz;
  gl_Position = projectionMatrix * viewMatrix * vec4(vPosition, 1.0);
}
`;

const haloFragmentShader = `
uniform vec3 color;
uniform float intensity;
varying vec3 vNormal;
varying vec3 vPosition;

void main() {
  vec3 viewDirection = normalize(cameraPosition - vPosition);
  float fresnel = dot(viewDirection, vNormal);
  fresnel = clamp(1.0 - fresnel, 0.0, 1.0);
  // Soft outer glow
  float alpha = pow(fresnel, 3.0) * intensity;
  
  gl_FragColor = vec4(color, alpha);
}
`;

function SolarParticles({ color, scale }: { color: string, scale: number }) {
  const count = 1000;
  const points = useRef<THREE.Points>(null);
  
  const positions = useMemo(() => {
    const p = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 4.5 * scale + Math.random() * 2 * scale;
      const theta = 2 * Math.PI * Math.random();
      const phi = Math.acos(2 * Math.random() - 1);
      p[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      p[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      p[i * 3 + 2] = r * Math.cos(phi);
    }
    return p;
  }, [scale]);

  useFrame((state) => {
    if (points.current) {
      points.current.rotation.y = state.clock.elapsedTime * 0.1;
      points.current.rotation.z = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <Points ref={points} positions={positions}>
      <PointMaterial transparent color={color} size={0.1} sizeAttenuation={true} depthWrite={false} blending={THREE.AdditiveBlending} opacity={0.6} />
    </Points>
  );
}

export default function Sun({ score }: { score: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const coronaRef = useRef<THREE.Mesh>(null);
  
  // Color Mapping
  let color = "#ef4444"; // Dark Red
  if (score >= 20) color = "#f97316"; // Orange
  if (score >= 40) color = "#eab308"; // Yellow
  if (score >= 60) color = "#3b82f6"; // Blue
  if (score >= 80) color = "#fbbf24"; // Gold

  const baseScale = 0.8 + (score / 100) * 0.4; // 0.8 to 1.2

  const plasmaUniforms = useMemo(() => ({
    time: { value: 0 },
    pulse: { value: 1 },
    color: { value: new THREE.Color(color) },
    intensity: { value: 2.0 }
  }), [color]);

  const haloUniforms = useMemo(() => ({
    color: { value: new THREE.Color(color) },
    intensity: { value: 0.8 + (score / 100) * 0.4 }
  }), [color, score]);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.2;
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
      
      const pulseSpeed = 1 + (score / 100);
      const pulseAmp = 0.02 + (score / 100) * 0.03;
      const pulseValue = 1 + Math.sin(state.clock.elapsedTime * pulseSpeed) * pulseAmp;
      
      const scale = baseScale * pulseValue;
      meshRef.current.scale.set(scale, scale, scale);

      // Update shader uniforms
      const material = meshRef.current.material as THREE.ShaderMaterial;
      if (material && material.uniforms) {
        material.uniforms.time.value = state.clock.elapsedTime;
        material.uniforms.pulse.value = pulseValue;
        material.uniforms.intensity.value = 1.0 + (score / 100) * 1.5;
        material.uniforms.color.value.set(color);
      }
    }

    if (coronaRef.current) {
      coronaRef.current.rotation.y = state.clock.elapsedTime * -0.1;
      coronaRef.current.rotation.z = state.clock.elapsedTime * 0.05;
      
      const pulseSpeed = 1 + (score / 100);
      const scale = baseScale * 1.2 * (1 + Math.sin(state.clock.elapsedTime * pulseSpeed + 1) * 0.05);
      coronaRef.current.scale.set(scale, scale, scale);
      
      const material = coronaRef.current.material as THREE.ShaderMaterial;
      if (material && material.uniforms) {
        material.uniforms.color.value.set(color);
        material.uniforms.intensity.value = 0.5 + (score / 100) * 1.0;
      }
    }
  });

  const getStatusText = (s: number) => {
    if (s >= 80) return "Peak Resonance";
    if (s >= 60) return "Steady Fusion";
    if (s >= 40) return "Stable Orbit";
    if (s >= 20) return "Friction Alert";
    return "Dormant Core";
  };

  return (
    <group>
      {/* Core Plasma */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[4, 128, 128]} />
        <shaderMaterial 
          vertexShader={plasmaVertexShader}
          fragmentShader={plasmaFragmentShader}
          uniforms={plasmaUniforms}
          transparent={true}
        />
      </mesh>
 
      {/* Corona / Halo */}
      <mesh ref={coronaRef}>
        <sphereGeometry args={[4.4, 64, 64]} />
        <shaderMaterial 
          vertexShader={haloVertexShader}
          fragmentShader={haloFragmentShader}
          uniforms={haloUniforms}
          transparent={true}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
          side={THREE.BackSide}
        />
      </mesh>
 
      <SolarParticles color={color} scale={baseScale} />
      
      <Html center position={[0, 0, 0]} distanceFactor={30} className="pointer-events-none z-50">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="text-4xl font-black text-black drop-shadow-[0_0_8px_rgba(255,255,255,0.95)]">
            {score}%
          </div>
          <div className="text-[8px] font-bold uppercase tracking-[0.2em] text-black/90 whitespace-nowrap mt-0.5 drop-shadow-[0_0_5px_rgba(255,255,255,0.95)]">
            {getStatusText(score)}
          </div>
        </div>
      </Html>
    </group>
  );
}
