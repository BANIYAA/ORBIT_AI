import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Clock, 
  MessageSquare, 
  Plus, 
  Zap, 
  Mic, 
  X, 
  RefreshCw, 
  Sparkles, 
  CheckCircle2, 
  Calendar, 
  Flame, 
  Trophy, 
  HelpCircle, 
  Send, 
  Check, 
  Loader2,
  Trash2,
  AlertCircle,
  Eye,
  Settings
} from 'lucide-react';
import { Task, Habit, DailyPlanResponse, ReflectionData } from '../../../types';
import { apiFetch } from '../../../utils/apiFetch';

interface RightSidebarProps {
  tasks: Task[];
  habits: Habit[];
  dailyPlan: DailyPlanResponse | null;
  reflections?: ReflectionData[];
  onNavigate: (tab: string) => void;
  onTaskComplete?: (id: string) => void;
  onStartFocusMode?: () => void;
  onCommandResult?: (action: string, payload: any) => any;
  userName?: string;
  productivityScore?: number;
  isOpen?: boolean;
  onClose?: () => void;
}

export default function RightSidebar({
  tasks = [],
  habits = [],
  dailyPlan = null,
  onNavigate,
  onTaskComplete,
  onStartFocusMode,
  onCommandResult,
  userName = 'Commander',
  productivityScore = 78,
  isOpen = false,
  onClose
}: RightSidebarProps) {
  // Modal control states
  const [showRemindersModal, setShowRemindersModal] = useState(false);
  const [showCoachModal, setShowCoachModal] = useState(false);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [showAddHabitModal, setShowAddHabitModal] = useState(false);

  // AI Coach states
  const [coachMsg, setCoachMsg] = useState<{ motivation: string; recommendation: string; observation: string } | null>(null);
  const [coachLoading, setCoachLoading] = useState(false);
  const [coachError, setCoachError] = useState(false);

  // Speech integration states
  const [isVoiceListening, setIsVoiceListening] = useState(false);

  // Forms states
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newTaskDuration, setNewTaskDuration] = useState(30);
  const [newHabitTitle, setNewHabitTitle] = useState('');
  const [newHabitFrequency, setNewHabitFrequency] = useState<'daily' | 'weekly'>('daily');

  // Success notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync with VoiceAssistant speech events
  useEffect(() => {
    const handleVoiceUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        setIsVoiceListening(!!customEvent.detail.isListening);
      }
    };

    window.addEventListener('orbit-voice-state-update', handleVoiceUpdate);
    return () => {
      window.removeEventListener('orbit-voice-state-update', handleVoiceUpdate);
    };
  }, []);

  // Fetch coach advice from API
  const fetchCoachMsg = async (forceRefresh = false) => {
    setCoachLoading(true);
    setCoachError(false);
    try {
      const res = await apiFetch(`/api/coach${forceRefresh ? '?refresh=true' : ''}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks, habits })
      });
      if (res.ok) {
        const data = await res.json();
        setCoachMsg(data);
      } else {
        setCoachError(true);
      }
    } catch (e) {
      console.error("Failed to fetch coach message in sidebar:", e);
      setCoachError(true);
    } finally {
      setCoachLoading(false);
    }
  };

  useEffect(() => {
    fetchCoachMsg();
  }, [tasks.length, habits.length]);

  // Helper: show transient toast feedback
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Quick Action: Voice Command toggler
  const toggleVoiceListening = () => {
    const event = new CustomEvent('toggle-orbit-voice');
    window.dispatchEvent(event);
  };

  // Task submit handler
  const handleAddTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    if (onCommandResult) {
      const tomorrow = new Date();
      tomorrow.setHours(tomorrow.getHours() + 2);
      const formattedDeadline = tomorrow.toISOString().slice(0, 16);

      const res = onCommandResult('ADD_TASK', {
        title: newTaskTitle,
        priority: newTaskPriority,
        duration: newTaskDuration,
        deadline: formattedDeadline
      });

      if (res?.success) {
        showToast(`Task "${newTaskTitle}" created!`);
        setNewTaskTitle('');
        setNewTaskPriority('medium');
        setNewTaskDuration(30);
        setShowAddTaskModal(false);
      }
    }
  };

  // Habit submit handler
  const handleAddHabitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitTitle.trim()) return;

    if (onCommandResult) {
      const res = onCommandResult('ADD_HABIT', {
        title: newHabitTitle,
        frequency: newHabitFrequency
      });

      if (res?.success) {
        showToast(`Habit "${newHabitTitle}" added!`);
        setNewHabitTitle('');
        setNewHabitFrequency('daily');
        setShowAddHabitModal(false);
      }
    }
  };

  // Toggle task completion
  const handleToggleTask = (taskId: string, title: string) => {
    if (onTaskComplete) {
      onTaskComplete(taskId);
      showToast(`Toggled completion of "${title}"`);
    } else if (onCommandResult) {
      onCommandResult('COMPLETE_TASK', { id: taskId });
      showToast(`Toggled completion of "${title}"`);
    }
  };

  // Filter and process upcoming reminders dynamically
  const upcomingReminders = useMemo(() => {
    const list: Array<{ id: string; title: string; time: string; type: 'Task' | 'Habit' | 'Break' | 'System'; color: string; completed?: boolean }> = [];
    
    // 1. Load active events from dailyPlan
    if (dailyPlan?.events && dailyPlan.events.length > 0) {
      dailyPlan.events.forEach((ev, idx) => {
        const formatTime = (hhmm: string) => {
          try {
            const [h, m] = hhmm.split(':').map(Number);
            const ampm = h >= 12 ? 'PM' : 'AM';
            const displayH = h % 12 === 0 ? 12 : h % 12;
            const displayM = m < 10 ? `0${m}` : m;
            return `${displayH}:${displayM} ${ampm}`;
          } catch {
            return hhmm;
          }
        };
        list.push({
          id: ev.id || `ev-${idx}`,
          title: ev.title,
          time: formatTime(ev.startTime),
          type: ev.type,
          color: ev.type === 'Task' ? '#3b82f6' : ev.type === 'Habit' ? '#a855f7' : '#eab308'
        });
      });
    }

    // 2. Load uncompleted tasks with deadlines
    const activeTasks = tasks.filter(t => !t.completed);
    activeTasks.forEach(task => {
      // Check for duplication
      if (list.some(item => item.title.toLowerCase() === task.title.toLowerCase())) return;
      
      let displayTime = 'Today';
      if (task.deadline) {
        try {
          const d = new Date(task.deadline);
          const h = d.getHours();
          const m = d.getMinutes();
          const ampm = h >= 12 ? 'PM' : 'AM';
          const displayH = h % 12 === 0 ? 12 : h % 12;
          const displayM = m < 10 ? `0${m}` : m;
          displayTime = `${displayH}:${displayM} ${ampm}`;
        } catch {
          displayTime = task.deadline;
        }
      } else if (task.aiOptimalTime) {
        displayTime = task.aiOptimalTime;
      }
      
      list.push({
        id: task.id,
        title: task.title,
        time: displayTime,
        type: 'Task',
        color: task.importance === 'high' ? '#ef4444' : task.importance === 'medium' ? '#f97316' : '#3b82f6',
        completed: task.completed
      });
    });

    return list.slice(0, 3); // show top 3 on HUD preview
  }, [dailyPlan, tasks]);

  return (
    <div 
      className={`${
        isOpen 
          ? 'flex fixed right-4 top-24 z-50 h-[calc(100vh-120px)] w-80 shadow-[0_0_20px_rgba(6,182,212,0.2)] border-cyan-500/30' 
          : 'hidden lg:flex h-full w-80'
      } pointer-events-auto shrink-0 relative animate-holo-float`}
      style={{ 
        transform: isOpen ? 'none' : 'perspective(1000px) rotateY(-12deg) rotateX(2deg) translateZ(10px)',
        transformStyle: 'preserve-3d'
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="w-full h-full flex flex-col gap-4 p-4 pb-28 glass-card border-cyan-500/10 hover:border-cyan-500/20 shadow-md overflow-y-auto scrollbar-none relative">
        {/* Scanline glitch overlay inside the panel */}
        <div className="absolute inset-0 pointer-events-none holo-scanline animate-holo-scan opacity-15" />
   
        {/* Small projection emitter cap visual */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-[2px] bg-cyan-400/60 shadow-[0_0_8px_rgba(6,182,212,0.3)] rounded-full opacity-65" />
        
        {/* Close button for mobile drawer */}
        {isOpen && onClose && (
          <button 
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer z-50"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      
      {/* 1. UPCOMING REMINDERS CARD */}
      <div className="border border-white/5 bg-white/[0.01] hover:border-cyan-500/30 rounded-2xl p-5 transition-all duration-300">
        <div className="text-[10px] uppercase tracking-[0.2em] text-[#3b82f6] mb-4 font-black font-mono flex items-center justify-between">
          <span>UPCOMING REMINDERS</span>
          <Clock className="w-3.5 h-3.5 text-[#3b82f6]" />
        </div>

        {upcomingReminders.length > 0 && upcomingReminders[0].type !== 'System' ? (
          <div className="flex flex-col gap-3.5">
            {upcomingReminders.map((reminder) => (
              <div 
                key={reminder.id}
                className="flex items-center justify-between gap-3 p-2 bg-white/[0.02] border border-white/[0.03] rounded-xl hover:bg-white/[0.04] transition-colors"
              >
                <div className="flex gap-3 items-start min-w-0">
                  <button
                    onClick={() => reminder.type === 'Task' && handleToggleTask(reminder.id, reminder.title)}
                    className={`mt-0.5 w-5 h-5 rounded-full flex items-center justify-center shrink-0 border transition-all ${
                      reminder.completed 
                        ? 'bg-[#22c55e]/20 border-[#22c55e] text-[#22c55e]' 
                        : 'bg-black/30 hover:bg-white/10 border-white/20 hover:border-white/40 text-transparent'
                    }`}
                  >
                    <Check className="w-3 h-3 text-[#22c55e]" />
                  </button>
                  <div className="min-w-0">
                    <div className={`text-xs font-bold text-white/90 truncate ${reminder.completed ? 'line-through opacity-40' : ''}`}>
                      {reminder.title}
                    </div>
                    <div className="text-[9px] text-[#3b82f6] font-mono tracking-wider uppercase mt-1 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: reminder.color }} />
                      <span>{reminder.time}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 border border-dashed border-white/5 rounded-xl bg-white/[0.01]">
            <CheckCircle2 className="w-6 h-6 text-emerald-500/60 mx-auto mb-2" />
            <p className="text-[10px] font-semibold text-white/60 uppercase tracking-widest">Inbox Clean</p>
            <p className="text-[9px] text-white/40 mt-1">All standard objectives cleared!</p>
          </div>
        )}

        <button 
          onClick={() => setShowRemindersModal(true)}
          className="w-full mt-4 py-2 border border-white/10 hover:border-white/20 bg-white/[0.02] hover:bg-[#3b82f6]/10 text-white/80 hover:text-[#3b82f6] text-xs font-bold tracking-widest uppercase rounded-xl transition-all duration-300 cursor-pointer"
        >
          View All Desk
        </button>
      </div>

      {/* 2. AI COACH MESSAGE CARD */}
      <div className="border border-white/5 bg-white/[0.01] hover:border-cyan-500/30 rounded-2xl p-5 relative overflow-hidden transition-all duration-300">
        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#06b6d4] to-[#a855f7]"></div>
        
        <div className="text-[10px] uppercase tracking-[0.2em] text-cyan-400 mb-3 font-black font-mono flex items-center gap-2 holo-text-glow">
          <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
          <span>AI Coach Advisor</span>
        </div>

        {coachLoading ? (
          <div className="flex flex-col gap-2 py-4 items-center justify-center">
            <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
            <span className="text-[9px] text-cyan-400/40 uppercase tracking-widest font-mono">Synthesizing Advice...</span>
          </div>
        ) : coachError ? (
          <div className="py-2">
            <p className="text-[10px] text-cyan-400/60 italic">Advice engine idle. Complete some goals to populate insights.</p>
          </div>
        ) : (
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#06b6d4] to-[#a855f7] flex items-center justify-center shrink-0 shadow-lg border border-cyan-500/10">
              <img src="https://api.dicebear.com/7.x/bottts/svg?seed=Orbit" alt="AI" className="w-6 h-6 animate-pulse" referrerPolicy="no-referrer" />
            </div>
            <div className="min-w-0">
              <p className="text-xs leading-relaxed text-cyan-100/80 italic line-clamp-3">
                "{coachMsg?.motivation || "Maintain your streak! Consistently reviewing your workflow stabilizes your focus quotient."}"
              </p>
            </div>
          </div>
        )}

        <button 
          onClick={() => setShowCoachModal(true)}
          className="w-full mt-4 py-2 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/20 hover:border-cyan-500/45 rounded-xl text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer"
        >
          View Full Advice
        </button>
      </div>

      {/* 3. INTERACTIVE QUICK ACTIONS CARD */}
      <div className="border border-white/5 bg-white/[0.01] hover:border-cyan-500/30 rounded-2xl p-5 transition-all duration-300">
        <div className="text-[10px] uppercase tracking-[0.2em] text-[#a855f7] mb-4 font-black font-mono">
          QUICK ACTIONS
        </div>
        <div className="flex flex-col gap-2">
          
          <button 
            onClick={() => setShowAddTaskModal(true)} 
            className="flex items-center justify-between px-4 py-3 bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 hover:border-white/10 rounded-xl transition-all duration-200 text-xs font-bold tracking-wider text-white group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <Plus className="w-4 h-4 text-[#3b82f6] group-hover:scale-110 transition-transform" />
              <span>Add Quick Task</span>
            </div>
            <span className="text-[9px] font-mono text-white/30 uppercase">HUD</span>
          </button>

          <button 
            onClick={() => setShowAddHabitModal(true)} 
            className="flex items-center justify-between px-4 py-3 bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 hover:border-white/10 rounded-xl transition-all duration-200 text-xs font-bold tracking-wider text-white group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <Plus className="w-4 h-4 text-[#a855f7] group-hover:scale-110 transition-transform" />
              <span>Add Quick Habit</span>
            </div>
            <span className="text-[9px] font-mono text-white/30 uppercase">HUD</span>
          </button>

          <button 
            onClick={() => { if(onStartFocusMode) onStartFocusMode(); else onNavigate('focusMode'); }} 
            className="flex items-center justify-between px-4 py-3 bg-[#ef4444]/10 hover:bg-[#ef4444]/20 border border-[#ef4444]/20 text-[#ef4444] rounded-xl transition-all duration-200 text-xs font-bold tracking-wider cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <Zap className="w-4 h-4 animate-pulse" />
              <span>Start Focus Session</span>
            </div>
            <span className="text-[9px] font-mono text-[#ef4444]/60 uppercase">ACTIVE</span>
          </button>

          <button 
            onClick={toggleVoiceListening}
            className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-300 text-xs font-bold tracking-wider cursor-pointer ${
              isVoiceListening 
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                : 'bg-[#3b82f6]/10 hover:bg-[#3b82f6]/20 border border-[#3b82f6]/20 text-[#3b82f6]'
            }`}
          >
            <div className="flex items-center gap-3">
              <Mic className={`w-4 h-4 ${isVoiceListening ? 'animate-bounce' : ''}`} />
              <span>{isVoiceListening ? 'Listening Voice...' : 'Voice Command'}</span>
            </div>
            {isVoiceListening ? (
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            ) : (
              <span className="text-[9px] font-mono text-white/30 uppercase">MIC</span>
            )}
          </button>

        </div>
      </div>
      </div>


      {/* ======================================================== */}
      {/* OVERLAY MODAL: UPCOMING REMINDERS DESK */}
      {/* ======================================================== */}
      <AnimatePresence>
        {showRemindersModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRemindersModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-[#09090d]/95 border border-white/10 rounded-2xl shadow-[0_0_50px_rgba(59,130,246,0.15)] overflow-hidden flex flex-col max-h-[85vh]"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#3b82f6]/10 border border-[#3b82f6]/30 flex items-center justify-center text-[#3b82f6]">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-extrabold tracking-wider uppercase text-white">Reminders & Agenda</h2>
                    <p className="text-[10px] text-[#3b82f6] font-mono uppercase tracking-widest mt-0.5">Orbit Command Console</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowRemindersModal(false)}
                  className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4 text-white/70" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="p-6 overflow-y-auto space-y-6 flex-1 scrollbar-none">
                
                {/* Section: Today's Scheduled Events */}
                <div>
                  <h3 className="text-[11px] font-black uppercase text-white/50 tracking-widest mb-3.5 font-mono">Planned Schedule Events</h3>
                  {dailyPlan?.events && dailyPlan.events.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {dailyPlan.events.map((ev, idx) => (
                        <div key={idx} className="p-4 bg-white/[0.02] border border-white/5 rounded-xl hover:border-white/10 transition-all">
                          <div className="flex items-start justify-between gap-2">
                            <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full uppercase font-bold ${
                              ev.type === 'Task' ? 'bg-[#3b82f6]/10 text-[#3b82f6] border border-[#3b82f6]/20' :
                              ev.type === 'Habit' ? 'bg-[#a855f7]/10 text-[#a855f7] border border-[#a855f7]/20' :
                              'bg-amber-500/10 text-amber-500 border border-amber-500/20'
                            }`}>
                              {ev.type}
                            </span>
                            <span className="text-[10px] font-bold font-mono text-white/50">{ev.startTime} - {ev.endTime}</span>
                          </div>
                          <h4 className="text-sm font-bold text-white mt-2 truncate">{ev.title}</h4>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-white/40 italic">No scheduled calendar events for today. Trigger "Plan Day" to construct a routine.</p>
                  )}
                </div>

                {/* Section: Tasks Queue */}
                <div>
                  <h3 className="text-[11px] font-black uppercase text-white/50 tracking-widest mb-3.5 font-mono">Tasks Deadline Queue</h3>
                  {tasks.length > 0 ? (
                    <div className="space-y-2.5">
                      {tasks.map((task) => (
                        <div 
                          key={task.id} 
                          className={`flex items-center justify-between p-3.5 bg-white/[0.01] hover:bg-white/[0.03] border rounded-xl transition-all ${
                            task.completed ? 'border-emerald-500/20' : 'border-white/5 hover:border-white/10'
                          }`}
                        >
                          <div className="flex items-center gap-3.5 min-w-0">
                            <button
                              onClick={() => handleToggleTask(task.id, task.title)}
                              className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                                task.completed 
                                  ? 'bg-[#22c55e]/20 border-[#22c55e] text-[#22c55e]' 
                                  : 'bg-black/40 border-white/20 hover:border-[#3b82f6] text-transparent'
                              }`}
                            >
                              <Check className="w-3.5 h-3.5 text-[#22c55e]" />
                            </button>
                            <div className="min-w-0">
                              <p className={`text-sm font-bold text-white truncate ${task.completed ? 'line-through opacity-40' : ''}`}>
                                {task.title}
                              </p>
                              <div className="flex flex-wrap items-center gap-2 mt-1">
                                {task.importance && (
                                  <span className={`text-[8px] font-mono tracking-widest uppercase px-1.5 py-0.5 rounded ${
                                    task.importance === 'high' ? 'bg-[#ef4444]/10 text-[#ef4444]' :
                                    task.importance === 'medium' ? 'bg-orange-500/10 text-orange-400' :
                                    'bg-sky-500/10 text-sky-400'
                                  }`}>
                                    {task.importance}
                                  </span>
                                )}
                                <span className="text-[9px] text-white/40 font-mono">Estimated {task.duration}m</span>
                                {task.deadline && (
                                  <span className="text-[9px] text-[#3b82f6] font-mono">Due: {new Date(task.deadline).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          <button 
                            onClick={() => {
                              if (onCommandResult) onCommandResult('DELETE_TASK', { id: task.id });
                            }}
                            className="w-8 h-8 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 border border-red-500/20 flex items-center justify-center transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-white/40 italic">No tasks present. Use HUD Quick Actions to declare some objectives.</p>
                  )}
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ======================================================== */}
      {/* OVERLAY MODAL: AI COACH MESSAGE */}
      {/* ======================================================== */}
      <AnimatePresence>
        {showCoachModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCoachModal(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-xl bg-[#09090d]/95 border border-[#3b82f6]/25 rounded-2xl shadow-[0_0_50px_rgba(59,130,246,0.25)] overflow-hidden flex flex-col"
            >
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-[#3b82f6] via-[#a855f7] to-[#3b82f6]"></div>
              
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#3b82f6] to-[#a855f7] flex items-center justify-center shadow-lg">
                    <img src="https://api.dicebear.com/7.x/bottts/svg?seed=Orbit" alt="AI" className="w-7 h-7" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <h2 className="text-base font-extrabold tracking-wider uppercase text-white">Orbit Coach Desk</h2>
                    <p className="text-[10px] text-purple-400 font-mono uppercase tracking-widest mt-0.5">Automated Intelligence Advisor</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowCoachModal(false)}
                  className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4 text-white/70" />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto scrollbar-none">
                
                {/* Core Motivation */}
                <div className="bg-white/[0.02] border border-white/5 p-5 rounded-2xl relative">
                  <div className="text-[9px] font-mono text-[#3b82f6] uppercase tracking-widest mb-2 font-bold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Focus Mantra</span>
                  </div>
                  <p className="text-sm font-serif italic text-white/95 leading-relaxed">
                    "{coachMsg?.motivation || "Maintain your focus streak. Actionable micro-wins construct macro-success metrics."}"
                  </p>
                </div>

                {/* Technical Observation */}
                <div>
                  <h4 className="text-[10px] font-black uppercase text-white/50 tracking-widest mb-2.5 font-mono">Acoustic System Observations</h4>
                  <div className="p-4 bg-purple-950/20 border border-purple-500/20 rounded-xl text-xs text-white/80 leading-relaxed">
                    {coachMsg?.observation || "You are displaying consistent task-completion profiles. Active habits showing continuous compliance. Procrastination indexes are nominal today."}
                  </div>
                </div>

                {/* Operational Recommendation */}
                <div>
                  <h4 className="text-[10px] font-black uppercase text-white/50 tracking-widest mb-2.5 font-mono">Strategic Recommendation</h4>
                  <div className="p-4 bg-emerald-950/20 border border-emerald-500/20 rounded-xl text-xs text-white/95 leading-relaxed flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{coachMsg?.recommendation || "Prioritize high-impact items immediately. Conduct a focused sprint sequence between 09:30 AM and 11:00 AM."}</span>
                  </div>
                </div>

              </div>

              {/* Actions Footer */}
              <div className="p-6 bg-white/[0.01] border-t border-white/5 flex gap-3">
                <button
                  onClick={() => fetchCoachMsg(true)}
                  disabled={coachLoading}
                  className="flex-1 py-3 bg-[#3b82f6]/10 hover:bg-[#3b82f6]/20 text-[#3b82f6] border border-[#3b82f6]/30 hover:border-[#3b82f6]/50 rounded-xl text-xs font-bold tracking-widest uppercase flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${coachLoading ? 'animate-spin' : ''}`} />
                  <span>{coachLoading ? 'Re-fetching Analysis...' : 'Refresh Coaching Session'}</span>
                </button>
                <button
                  onClick={() => {
                    setShowCoachModal(false);
                    onNavigate('reflection');
                  }}
                  className="px-5 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold tracking-widest uppercase transition-colors cursor-pointer"
                >
                  View Full Metrics
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ======================================================== */}
      {/* OVERLAY MODAL: QUICK ADD TASK */}
      {/* ======================================================== */}
      <AnimatePresence>
        {showAddTaskModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddTaskModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-[#09090d]/95 border border-white/10 rounded-2xl shadow-2xl p-6"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2.5">
                  <Plus className="w-5 h-5 text-[#3b82f6]" />
                  <h3 className="text-sm font-black uppercase tracking-widest text-white">Create Quick Task</h3>
                </div>
                <button 
                  onClick={() => setShowAddTaskModal(false)}
                  className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer border border-white/5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <form onSubmit={handleAddTaskSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-1.5">Task Objective</label>
                  <input 
                    type="text" 
                    required
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    placeholder="e.g. Sync Database Schemas"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-[#3b82f6]/50 transition-colors"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-1.5">Priority Quotient</label>
                    <select
                      value={newTaskPriority}
                      onChange={(e: any) => setNewTaskPriority(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-3 text-sm text-white outline-none focus:border-[#3b82f6]/50 cursor-pointer"
                    >
                      <option value="low" className="bg-[#09090d]">Low</option>
                      <option value="medium" className="bg-[#09090d]">Medium</option>
                      <option value="high" className="bg-[#09090d]">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-1.5">Duration (min)</label>
                    <input 
                      type="number" 
                      required
                      min={5}
                      max={480}
                      value={newTaskDuration}
                      onChange={(e) => setNewTaskDuration(Number(e.target.value))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-[#3b82f6]/50"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 py-3.5 bg-gradient-to-r from-[#1d4ed8] to-[#6366f1] text-white text-xs font-bold tracking-widest uppercase rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 transition-all cursor-pointer"
                >
                  Declare Objective
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ======================================================== */}
      {/* OVERLAY MODAL: QUICK ADD HABIT */}
      {/* ======================================================== */}
      <AnimatePresence>
        {showAddHabitModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddHabitModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />

            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-[#09090d]/95 border border-white/10 rounded-2xl shadow-2xl p-6"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2.5">
                  <Plus className="w-5 h-5 text-[#a855f7]" />
                  <h3 className="text-sm font-black uppercase tracking-widest text-white">Create Quick Habit</h3>
                </div>
                <button 
                  onClick={() => setShowAddHabitModal(false)}
                  className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors cursor-pointer border border-white/5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <form onSubmit={handleAddHabitSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-1.5">Habit Identity</label>
                  <input 
                    type="text" 
                    required
                    value={newHabitTitle}
                    onChange={(e) => setNewHabitTitle(e.target.value)}
                    placeholder="e.g. Meditate 10m"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-[#a855f7]/50 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-white/50 mb-1.5">Frequency Rhythm</label>
                  <select
                    value={newHabitFrequency}
                    onChange={(e: any) => setNewHabitFrequency(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-3 text-sm text-white outline-none focus:border-[#a855f7]/50 cursor-pointer"
                  >
                    <option value="daily" className="bg-[#09090d]">Daily</option>
                    <option value="weekly" className="bg-[#09090d]">Weekly</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 py-3.5 bg-gradient-to-r from-[#7e22ce] to-[#ec4899] text-white text-xs font-bold tracking-widest uppercase rounded-xl shadow-lg shadow-purple-500/20 hover:shadow-purple-500/30 transition-all cursor-pointer"
                >
                  Anchor Routine
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast Feedback Notification Display */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 right-6 z-[200] bg-zinc-900/95 border border-[#3b82f6]/30 text-white text-xs px-5 py-3 rounded-xl shadow-[0_5px_25px_rgba(59,130,246,0.25)] flex items-center gap-2.5 font-sans"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
