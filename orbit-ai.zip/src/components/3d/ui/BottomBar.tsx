import React, { useState, useEffect, useMemo } from 'react';
import { ResponsiveContainer, AreaChart, Area, Tooltip } from 'recharts';
import { apiFetch } from '../../../utils/apiFetch';

interface BottomBarProps {
  tasks: any[];
  habits: any[];
}

export default function BottomBar({ tasks = [], habits = [] }: BottomBarProps) {
  const [focusTimeStr, setFocusTimeStr] = useState('0m');

  const completedTasks = useMemo(() => tasks.filter((t: any) => t.completed).length, [tasks]);
  const activeHabits = useMemo(() => habits.filter((h: any) => h.streak > 0).length, [habits]);

  // Dynamically calculate plan progress
  const planProgressPercent = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const completedTasksCount = tasks.filter((t: any) => t.completed).length;
    const completedHabitsCount = habits.filter((h: any) => h.completedDays?.includes(todayStr)).length;
    
    const totalItems = tasks.length + habits.length;
    if (totalItems === 0) return 100; // All clear if nothing scheduled

    const completedItems = completedTasksCount + completedHabitsCount;
    return Math.round((completedItems / totalItems) * 100);
  }, [tasks, habits]);

  // Fetch real focus session duration
  useEffect(() => {
    let isMounted = true;
    async function fetchSessions() {
      try {
        const res = await apiFetch('/api/focus_sessions');
        if (res.ok) {
          const sessions = await res.json();
          if (isMounted && Array.isArray(sessions)) {
            const totalMinutes = sessions.reduce((acc: number, s: any) => acc + (Number(s.duration) || 0), 0);
            if (totalMinutes >= 60) {
              const h = Math.floor(totalMinutes / 60);
              const m = totalMinutes % 60;
              setFocusTimeStr(`${h}h ${m}m`);
            } else {
              setFocusTimeStr(`${totalMinutes}m`);
            }
          }
        }
      } catch (err) {
        console.warn("[BottomBar] Failed to load focus session times dynamically:", err);
      }
    }
    fetchSessions();
    return () => { isMounted = false; };
  }, [tasks, habits]);

  const mockData = [
    { time: '09:00', focus: 60 },
    { time: '10:00', focus: 75 },
    { time: '11:00', focus: 85 },
    { time: '12:00', focus: 70 },
    { time: '13:00', focus: 90 },
    { time: '14:00', focus: 95 },
    { time: '15:00', focus: 80 }
  ];

  return (
    <div 
      className="w-full max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 py-3 px-6 rounded-3xl pointer-events-auto border border-cyan-500/10 bg-white/5 backdrop-blur-[20px] holo-glow-cyan animate-holo-float relative overflow-hidden"
      style={{ 
        transform: 'perspective(1000px) rotateX(15deg) translateZ(10px)',
        transformStyle: 'preserve-3d'
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Scanline glitch overlay inside the panel */}
      <div className="absolute inset-0 pointer-events-none holo-scanline animate-holo-scan opacity-20" />

      {/* Small projection emitter cap visual */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-32 h-[2px] bg-cyan-400 shadow-[0_0_10px_#06b6d4] rounded-full opacity-65" />
      
      <div className="flex items-center gap-8 md:gap-12 flex-1 justify-around relative z-10">
        <div className="text-center">
          <div className="text-3xl font-bold text-white mb-1 holo-text-glow">{completedTasks}</div>
          <div className="text-[10px] uppercase tracking-widest text-cyan-400/70 font-mono font-black">Tasks Completed</div>
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold text-[#a855f7] mb-1 drop-shadow-[0_0_8px_rgba(168,85,247,0.4)]">{activeHabits}</div>
          <div className="text-[10px] uppercase tracking-widest text-[#a855f7]/80 font-mono font-black">Active Habits</div>
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold text-amber-400 mb-1 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)]">{focusTimeStr}</div>
          <div className="text-[10px] uppercase tracking-widest text-amber-400/80 font-mono font-black">Focus Time</div>
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold text-emerald-400 mb-1 drop-shadow-[0_0_8px_rgba(52,211,153,0.4)]">{planProgressPercent}%</div>
          <div className="text-[10px] uppercase tracking-widest text-emerald-400/80 font-mono font-black font-semibold">Plan Progress</div>
        </div>
      </div>

      <div className="w-full md:w-64 h-24 hidden md:block border-l border-cyan-500/10 pl-6 relative z-10">
        <div className="text-[10px] uppercase tracking-widest text-cyan-400/60 mb-2 font-mono font-black">Productivity Trend</div>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={mockData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorFocus" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Tooltip contentStyle={{ backgroundColor: '#030a16', border: '1px solid #06b6d430', borderRadius: '8px', color: '#fff' }} />
            <Area type="monotone" dataKey="focus" stroke="#06b6d4" fillOpacity={1} fill="url(#colorFocus)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
    </div>
  );
}
