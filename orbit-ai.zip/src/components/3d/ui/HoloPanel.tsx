import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

interface HoloPanelProps {
  children: React.ReactNode;
  title: string;
  onClose?: () => void;
  color?: string; // e.g. '#06b6d4'
  className?: string;
  perspectiveAngle?: string; // CSS transform for 3D depth, e.g. 'perspective(1200px) rotateY(5deg)'
}

export default function HoloPanel({
  children,
  title,
  onClose,
  color = '#06b6d4',
  className = '',
  perspectiveAngle = 'perspective(1000px) rotateY(3deg) rotateX(1deg)'
}: HoloPanelProps) {
  const [sequenceStage, setSequenceStage] = useState<'beam' | 'wireframe' | 'fill' | 'ready'>('beam');

  useEffect(() => {
    // Hologram boot-up animation pipeline
    const beamTimer = setTimeout(() => setSequenceStage('wireframe'), 350);
    const wireframeTimer = setTimeout(() => setSequenceStage('fill'), 700);
    const readyTimer = setTimeout(() => setSequenceStage('ready'), 1000);

    return () => {
      clearTimeout(beamTimer);
      clearTimeout(wireframeTimer);
      clearTimeout(readyTimer);
    };
  }, []);

  // Volumetric flare behind the panel
  const glowStyle = {
    '--glow-color': color,
    background: `radial-gradient(400px circle at 50% 50%, ${color}15, transparent 70%)`
  } as React.CSSProperties;

  return (
    <div className={`relative ${className}`} style={{ transform: perspectiveAngle }}>
      {/* 1. Volumetric Projection Source Lighting Backdrop */}
      <div 
        className="absolute inset-0 pointer-events-none -z-10 blur-2xl opacity-60 rounded-3xl"
        style={glowStyle}
      />

      {/* 2. Main Panel Core */}
      <div 
        className="relative rounded-2xl border border-cyan-500/15 bg-white/5 backdrop-blur-[20px] overflow-hidden holo-glow-cyan animate-holo-float hover:border-cyan-400/35 transition-colors duration-500"
        style={{
          boxShadow: `0 0 30px ${color}10, inset 0 0 15px ${color}05`,
          borderColor: sequenceStage !== 'beam' ? `${color}30` : 'transparent'
        }}
      >
        {/* Continuous Floating Interactive Glitch Scanline Layer */}
        <div className="absolute inset-0 pointer-events-none holo-scanline animate-holo-scan opacity-40" />

        {/* Horizontal thin projection beam lines running at the top/bottom */}
        <div 
          className="absolute top-0 left-0 right-0 h-[1.5px] opacity-70 animate-pulse"
          style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }}
        />
        <div 
          className="absolute bottom-0 left-0 right-0 h-[1.5px] opacity-70 animate-pulse"
          style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }}
        />

        {/* Phase A: Vertically Expanding Light Beam Core */}
        {sequenceStage === 'beam' && (
          <motion.div 
            initial={{ height: '0%', opacity: 1 }}
            animate={{ height: '100%', opacity: 0.8 }}
            className="absolute left-1/2 top-0 -translate-x-1/2 w-1 shadow-[0_0_20px_#06b6d4]"
            style={{ backgroundColor: color }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
          />
        )}

        {/* Phase B: Wireframe borders reveal */}
        {sequenceStage !== 'beam' && (
          <div className="absolute inset-0 border-[1px] border-dashed pointer-events-none opacity-20" style={{ borderColor: color }} />
        )}

        {/* Phase C: Grid projection overlay */}
        {sequenceStage !== 'beam' && (
          <div 
            className="absolute inset-0 opacity-[0.03] pointer-events-none"
            style={{
              backgroundImage: `radial-gradient(${color} 1px, transparent 1px)`,
              backgroundSize: '16px 16px'
            }}
          />
        )}

        {/* Phase D: Actual Contents reveal */}
        <div className={`transition-all duration-700 p-6 ${sequenceStage === 'ready' ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-4 scale-95 pointer-events-none'}`}>
          {/* Header */}
          <div className="flex items-center justify-between border-b border-cyan-500/10 pb-4 mb-4">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 animate-pulse" style={{ color }} />
              <h3 
                className="text-sm font-black uppercase tracking-[0.2em] font-mono text-white holo-text-glow"
                style={{ textShadow: `0 0 10px ${color}60` }}
              >
                {title}
              </h3>
            </div>
            {onClose && (
              <button 
                onClick={onClose}
                className="text-cyan-500/50 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-md px-2 py-1 text-[10px] font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
              >
                Dissolve [X]
              </button>
            )}
          </div>

          {/* Body Content */}
          <div className="text-white/90 select-text">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
