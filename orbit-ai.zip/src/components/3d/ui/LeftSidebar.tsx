import React from 'react';
import { Home, CheckSquare, Target, Calendar, Brain, Dna, Zap, Settings, Sparkles, X } from 'lucide-react';

export default function LeftSidebar({ 
  onNavigate, 
  onStartFocusMode, 
  activeTab,
  isOpen = false,
  onClose
}: { 
  onNavigate: (tab: string) => void, 
  onStartFocusMode?: () => void, 
  activeTab?: string,
  isOpen?: boolean,
  onClose?: () => void
}) {
  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard', color: '#06b6d4' },
    { id: 'tasks', icon: CheckSquare, label: 'Tasks', color: '#3b82f6' },
    { id: 'habits', icon: Target, label: 'Habits', color: '#a855f7' },
    { id: 'reflection', icon: Calendar, label: 'Daily Plan', color: '#22c55e' },
    { id: 'aiCoach', icon: Brain, label: 'AI Coach', color: '#ec4899' },
    { id: 'focusMode', icon: Zap, label: 'Focus Mode', color: '#ef4444' },
    { id: 'dna', icon: Dna, label: 'Productivity DNA', color: '#06b6d4' },
    { id: 'settings', icon: Settings, label: 'Settings', color: '#64748b' }
  ];

  return (
    <div 
      className={`${
        isOpen 
          ? 'flex fixed left-4 top-24 z-50 h-[calc(100vh-120px)] w-64 shadow-[0_0_20px_rgba(6,182,212,0.2)] border-cyan-500/30' 
          : 'hidden lg:flex h-full w-60'
      } pointer-events-auto shrink-0 relative animate-holo-float`}
      style={{ 
        transform: isOpen ? 'none' : 'perspective(1000px) rotateY(12deg) rotateX(2deg) translateZ(10px)',
        transformStyle: 'preserve-3d'
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="w-full h-full flex flex-col gap-3 p-4 pb-24 glass-card border-cyan-500/10 hover:border-cyan-500/20 shadow-md overflow-y-auto scrollbar-none relative">
        {/* Scanline glitch overlay inside the panel */}
        <div className="absolute inset-0 pointer-events-none holo-scanline animate-holo-scan opacity-15" />

        {/* Small projection emitter cap visual */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-[2px] bg-cyan-400/60 shadow-[0_0_8px_rgba(6,182,212,0.3)] rounded-full opacity-65" />

        {/* Close button for mobile drawer */}
        {isOpen && onClose && (
          <button 
            onClick={onClose}
            className="absolute top-3 right-3 p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer z-50"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}

        <div className="flex items-center gap-2 mb-2 border-b border-cyan-500/10 pb-2.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-cyan-400 font-mono">
            Spatial HUD
          </span>
        </div>

        <div className="flex flex-col gap-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id || (!activeTab && item.id === 'dashboard');
            
            return (
              <button
                key={item.id}
                onClick={(e) => {
                  e.stopPropagation();
                  if (item.id === 'focusMode') {
                    if (onStartFocusMode) onStartFocusMode();
                  } else {
                    onNavigate(item.id);
                  }
                }}
                className={`group relative flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all duration-200 text-xs font-semibold tracking-wider font-mono cursor-pointer overflow-hidden border ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border-cyan-400/20 shadow-[0_0_10px_rgba(6,182,212,0.08)]' 
                    : 'text-white/60 hover:text-white hover:bg-cyan-500/5 border-transparent'
                }`}
              >
                {/* Left active line indicator */}
                {isActive && (
                  <div 
                    className="absolute left-0 top-0 bottom-0 w-[2.5px]"
                    style={{ backgroundColor: item.color }}
                  />
                )}

                <Icon 
                  className={`w-3.5 h-3.5 transition-transform duration-200 group-hover:scale-105`}
                  style={{ color: isActive ? item.color : 'rgba(255,255,255,0.4)' }}
                />
                
                <span className="relative z-10">
                  {item.label}
                </span>

                {/* Glowing micro-dot */}
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <div className="w-1 h-1 rounded-full bg-cyan-400/80" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
