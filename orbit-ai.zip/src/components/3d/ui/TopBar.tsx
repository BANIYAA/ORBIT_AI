import React from 'react';
import OrbitTopBar from '../../OrbitTopBar';
import { Task, Habit } from '../../../types';

interface TopBarProps {
  userName?: string;
  productivityScore?: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isFocusMode: boolean;
  setIsFocusMode: (focus: boolean) => void;
  onLogout: () => void;
  tasks: Task[];
  habits: Habit[];
  onCommandResult: (action: string, payload: any) => any;
}

export default function TopBar(props: TopBarProps) {
  return (
    <div className="w-full flex items-center justify-between pointer-events-auto">
      <OrbitTopBar {...props} />
    </div>
  );
}

