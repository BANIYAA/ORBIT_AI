import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Html } from '@react-three/drei';

export default function Satellite({ index, total, color, size, radius, label }: any) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const angleOffset = (index / total) * Math.PI * 2;
  
  useFrame((state) => {
    if (meshRef.current) {
      const time = state.clock.elapsedTime * 1.5;
      meshRef.current.position.x = Math.cos(time + angleOffset) * radius;
      meshRef.current.position.y = Math.sin(time + angleOffset) * radius * 0.2; // slight tilt
      meshRef.current.position.z = Math.sin(time + angleOffset) * radius;
    }
  });

  return (
    <mesh 
      ref={meshRef}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
      onPointerOut={(e) => { e.stopPropagation(); setHovered(false); }}
    >
      <sphereGeometry args={[size, 16, 16]} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} />
      
      {hovered && (
        <Html position={[0, 0.5, 0]} center className="pointer-events-none z-50">
          <div className="bg-black/90 text-white text-[9px] px-2 py-1 rounded border border-white/20 whitespace-nowrap">
            {label}
          </div>
        </Html>
      )}
    </mesh>
  );
}
