import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { Bell } from 'lucide-react';

export default function HoloDrone({ message, onComplete }: { message: string, onComplete: () => void }) {
  const droneRef = useRef<THREE.Group>(null);
  const [phase, setPhase] = useState<'approaching' | 'displaying' | 'leaving'>('approaching');
  const [timeInPhase, setTimeInPhase] = useState(0);

  useFrame((state, delta) => {
    setTimeInPhase(t => t + delta);
    const camera = state.camera;
    
    if (droneRef.current) {
      const drone = droneRef.current;
      
      // Target position in front of camera
      const targetPos = new THREE.Vector3(0, 1, -8);
      targetPos.applyQuaternion(camera.quaternion);
      targetPos.add(camera.position);

      if (phase === 'approaching') {
        // Spawn far away and fly in
        if (timeInPhase === 0) {
          const startPos = new THREE.Vector3((Math.random() - 0.5) * 40, 20, -40);
          startPos.applyQuaternion(camera.quaternion);
          startPos.add(camera.position);
          drone.position.copy(startPos);
        }
        
        drone.position.lerp(targetPos, 0.05);
        drone.lookAt(camera.position);
        
        if (drone.position.distanceTo(targetPos) < 0.5 && timeInPhase > 1) {
          setPhase('displaying');
          setTimeInPhase(0);
        }
      } else if (phase === 'displaying') {
        // Hover
        drone.position.y += Math.sin(state.clock.elapsedTime * 4) * 0.005;
        drone.lookAt(camera.position);
        
        if (timeInPhase > 4) {
          setPhase('leaving');
          setTimeInPhase(0);
        }
      } else if (phase === 'leaving') {
        // Fly up and away
        const escapePos = new THREE.Vector3(0, 50, -20);
        escapePos.applyQuaternion(camera.quaternion);
        escapePos.add(camera.position);
        
        drone.position.lerp(escapePos, 0.08);
        drone.lookAt(escapePos);
        
        if (timeInPhase > 2) {
          onComplete();
        }
      }
    }
  });

  return (
    <group ref={droneRef}>
      <mesh>
        <cylinderGeometry args={[0.2, 0.2, 0.1, 16]} />
        <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={2} wireframe />
      </mesh>
      
      {phase === 'displaying' && (
        <Html position={[0, 1.5, 0]} center className="pointer-events-none">
          <div className="bg-blue-900/40 backdrop-blur-md border border-blue-400/50 p-3 rounded-lg flex items-center gap-3 animate-in fade-in zoom-in duration-300">
            <Bell className="text-blue-400 w-5 h-5 animate-pulse" />
            <span className="text-blue-100 text-sm font-medium tracking-wide whitespace-nowrap">{message}</span>
          </div>
        </Html>
      )}
    </group>
  );
}
