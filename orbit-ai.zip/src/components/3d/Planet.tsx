import React, { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import * as Icons from 'lucide-react';
import Satellite from './Satellite';

export default function Planet({ id, name, color, icon, radius, index, count, onClick, tasks, habits, isActive }: any) {
  const groupRef = useRef<THREE.Group>(null);
  const planetRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  // Physics parameters based on index
  const semiMajorAxis = radius;
  const semiMinorAxis = radius * (0.8 + (index % 3) * 0.1); // Slight ellipse
  const speed = 0.5 - (radius / 50) * 0.3; // Kepler's 3rd law approximation
  const initialAngle = (index * 137.5) * (Math.PI / 180); // Golden angle spread
  const inclination = (index % 2 === 0 ? 1 : -1) * (0.05 + (index * 0.02)); // Orbital inclination
  
  // Planet shape wobble
  const wobbleSpeed = 0.5 + index * 0.1;
  const wobbleAmount = 0.1;

  useFrame((state) => {
    if (groupRef.current) {
      const angle = initialAngle + state.clock.elapsedTime * speed * 0.5;
      
      // Calculate elliptical position
      const x = Math.cos(angle) * semiMajorAxis;
      const z = Math.sin(angle) * semiMinorAxis;
      
      // Apply inclination
      const y = Math.sin(angle) * radius * inclination;

      groupRef.current.position.set(x, y, z);
    }
    
    if (planetRef.current) {
      planetRef.current.rotation.y += 0.01;
      
      // Axial wobble
      planetRef.current.rotation.x = Math.sin(state.clock.elapsedTime * wobbleSpeed) * wobbleAmount;
      planetRef.current.rotation.z = Math.cos(state.clock.elapsedTime * wobbleSpeed) * wobbleAmount;

      // Hover scale animation
      const targetScale = hovered || isActive ? 1.4 : 1.0;
      planetRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    }
  });

  const IconComponent = (Icons as any)[icon] || Icons.Circle;

  // Orbit path geometry
  const orbitGeometry = useMemo(() => {
    const points = [];
    for (let i = 0; i <= 64; i++) {
      const angle = (i / 64) * Math.PI * 2;
      const x = Math.cos(angle) * semiMajorAxis;
      const z = Math.sin(angle) * semiMinorAxis;
      const y = Math.sin(angle) * radius * inclination;
      points.push(new THREE.Vector3(x, y, z));
    }
    return new THREE.BufferGeometry().setFromPoints(points);
  }, [semiMajorAxis, semiMinorAxis, radius, inclination]);

  const renderGeometry = () => {
    switch (id) {
      case 'tasks':
        return <sphereGeometry args={[1.6, 32, 32]} />;
      case 'habits':
        return <sphereGeometry args={[1.3, 32, 32]} />;
      case 'reflection':
        return <dodecahedronGeometry args={[1.5, 0]} />;
      case 'aiCoach':
        return <icosahedronGeometry args={[1.5, 0]} />;
      case 'dna':
        return <torusKnotGeometry args={[0.9, 0.25, 64, 16]} />;
      case 'focusMode':
        return <sphereGeometry args={[1.4, 64, 64]} />;
      default:
        return <dodecahedronGeometry args={[1.5, 1]} />;
    }
  };

  const hasRing = id === 'habits' || id === 'focusMode' || id === 'reflection';

  return (
    <group>
      {/* Elliptical Orbit Ring */}
      {/* @ts-ignore */}
      <line geometry={orbitGeometry}>
        <lineBasicMaterial color={hovered || isActive ? color : '#ffffff'} transparent opacity={hovered || isActive ? 1.0 : 0.4} />
      </line>

      <group ref={groupRef}>
        {/* Space Station / Planet Core */}
        <mesh 
          ref={planetRef}
          onClick={(e) => { e.stopPropagation(); onClick(); }}
          onPointerOver={(e) => { e.stopPropagation(); setHovered(true); document.body.style.cursor = 'pointer'; }}
          onPointerOut={(e) => { e.stopPropagation(); setHovered(false); document.body.style.cursor = 'auto'; }}
        >
          {renderGeometry()}
          <meshStandardMaterial 
            color={color} 
            emissive={color} 
            emissiveIntensity={hovered || isActive ? 1.3 : 0.5} 
            roughness={0.2}
            metalness={0.9}
            wireframe={isActive}
          />
        </mesh>

        {/* Outer Energy Glow Shield */}
        <mesh scale={[1.18, 1.18, 1.18]}>
          {renderGeometry()}
          <meshStandardMaterial 
            color={color} 
            transparent 
            opacity={hovered || isActive ? 0.35 : 0.12} 
            wireframe 
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>
        
        {/* Planet Rings */}
        {hasRing && (
          <mesh rotation={[Math.PI / 3, Math.PI / 8, 0]}>
            <torusGeometry args={[id === 'focusMode' ? 2.5 : (id === 'reflection' ? 2.7 : 2.2), 0.04, 16, 100]} />
            <meshStandardMaterial 
              color={color} 
              emissive={color} 
              emissiveIntensity={0.6} 
              transparent 
              opacity={0.7} 
            />
          </mesh>
        )}
        
        {/* Satellites */}
        {tasks && tasks.filter((t:any)=>!t.completed).slice(0,10).map((task:any, i:number) => {
          let satSize = 0.15;
          if (task.duration) {
            if (task.duration <= 15) satSize = 0.1;
            else if (task.duration <= 30) satSize = 0.15;
            else if (task.duration <= 60) satSize = 0.2;
            else satSize = 0.3;
          }
          
          let satColor = "#3b82f6"; // Low = Blue
          if (task.importance === 'medium') satColor = "#f97316"; // Orange
          if (task.importance === 'high') satColor = "#ef4444"; // Red
          if (task.importance === 'critical') satColor = "#ffffff"; // White
          
          let satRadius = 2.5 + (i * 0.2); // Default spread
          if (task.deadline) {
            const daysToDeadline = (new Date(task.deadline).getTime() - Date.now()) / (1000 * 3600 * 24);
            satRadius = Math.max(1.5, Math.min(4.0, 1.5 + (daysToDeadline * 0.2)));
          }

          return <Satellite key={task.id} index={i} total={tasks.filter((t:any)=>!t.completed).length} color={satColor} size={satSize} radius={satRadius} label={task.title} />
        })}

        {habits && habits.slice(0,10).map((habit:any, i:number) => {
          const satSize = 0.1 + (habit.streak * 0.01);
          const satColor = habit.streak > 0 ? "#a855f7" : "#555555";
          return <Satellite key={habit.id} index={i} total={habits.length} color={satColor} size={satSize} radius={2.5} label={`${habit.title} (${habit.streak}🔥)`} />
        })}

        <Html position={[0, 2.5, 0]} center className="pointer-events-none transition-opacity duration-300" style={{ opacity: hovered || isActive ? 1 : 0.3 }}>
          <div className="bg-black/60 backdrop-blur-md border border-white/10 p-2 rounded-xl shadow-2xl flex flex-col items-center min-w-[100px] hover:bg-black/80 transition-colors">
            <div className="flex items-center gap-2 text-white font-bold text-xs mb-1 tracking-wide">
              <IconComponent size={14} color={color} />
              <span style={{ textShadow: `0 0 10px ${color}` }}>{name}</span>
            </div>
            {count !== undefined && (
              <div className="text-[9px] text-white/80 font-mono bg-white/10 px-2 py-0.5 rounded-full">
                {count} Active
              </div>
            )}
          </div>
        </Html>
      </group>
    </group>
  );
}
