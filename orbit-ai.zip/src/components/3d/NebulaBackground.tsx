import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function ParticleCloud({ color, count, radius, speed, size }: { color: string, count: number, radius: number, speed: number, size: number }) {
  const ref = useRef<THREE.Points>(null);
  
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = radius * Math.cbrt(Math.random());
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(2 * Math.random() - 1);
      
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.4; // flatter Y
      pos[i * 3 + 2] = r * Math.cos(phi);
    }
    return pos;
  }, [count, radius]);

  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * speed;
      // Pulse scale
      const scale = 1 + Math.sin(state.clock.elapsedTime * speed * 2) * 0.05;
      ref.current.scale.set(scale, scale, scale);
      
      ref.current.rotation.z = Math.sin(state.clock.elapsedTime * speed * 0.5) * 0.1;
      ref.current.rotation.x = Math.cos(state.clock.elapsedTime * speed * 0.3) * 0.1;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={size}
        color={color}
        transparent
        opacity={0.8}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

function Scene() {
  useFrame((state) => {
    // Subtle camera drift
    state.camera.position.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.5;
    state.camera.position.y = 2 + Math.cos(state.clock.elapsedTime * 0.1) * 0.2;
    state.camera.lookAt(0, 0, 0);
  });

  return (
    <>
      <fog attach="fog" args={['#020204', 5, 25]} />
      <ParticleCloud color="#47d6ff" count={6000} radius={18} speed={0.03} size={0.05} />
      <ParticleCloud color="#7e04b2" count={4000} radius={22} speed={0.02} size={0.06} />
      <ParticleCloud color="#ffffff" count={2000} radius={25} speed={0.015} size={0.04} />
    </>
  );
}

export default function NebulaBackground() {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none">
      <Canvas camera={{ position: [0, 2, 12], fov: 60 }}>
        <Scene />
      </Canvas>
    </div>
  );
}
