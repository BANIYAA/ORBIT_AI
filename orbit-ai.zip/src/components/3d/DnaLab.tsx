import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export default function DnaLab() {
  const groupRef = useRef<THREE.Group>(null);

  const numPairs = 20;
  const radius = 2;
  const height = 10;
  const spacing = height / numPairs;

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.5;
    }
  });

  const pairs = [];
  for (let i = 0; i < numPairs; i++) {
    const angle = i * 0.5;
    const y = -height / 2 + i * spacing;
    
    pairs.push(
      <group key={i} position={[0, y, 0]}>
        {/* Backbone 1 */}
        <mesh position={[Math.cos(angle) * radius, 0, Math.sin(angle) * radius]}>
          <sphereGeometry args={[0.3, 16, 16]} />
          <meshStandardMaterial color="#06b6d4" emissive="#06b6d4" emissiveIntensity={0.5} />
        </mesh>
        
        {/* Backbone 2 */}
        <mesh position={[-Math.cos(angle) * radius, 0, -Math.sin(angle) * radius]}>
          <sphereGeometry args={[0.3, 16, 16]} />
          <meshStandardMaterial color="#ec4899" emissive="#ec4899" emissiveIntensity={0.5} />
        </mesh>
        
        {/* Connecting bar */}
        <mesh rotation={[0, -angle, Math.PI / 2]}>
          <cylinderGeometry args={[0.05, 0.05, radius * 2]} />
          <meshStandardMaterial color="#ffffff" transparent opacity={0.3} />
        </mesh>
      </group>
    );
  }

  return (
    <group ref={groupRef} position={[
      Math.cos(4 * 137.5 * Math.PI / 180) * 30,
      0,
      Math.sin(4 * 137.5 * Math.PI / 180) * 30 * (0.8 + 0.1) // 0.8 + (4%3)*0.1 = 0.9
    ]}> 
      {pairs}
    </group>
  );
}
