import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

export default function MemoryCrystal({ position, text, color = "#eab308" }: { position: [number, number, number], text: string, color?: string }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005;
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.5;
    }
  });

  return (
    <group position={position}>
      <mesh 
        ref={meshRef}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <octahedronGeometry args={[0.8, 0]} />
        <meshStandardMaterial 
          color={color} 
          emissive={color}
          emissiveIntensity={hovered ? 0.8 : 0.2}
          wireframe={false}
          transparent
          opacity={0.8}
          roughness={0.1}
          metalness={0.9}
        />
      </mesh>
      
      {hovered && (
        <Html position={[0, 1.5, 0]} center className="pointer-events-none z-50">
          <div className="bg-yellow-900/60 backdrop-blur-md border border-yellow-500/50 p-3 rounded-lg shadow-2xl animate-in zoom-in duration-200">
            <div className="text-yellow-100 text-xs max-w-[150px] whitespace-normal text-center">
              {text}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}
