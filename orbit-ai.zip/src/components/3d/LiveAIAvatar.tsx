import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { MeshDistortMaterial, PointMaterial, Points } from '@react-three/drei';
import * as THREE from 'three';

export default function LiveAIAvatar({ targetPosition, isThinking }: { targetPosition?: THREE.Vector3, isThinking?: boolean }) {
  const avatarRef = useRef<THREE.Group>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  // Holographic particles
  const count = 200;
  const pointsRef = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const p = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      p[i * 3] = (Math.random() - 0.5) * 4;
      p[i * 3 + 1] = (Math.random() - 0.5) * 4;
      p[i * 3 + 2] = (Math.random() - 0.5) * 4;
    }
    return p;
  }, []);

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    // Float animation and attach to camera
    if (avatarRef.current) {
      // Calculate a position slightly in front of and to the right of the camera
      const camera = state.camera;
      const offset = new THREE.Vector3(3, -2, -6); // Right, Down, Forward
      offset.applyQuaternion(camera.quaternion);
      avatarRef.current.position.copy(camera.position).add(offset);

      // Add float effect relative to this fixed offset
      avatarRef.current.position.y += Math.sin(time * 2) * 0.1;
      
      // Look at target or center
      if (targetPosition) {
        avatarRef.current.lookAt(targetPosition);
      } else {
        // Look at world center
        avatarRef.current.lookAt(0, 0, 0);
      }
    }

    if (coreRef.current) {
      coreRef.current.rotation.x = time;
      coreRef.current.rotation.y = time * 0.5;
      const scale = isThinking ? 1 + Math.sin(time * 10) * 0.1 : 1 + Math.sin(time * 2) * 0.05;
      coreRef.current.scale.setScalar(scale);
    }

    if (ringRef.current) {
      ringRef.current.rotation.x = Math.PI / 2 + Math.sin(time) * 0.2;
      ringRef.current.rotation.y = time;
    }

    if (pointsRef.current) {
      pointsRef.current.rotation.y = time * 0.2;
    }
  });

  const color = isThinking ? "#ec4899" : "#06b6d4";

  return (
    <group position={[0, 10, 20]}> {/* Default fixed position relative to world, or attach to camera? */}
      <group ref={avatarRef}>
        {/* Holographic Core */}
        <mesh ref={coreRef}>
          <octahedronGeometry args={[1, 0]} />
          <meshStandardMaterial 
            color={color} 
            emissive={color}
            emissiveIntensity={isThinking ? 2 : 1}
            wireframe
            transparent
            opacity={0.8}
          />
        </mesh>
        
        {/* Outer Ring */}
        <mesh ref={ringRef}>
          <torusGeometry args={[1.5, 0.02, 16, 64]} />
          <meshBasicMaterial color={color} transparent opacity={0.5} />
        </mesh>

        <Points ref={pointsRef} positions={positions}>
          <PointMaterial transparent color={color} size={0.05} sizeAttenuation={true} depthWrite={false} blending={THREE.AdditiveBlending} opacity={0.4} />
        </Points>
      </group>
    </group>
  );
}
