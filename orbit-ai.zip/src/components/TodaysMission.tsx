import React from 'react';
import { Target, Clock, ArrowRight } from 'lucide-react';
import { Task } from '../types';

interface TodaysMissionProps {
  task: Task | undefined;
}

export default function TodaysMission({ task }: TodaysMissionProps) {
  if (!task) return null;

  return (
    <div className="bg-gradient-to-br from-[#111] to-[#0a0a0a] border border-[#222] p-8 space-y-6 shadow-2xl relative overflow-hidden">
      {/* Decorative sun glow behind the mission */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>

      <div className="flex items-center justify-between border-b border-[#222] pb-4 relative z-10">
        <h2 className="text-2xl font-light font-serif italic text-white flex items-center gap-3">
          <Target className="w-6 h-6 text-amber-500" />
          Today's Mission
        </h2>
        <span className="text-amber-500 font-mono text-[10px] uppercase tracking-widest border border-amber-500/30 px-3 py-1 bg-amber-950/20">
          Priority Score: {task.aiPriorityScore || 'N/A'}
        </span>
      </div>

      <div className="space-y-4 relative z-10">
        <h3 className="text-3xl font-medium text-white">{task.title}</h3>
        
        <div className="bg-[#151515] p-5 border-l-2 border-amber-500 space-y-2">
          <p className="text-[#888] font-mono text-[10px] uppercase tracking-widest flex items-center gap-2">
            <ArrowRight className="w-3 h-3 text-amber-500" />
            AI Reasoning
          </p>
          <p className="text-white text-sm leading-relaxed">{typeof task.aiReasoning === 'object' ? JSON.stringify(task.aiReasoning) : (task.aiReasoning || "Prioritized to optimize daily workflow.")}</p>
        </div>

        <div className="flex items-center gap-6 pt-2">
          <div className="flex items-center gap-2 text-sm text-[#888]">
            <Clock className="w-4 h-4 text-[#666]" />
            <span>Est. {task.duration} minutes</span>
          </div>
          {task.aiOptimalTime && (
            <div className="flex items-center gap-2 text-sm text-[#888]">
              <Target className="w-4 h-4 text-[#666]" />
              <span>{typeof task.aiOptimalTime === 'object' ? JSON.stringify(task.aiOptimalTime) : task.aiOptimalTime}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
