import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  Clock, 
  Flame, 
  Brain, 
  Target, 
  Sparkles, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Compass, 
  Trophy, 
  Calendar,
  Hourglass,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  BookOpen
} from 'lucide-react';
import { ProductivityDna, JournalInsight, ReflectionData } from '../types';
import { apiFetch } from '../utils/apiFetch';

interface FocusSession {
  id: string;
  taskId: string | null;
  startTime: string;
  endTime: string | null;
  durationMinutes: number;
  completed: boolean;
  createdAt: string;
}

interface AIRecommendations {
  whatToPrioritize: string;
  habitsToImprove: string;
  tasksToScheduleDifferently: string;
  riskAlerts: string[];
}

export default function ProductivityIntelligenceView() {
  const [dna, setDna] = useState<ProductivityDna | null>(null);
  const [sessions, setSessions] = useState<FocusSession[]>([]);
  const [journalInsights, setJournalInsights] = useState<JournalInsight[]>([]);
  const [reflections, setReflections] = useState<ReflectionData[]>([]);
  const [recommendations, setRecommendations] = useState<AIRecommendations | null>(null);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async (forceRefresh = false) => {
    try {
      if (forceRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      setError(null);

      // Fetch Productivity DNA
      const dnaUrl = `/api/productivity-dna${forceRefresh ? '?refresh=true' : ''}`;
      const dnaPromise = apiFetch(dnaUrl).then(res => {
        if (!res.ok) throw new Error('DNA failed');
        return res.json() as Promise<ProductivityDna>;
      });

      // Fetch Focus Sessions
      const sessionsPromise = apiFetch('/api/focus_sessions').then(res => {
        if (!res.ok) throw new Error('Sessions failed');
        return res.json() as Promise<{ sessions: FocusSession[] }>;
      });

      // Fetch Journal Insights
      const journalPromise = apiFetch('/api/journal-analysis').then(res => {
        if (!res.ok) throw new Error('Journal failed');
        return res.json() as Promise<JournalInsight[]>;
      });

      // Fetch Reflections
      const reflectionPromise = apiFetch('/api/reflection').then(res => {
        if (!res.ok) throw new Error('Reflections failed');
        return res.json() as Promise<{ reflections: ReflectionData[] }>;
      });

      // Fetch AI recommendations
      const recommendationsPromise = apiFetch('/api/productivity-intelligence/recommendations').then(res => {
        if (!res.ok) throw new Error('Recommendations failed');
        return res.json() as Promise<AIRecommendations>;
      });

      const [dnaData, sessionsData, journalData, reflectionData, recsData] = await Promise.all([
        dnaPromise.catch(err => {
          console.warn("Using offline fallback for DNA:", err);
          return null;
        }),
        sessionsPromise.catch(err => {
          console.warn("Failed fetching sessions:", err);
          return { sessions: [] };
        }),
        journalPromise.catch(err => {
          console.warn("Failed fetching journal insights:", err);
          return [];
        }),
        reflectionPromise.catch(err => {
          console.warn("Failed fetching reflections:", err);
          return { reflections: [] };
        }),
        recommendationsPromise.catch(err => {
          console.warn("Failed fetching AI recommendations:", err);
          return null;
        })
      ]);

      if (dnaData) setDna(dnaData);
      setSessions(Array.isArray(sessionsData?.sessions) ? sessionsData.sessions : []);
      setJournalInsights(Array.isArray(journalData) ? journalData : []);
      setReflections(Array.isArray(reflectionData?.reflections) ? reflectionData.reflections : []);
      
      if (recsData) {
        setRecommendations(recsData);
      } else {
        // Build robust local suggestions based on current arrays if API failed
        setRecommendations({
          whatToPrioritize: "Focus on outstanding high-importance items in your task manager. Prioritize deep focus blocks in your morning hours.",
          habitsToImprove: "Establish routine consistency: Anchor your habits directly onto existing events (e.g., right after morning briefing).",
          tasksToScheduleDifferently: "Allocate custom duration allowances. Ensure complex tasks are decomposed beforehand into 15-minute intervals.",
          riskAlerts: ["Check for overdue schedule items to prevent compounding deadline blocks."]
        });
      }

    } catch (err: any) {
      console.error("Dashboard compiled error:", err);
      setError(err.message || 'An error occurred during pattern compilation');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Helper Calculations
  const completedSessions = sessions.filter(s => s.completed);
  const totalFocusMinutes = completedSessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalFocusHours = (totalFocusMinutes / 60).toFixed(1);

  // Focus Streak Calculation
  const calculateFocusStreak = (sessionsList: FocusSession[]): number => {
    const completed = sessionsList.filter(s => s.completed);
    if (completed.length === 0) return 0;

    const dates = completed.map(s => {
      try {
        return s.startTime.split('T')[0];
      } catch {
        return '';
      }
    }).filter(d => d !== '');

    const dateSet = new Set(dates);
    let streak = 0;
    const current = new Date();

    const todayStr = current.toISOString().split('T')[0];
    if (dateSet.has(todayStr)) {
      streak++;
      while (true) {
        current.setDate(current.getDate() - 1);
        const prevStr = current.toISOString().split('T')[0];
        if (dateSet.has(prevStr)) {
          streak++;
        } else {
          break;
        }
      }
    } else {
      current.setDate(current.getDate() - 1);
      const yesterdayStr = current.toISOString().split('T')[0];
      if (dateSet.has(yesterdayStr)) {
        streak++;
        while (true) {
          current.setDate(current.getDate() - 1);
          const prevStr = current.toISOString().split('T')[0];
          if (dateSet.has(prevStr)) {
            streak++;
          } else {
            break;
          }
        }
      }
    }
    return streak;
  };

  const focusStreak = calculateFocusStreak(sessions);
  const focusReliability = sessions.length > 0 
    ? Math.round((completedSessions.length / sessions.length) * 100) 
    : 100;

  // Render Loading state
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 space-y-4">
        <div className="relative flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin"></div>
          <Sparkles className="w-6 h-6 text-indigo-400 absolute animate-pulse" />
        </div>
        <p className="text-xs uppercase tracking-widest font-mono text-[#666]">Mapping Productivity Intelligence...</p>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="p-8 border border-rose-500/20 bg-rose-500/5 text-center space-y-4 rounded-none max-w-lg mx-auto my-12">
        <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto" />
        <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">Intelligence Engine Offline</h3>
        <p className="text-xs text-[#999] max-w-md mx-auto">{error}</p>
        <button 
          onClick={() => fetchData()}
          className="px-4 py-2 border border-[#333] text-white text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-all cursor-pointer"
        >
          Retry Compilation
        </button>
      </div>
    );
  }

  // Generate 7-day Weekly Trend values
  const getWeeklyTrend = () => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const result: { label: string; score: number }[] = [];
    const today = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayLabel = days[d.getDay()];
      
      // Find reflection score or default
      const reflection = reflections.find(r => r.date === dateStr);
      let score = 0;
      if (reflection) {
        score = Math.round((reflection.completionRate + reflection.habitConsistency + reflection.focusScore) / 3);
      } else {
        // heuristic calculation based on focus sessions completed on that day
        const daySessions = sessions.filter(s => s.startTime.split('T')[0] === dateStr);
        if (daySessions.length > 0) {
          const completedCount = daySessions.filter(s => s.completed).length;
          score = Math.round(50 + (completedCount / daySessions.length) * 40);
        } else {
          score = 0;
        }
      }
      result.push({ label: dayLabel, score: Math.min(Math.max(score, 0), 100) });
    }
    return result;
  };

  const weeklyData = getWeeklyTrend();

  // Generate 30-day Grid data for Activity Heatmap
  const getMonthlyGrid = () => {
    const result: { date: string; score: number }[] = [];
    const today = new Date();
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      
      // Find productivity score for the day
      const reflection = reflections.find(r => r.date === dateStr);
      let score = 0;
      if (reflection) {
        score = Math.round((reflection.completionRate + reflection.habitConsistency + reflection.focusScore) / 3);
      } else {
        const daySessions = sessions.filter(s => s.startTime.split('T')[0] === dateStr);
        if (daySessions.length > 0) {
          score = daySessions.filter(s => s.completed).length * 30 + 30;
        } else {
          score = 0; // inactive days
        }
      }
      result.push({ date: dateStr, score: Math.min(score, 100) });
    }
    return result;
  };

  const monthlyGridData = getMonthlyGrid();

  // Get dynamic daily score from latest reflection or computed
  const latestReflection = reflections[0];
  const computedDailyScore = latestReflection 
    ? Math.round((latestReflection.completionRate + latestReflection.habitConsistency + latestReflection.focusScore) / 3)
    : dna ? Math.round((dna.completionRate + dna.focusScore + dna.habitScore) / 3) : 0;

  // Color mapping helper for heat values
  const getHeatColorClass = (score: number) => {
    if (score === 0) return 'bg-[#121212] border-white/5';
    if (score < 35) return 'bg-indigo-950/40 text-indigo-400 border-indigo-900/30';
    if (score < 65) return 'bg-indigo-800/40 text-indigo-300 border-indigo-700/30';
    if (score < 85) return 'bg-indigo-600/50 text-indigo-200 border-indigo-500/40';
    return 'bg-indigo-500 text-white shadow-[0_0_12px_rgba(99,102,241,0.5)] border-indigo-400';
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Dashboard Top Control Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/10 pb-6 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Activity className="w-5 h-5" />
            </span>
            <span className="text-[10px] uppercase font-mono tracking-[0.2em] text-indigo-400">Cognitive Hub</span>
          </div>
          <h1 className="text-xl font-medium tracking-tight text-white mt-1 font-sans">
            Productivity Intelligence
          </h1>
        </div>

        <button
          onClick={() => fetchData(true)}
          disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 text-white hover:bg-white hover:text-black transition-all font-mono text-[10px] uppercase tracking-widest cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Sequencing Genome...' : 'Regenerate Analysis'}
        </button>
      </div>

      {/* Grid Layout for Dashboard Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Module 1: Productivity Score & Trend (Left Column - 4 cols wide) */}
        <div className="lg:col-span-4 flex flex-col space-y-8">
          
          {/* Glassmorphic Daily Score Card */}
          <div className="p-6 bg-white/5 backdrop-blur-[20px] border border-white/10 relative overflow-hidden flex flex-col items-center text-center space-y-4">
            <div className="absolute top-0 right-0 p-3">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
            </div>
            
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#888] font-mono">
              Productivity Score
            </h2>

            {/* Glowing Radial Progress Concentric Wheel */}
            <div className="relative w-40 h-40 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                {/* Background path */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="rgba(255, 255, 255, 0.05)"
                  strokeWidth="6"
                  fill="transparent"
                />
                {/* Score path */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="url(#indigoGrad)"
                  strokeWidth="7"
                  fill="transparent"
                  strokeDasharray={2 * Math.PI * 40}
                  strokeDashoffset={2 * Math.PI * 40 * (1 - computedDailyScore / 100)}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                />
                {/* Gradient Definition */}
                <defs>
                  <linearGradient id="indigoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#818cf8" />
                    <stop offset="100%" stopColor="#c084fc" />
                  </linearGradient>
                </defs>
              </svg>
              {/* Inner glowing center */}
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-4xl font-bold tracking-tighter text-white font-sans drop-shadow-[0_0_15px_rgba(129,140,248,0.3)]">
                  {computedDailyScore}
                </span>
                <span className="text-[9px] uppercase tracking-wider text-[#666] font-mono">
                  Rating: {computedDailyScore >= 85 ? "Optimal" : computedDailyScore >= 65 ? "Steady" : "Lagging"}
                </span>
              </div>
            </div>

            <p className="text-xs text-[#999] leading-relaxed px-4 font-sans">
              Daily autonomous performance index computed from completed schedule items, core tasks, and cognitive consistency.
            </p>
          </div>

          {/* Weekly and Monthly Trends */}
          <div className="p-6 bg-white/5 backdrop-blur-[20px] border border-white/10 space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-widest text-[#888] font-mono flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                Performance Trends
              </h2>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/5 px-2 py-0.5 border border-emerald-500/10">
                Stable
              </span>
            </div>

            {/* Custom SVG Line Chart */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-[#666]">Weekly Score Timeline</span>
                <span className="text-[10px] font-mono text-indigo-400">Last 7 Days</span>
              </div>
              
              <div className="h-28 w-full border border-white/5 bg-black/30 relative flex items-end pt-4 pb-2 px-1">
                {/* Simple responsive visual bars for score representing historical points */}
                <div className="w-full h-full flex items-end justify-between px-2 gap-1.5">
                  {weeklyData.map((day, idx) => (
                    <div key={idx} className="flex-1 flex flex-col items-center space-y-1 group">
                      {/* Tooltip on hover */}
                      <div className="absolute bottom-16 opacity-0 group-hover:opacity-100 transition-opacity bg-black border border-white/15 px-1.5 py-0.5 text-[8px] font-mono text-white rounded pointer-events-none z-10">
                        {day.score}%
                      </div>
                      <div className="w-full relative bg-white/5 flex flex-col justify-end h-16 rounded-sm overflow-hidden">
                        <div 
                          style={{ height: `${day.score}%` }} 
                          className="w-full bg-gradient-to-t from-indigo-600 to-indigo-400 transition-all duration-700 hover:from-purple-500 hover:to-indigo-400"
                        />
                      </div>
                      <span className="text-[8px] font-mono text-[#555] uppercase group-hover:text-white transition-colors">
                        {day.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Monthly Calendar Matrix Heatmap */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-[#666]">Monthly Activity Grid</span>
                <span className="text-[10px] font-mono text-[#555]">30 Days</span>
              </div>
              <div className="grid grid-cols-10 gap-1.5 bg-black/20 p-2.5 border border-white/5">
                {monthlyGridData.map((node, idx) => (
                  <div
                    key={idx}
                    className={`aspect-square border transition-all duration-300 hover:scale-115 cursor-crosshair ${getHeatColorClass(node.score)}`}
                    title={`Date: ${node.date} | Score: ${node.score}%`}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between text-[8px] font-mono text-[#555] uppercase px-1">
                <span>Lagging</span>
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-[#121212] border border-white/5" />
                  <div className="w-2 h-2 bg-indigo-950/40" />
                  <div className="w-2 h-2 bg-indigo-800/40" />
                  <div className="w-2 h-2 bg-indigo-600/50" />
                  <div className="w-2 h-2 bg-indigo-500" />
                </div>
                <span>Optimal</span>
              </div>
            </div>

          </div>

        </div>

        {/* Column 2: Focus Analytics & DNA (Middle Column - 4 cols wide) */}
        <div className="lg:col-span-4 flex flex-col space-y-8">
          
          {/* Glassmorphic Focus Analytics Card */}
          <div className="p-6 bg-white/5 backdrop-blur-[20px] border border-white/10 space-y-5">
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#888] font-mono flex items-center gap-1.5 border-b border-white/5 pb-3">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              Focus Analytics
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3.5 border border-white/5 bg-black/20 flex flex-col space-y-1">
                <span className="text-[9px] uppercase font-mono text-[#666]">Total Focus Time</span>
                <span className="text-xl font-bold text-white tracking-tight font-sans">
                  {totalFocusHours} <span className="text-xs text-indigo-400 font-mono">Hrs</span>
                </span>
              </div>

              <div className="p-3.5 border border-white/5 bg-black/20 flex flex-col space-y-1">
                <span className="text-[9px] uppercase font-mono text-[#666]">Focus Streak</span>
                <span className="text-xl font-bold text-white tracking-tight flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-orange-400 animate-pulse fill-orange-400" />
                  {focusStreak} <span className="text-xs text-orange-400 font-mono">Days</span>
                </span>
              </div>
            </div>

            {/* Session History list */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono uppercase text-[#666]">Session History</span>
              {sessions.length === 0 ? (
                <div className="text-center py-4 border border-dashed border-white/5 bg-black/10">
                  <p className="text-[10px] font-mono text-[#555] uppercase">No Focus Sessions Found</p>
                </div>
              ) : (
                <div className="max-h-[148px] overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                  {sessions.slice(0, 5).map((session, idx) => (
                    <div key={idx} className="p-2 border border-white/5 bg-black/10 flex items-center justify-between text-xs font-mono">
                      <div className="flex flex-col space-y-0.5">
                        <span className="text-[10px] text-[#999] truncate max-w-[130px]">
                          Session #{session.id.split('_')[1]?.slice(-4) || idx}
                        </span>
                        <span className="text-[8px] text-[#555]">
                          {new Date(session.startTime).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-white font-bold">{session.durationMinutes}m</span>
                        <span className={`px-1.5 py-0.5 text-[8px] uppercase border font-bold ${
                          session.completed 
                            ? 'text-emerald-400 bg-emerald-500/5 border-emerald-500/10' 
                            : 'text-amber-400 bg-amber-500/5 border-amber-500/10'
                        }`}>
                          {session.completed ? 'Finished' : 'Interrupted'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Productivity DNA Module */}
          <div className="p-6 bg-white/5 backdrop-blur-[20px] border border-white/10 space-y-5">
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#888] font-mono flex items-center gap-1.5 border-b border-white/5 pb-3">
              <Compass className="w-3.5 h-3.5 text-indigo-400" />
              Productivity DNA
            </h2>

            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 border border-white/5 bg-black/20">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-400" />
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase font-mono text-[#666]">Best Work Hours</span>
                    <span className="text-xs font-bold text-white">{dna?.bestWorkHours || "09:00 AM – 12:00 PM"}</span>
                  </div>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-purple-400" />
              </div>

              <div className="flex justify-between items-center p-3 border border-white/5 bg-black/20">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-cyan-400" />
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase font-mono text-[#666]">Most Productive Day</span>
                    <span className="text-xs font-bold text-white">{dna?.productiveDay || "Tuesday"}</span>
                  </div>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
              </div>

              <div className="flex justify-between items-center p-3 border border-white/5 bg-black/20">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase font-mono text-[#666]">Focus Reliability</span>
                    <span className="text-xs font-bold text-white">{focusReliability}% Consistency</span>
                  </div>
                </div>
                <div className="w-12 bg-white/5 h-2 rounded-full overflow-hidden">
                  <div style={{ width: `${focusReliability}%` }} className="bg-emerald-500 h-full" />
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Column 3: Journal Intelligence & AI Recommendations (Right Column - 4 cols wide) */}
        <div className="lg:col-span-4 flex flex-col space-y-8">
          
          {/* Glassmorphic Journal Intelligence Card */}
          <div className="p-6 bg-white/5 backdrop-blur-[20px] border border-white/10 space-y-5">
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#888] font-mono flex items-center gap-1.5 border-b border-white/5 pb-3">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              Journal Intelligence
            </h2>

            {journalInsights.length === 0 ? (
              <div className="text-center py-6 border border-dashed border-white/5 bg-black/10 space-y-2">
                <HelpCircle className="w-6 h-6 text-[#444] mx-auto animate-pulse" />
                <p className="text-[10px] font-mono text-[#555] uppercase">No Journal Analyzed Yet</p>
                <p className="text-[9px] text-[#444]">Submit a daily reflection or type a journal entry in the Reflection tab to generate insights.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3.5 border border-white/5 bg-black/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] uppercase font-mono text-indigo-400">Recent Insights</span>
                    <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/5 px-1.5 border border-emerald-500/10">
                      Score: {journalInsights[0].score || 80}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#aaa] leading-relaxed italic">
                    "{journalInsights[0].analysis.slice(0, 150)}..."
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-[#666]">Improvement Suggestions</span>
                  <div className="space-y-1.5">
                    {journalInsights[0] && Array.isArray(journalInsights[0].improvements) && journalInsights[0].improvements.slice(0, 2).map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-[10px] font-mono text-[#999] leading-tight">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* AI Recommendations Module */}
          <div className="p-6 bg-white/5 backdrop-blur-[20px] border border-indigo-500/20 relative space-y-5">
            {/* Ambient gold glow highlight on card border */}
            <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-indigo-500/30 to-transparent" />
            
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#888] font-mono flex items-center gap-1.5 border-b border-white/5 pb-3">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              AI Recommendations
            </h2>

            <div className="space-y-4">
              
              {/* Prioritize Recommendation */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[9px] uppercase font-mono text-[#666]">What to Prioritize</span>
                </div>
                <p className="text-[10.5px] text-[#aaa] leading-relaxed pl-5 font-sans">
                  {recommendations?.whatToPrioritize || "Establish daily priority buffers to prevent schedule overflow."}
                </p>
              </div>

              {/* Habit Suggestion */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[9px] uppercase font-mono text-[#666]">Routine Improvement</span>
                </div>
                <p className="text-[10.5px] text-[#aaa] leading-relaxed pl-5 font-sans">
                  {recommendations?.habitsToImprove || "Focus on consistency triggers. Ensure low-adherence habits are coupled with a regular cue."}
                </p>
              </div>

              {/* Scheduling feedback */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[9px] uppercase font-mono text-[#666]">Scheduling Shifts</span>
                </div>
                <p className="text-[10.5px] text-[#aaa] leading-relaxed pl-5 font-sans">
                  {recommendations?.tasksToScheduleDifferently || "Utilize single-task block durations. Break larger blocks into multiple focus sprints."}
                </p>
              </div>

              {/* Risk Alerts */}
              {Array.isArray(recommendations?.riskAlerts) && recommendations.riskAlerts.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-white/5">
                  <div className="flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                    <span className="text-[9px] uppercase font-mono text-rose-400 font-bold">System Risks Detected</span>
                  </div>
                  <div className="space-y-1 pl-5">
                    {recommendations.riskAlerts.map((alert, idx) => (
                      <p key={idx} className="text-[10px] text-rose-300 font-mono leading-tight">
                        • {alert}
                      </p>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
