import React from 'react';
import { DailyPlanResponse } from '../types';
import { Calendar, Lightbulb, Activity, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface DailyPlanViewProps {
  plan: DailyPlanResponse | null;
  isPlanningDay: boolean;
  onPlanDay: () => void;
}

export default function DailyPlanView({ plan, isPlanningDay, onPlanDay }: DailyPlanViewProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-light font-serif italic text-white flex items-center gap-2">
          Autonomous Schedule
        </h2>
        <button
          onClick={onPlanDay}
          disabled={isPlanningDay}
          className={`px-5 py-2.5 text-[10px] font-bold uppercase tracking-widest border transition-all ${
            isPlanningDay 
            ? 'bg-[#222] border-[#222] text-[#666] cursor-not-allowed'
            : 'bg-white text-black border-white hover:bg-transparent hover:text-white'
          }`}
        >
          {isPlanningDay ? 'Planning...' : 'Plan My Day'}
        </button>
      </div>

      {plan && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-[10px] font-mono uppercase tracking-widest text-[#666]">Timeline ({plan.date})</h3>
            <div className="space-y-3 relative border-l border-[#222] ml-2 pl-6">
              {Array.isArray(plan.events) && plan.events.map((event, idx) => (
                <div key={idx} className="relative">
                  <div className="absolute -left-[29px] top-1.5 w-2 h-2 bg-[#444] rounded-full ring-4 ring-[#0a0a0a]"></div>
                  <div className="bg-[#111] border border-[#1a1a1a] p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <h4 className="text-[#e0e0e0] text-xs font-medium">{typeof event.title === 'object' ? JSON.stringify(event.title) : event.title}</h4>
                      <span className="text-[9px] text-[#888] uppercase tracking-wider font-mono">
                        {typeof event.type === 'object' ? JSON.stringify(event.type) : event.type}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#aaa] font-mono bg-[#1a1a1a] px-2 py-1 rounded-sm whitespace-nowrap">
                      {typeof event.startTime === 'object' ? JSON.stringify(event.startTime) : event.startTime} — {typeof event.endTime === 'object' ? JSON.stringify(event.endTime) : event.endTime}
                    </div>
                  </div>
                </div>
              ))}
              {(!Array.isArray(plan.events) || plan.events.length === 0) && (
                <p className="text-xs text-[#666]">No events planned for today.</p>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-gradient-to-br from-[#111] to-[#050505] border border-[#1a1a1a] p-4 space-y-3 shadow-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-[9px] font-mono uppercase tracking-widest text-[#888] flex items-center gap-1.5">
                  <Activity className="w-3 h-3" />
                  Productivity Score
                </h3>
                {plan.productivityTrend === 'Improving' && <TrendingUp className="w-3.5 h-3.5 text-green-500" />}
                {plan.productivityTrend === 'Declining' && <TrendingDown className="w-3.5 h-3.5 text-red-500" />}
                {plan.productivityTrend === 'Stable' && <Minus className="w-3.5 h-3.5 text-amber-500" />}
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-light text-white">{plan.productivityScore}</span>
                <span className="text-xs text-[#666] font-mono">/ 100</span>
              </div>
            </div>

            <div className="bg-[#111] border border-[#1a1a1a] p-4 space-y-3">
              <h3 className="text-[9px] font-mono uppercase tracking-widest text-[#888] flex items-center gap-1.5 mb-3">
                <Lightbulb className="w-3 h-3" />
                Smart Insights
              </h3>
              <div className="space-y-3">
                {Array.isArray(plan.insights) && plan.insights.map((insight, idx) => (
                  <div key={idx} className="flex gap-2.5 items-start">
                    <div className="text-amber-500 mt-0.5 select-none font-mono text-[10px]">0{idx + 1}</div>
                    <p className="text-xs text-[#eee] leading-relaxed">
                      {typeof insight === 'object' && insight !== null 
                        ? (insight as any).message || JSON.stringify(insight) 
                        : insight}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
