import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, Square, CheckCircle, Target, Award, Clock, Flame, Calendar, Activity, TrendingUp, Settings, User, Compass, Zap } from 'lucide-react';
import { Task } from '../types';
import { apiFetch } from '../utils/apiFetch';
import OrbitTopBar from './OrbitTopBar';

interface FocusModeProps {
  tasks: Task[];
  sunTaskId: string | null;
  onCompleteTask: (id: string) => void;
  onExit: () => void;
  habits: any[];
  userName?: string;
  productivityScore?: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isFocusMode: boolean;
  setIsFocusMode: (focus: boolean) => void;
  onLogout: () => void;
  onCommandResult: (action: string, payload: any) => any;
}

export default function FocusMode({ 
  tasks, 
  sunTaskId, 
  onCompleteTask, 
  onExit, 
  habits,
  userName,
  productivityScore,
  activeTab,
  setActiveTab,
  isFocusMode,
  setIsFocusMode,
  onLogout,
  onCommandResult
}: FocusModeProps) {
  const [mission, setMission] = useState<string | null>(null);
  const [durationMinutes, setDurationMinutes] = useState<number>(25);
  const [sessionState, setSessionState] = useState<'setup' | 'active' | 'paused' | 'completed'>('setup');
  const [timeRemaining, setTimeRemaining] = useState<number>(25 * 60);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<string | null>(null);
  const [sessions, setSessions] = useState<any[]>([]);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  
  const timerRef = useRef<number | null>(null);

  // Mouse parallax movement for ambient light
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const moveX = (e.clientX - window.innerWidth / 2) * 0.05;
      const moveY = (e.clientY - window.innerHeight / 2) * 0.05;
      setMousePos({ x: moveX, y: moveY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const sunTask = tasks.find(t => t.id === sunTaskId);

  // Fetch Focus Sessions for analytics
  const fetchSessions = () => {
    apiFetch('/api/focus_sessions')
      .then(res => res.json())
      .then(data => {
        if (data.sessions) {
          setSessions(data.sessions);
        }
      })
      .catch(err => console.error("Error fetching sessions:", err));
  };

  useEffect(() => {
    fetchSessions();
  }, [sessionState]);

  useEffect(() => {
    // Fetch mission
    apiFetch('/api/focus_mission', {
      method: 'POST',
      body: JSON.stringify({ sunTask: sunTaskId, tasks, habits })
    })
    .then(res => res.json())
    .then(data => {
      setMission(data.mission || "Your mission is to maintain peak performance and strategic focus to successfully beat Diksha by 9:00 p.m. today. Channel your energy into executing this priority with precision and determination.");
    })
    .catch(() => {
      setMission("Your mission is to maintain peak performance and strategic focus to successfully beat Diksha by 9:00 p.m. today. Channel your energy into executing this priority with precision and determination.");
    });
  }, [sunTaskId, tasks, habits]);

  // Handle global voice commands sent from App.tsx via a custom event, or pass them down
  useEffect(() => {
    const handleCommand = (e: any) => {
      const intent = e.detail.intent;
      if (intent === 'FOCUS_NOW' && sessionState === 'setup') startSession();
      else if (intent === 'FOCUS_PAUSE' && sessionState === 'active') pauseSession();
      else if (intent === 'FOCUS_RESUME' && sessionState === 'paused') resumeSession();
      else if (intent === 'FOCUS_END' && (sessionState === 'active' || sessionState === 'paused')) endSession();
    };
    window.addEventListener('FOCUS_COMMAND', handleCommand);
    return () => window.removeEventListener('FOCUS_COMMAND', handleCommand);
  }, [sessionState, durationMinutes]);

  const startSession = () => {
    setSessionId(`fs_${Date.now()}`);
    setStartTime(new Date().toISOString());
    setTimeRemaining(durationMinutes * 60);
    setSessionState('active');
  };

  const pauseSession = () => {
    setSessionState('paused');
  };

  const resumeSession = () => {
    setSessionState('active');
  };

  const endSession = async () => {
    setSessionState('completed');
    if (timerRef.current) clearInterval(timerRef.current);
    
    const endTime = new Date().toISOString();
    const actualDurationMinutes = Math.round((durationMinutes * 60 - timeRemaining) / 60);
    
    // Save to DB
    if (sessionId) {
      try {
        await apiFetch('/api/focus_sessions', {
          method: 'POST',
          body: JSON.stringify({
            session: {
              id: sessionId,
              taskId: sunTaskId,
              startTime,
              endTime,
              durationMinutes: actualDurationMinutes,
              completed: true
            }
          })
        });
        fetchSessions();
      } catch (e) {
        console.error("Failed to save focus session:", e);
      }
    }
  };

  useEffect(() => {
    if (sessionState === 'active') {
      timerRef.current = window.setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            endSession();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [sessionState]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = 100 - (timeRemaining / (durationMinutes * 60)) * 100;

  // Calculate focus analytics dynamically
  const getAnalytics = () => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const sevenDaysAgo = startOfDay - 7 * 24 * 60 * 60 * 1000;
    const thirtyDaysAgo = startOfDay - 30 * 24 * 60 * 60 * 1000;

    let dailyTime = 0;
    let weeklyTime = 0;
    let monthlyTime = 0;
    let longestSession = 0;
    const activeDates = new Set<string>();

    sessions.forEach(s => {
      if (!s.completed) return;
      
      const sTime = new Date(s.startTime).getTime();
      const duration = s.durationMinutes || 0;
      
      if (duration > longestSession) {
        longestSession = duration;
      }

      if (sTime >= startOfDay) {
        dailyTime += duration;
      }
      if (sTime >= sevenDaysAgo) {
        weeklyTime += duration;
      }
      if (sTime >= thirtyDaysAgo) {
        monthlyTime += duration;
      }

      const dateStr = new Date(s.startTime).toISOString().split('T')[0];
      activeDates.add(dateStr);
    });

    // Calculate Streak
    let streak = 0;
    let checkDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    while (true) {
      const dateStr = checkDate.toISOString().split('T')[0];
      if (activeDates.has(dateStr)) {
        streak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        if (streak === 0) {
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayStr = yesterday.toISOString().split('T')[0];
          if (activeDates.has(yesterdayStr)) {
            checkDate = yesterday;
            continue;
          }
        }
        break;
      }
    }

    return {
      dailyTime,
      weeklyTime,
      monthlyTime,
      longestSession,
      streak
    };
  };

  const stats = getAnalytics();

  return (
    <div className="fixed inset-0 bg-[#020204] text-[#e5e1e8] z-50 overflow-y-auto selection:bg-[#a5e7ff]/30">
      {/* Star Field & Immersive Space Atmosphere */}
      <div className="star-field pointer-events-none" />
      
      {/* Background Solar Core & Orbital Rings */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] solar-glow"
          style={{ transform: `translate(calc(-50% + ${mousePos.x}px), calc(-50% + ${mousePos.y}px))` }}
        />
        <div className="orbital-ring w-[500px] h-[500px] animate-orbit border-dashed" />
        <div className="orbital-ring w-[800px] h-[800px] animate-orbit-reverse border-solid opacity-20" />
        <div className="orbital-ring w-[1100px] h-[1100px] animate-orbit opacity-10" />
      </div>

      {/* Top Header Navigation - Standard Unified Taskbar used in every page */}
      <OrbitTopBar
        userName={userName}
        productivityScore={productivityScore}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setIsFocusMode(false);
          setActiveTab(tab);
        }}
        isFocusMode={isFocusMode}
        setIsFocusMode={setIsFocusMode}
        onLogout={onLogout}
        tasks={tasks}
        habits={habits}
        onCommandResult={onCommandResult}
      />

      {/* Main Container */}
      <main className="relative pt-24 pb-8 min-h-[calc(100vh-6rem)] flex items-center justify-center px-4 sm:px-10 max-w-7xl mx-auto z-10">
        <AnimatePresence mode="wait">
          {sessionState === 'setup' && (
            <motion.div 
              key="setup"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start w-full"
            >
              {/* Left Column: Preset Select & Deep Work Initializer */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-3 px-3 py-1 rounded-full bg-white/5 border border-[#a5e7ff]/20 w-fit">
                    <span className="w-2 h-2 rounded-full bg-[#a5e7ff] shadow-[0_0_8px_#a5e7ff] animate-ping" />
                    <span className="font-semibold text-[10px] text-[#a5e7ff] tracking-[0.2em] font-mono uppercase">FOCUS PROTOCOL INITIALIZATION</span>
                  </div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight leading-none font-sans">Set Focus Duration</h1>
                </div>

                {/* Focus Presets Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[25, 45, 60, 90].map(mins => {
                    const isActive = durationMinutes === mins;
                    return (
                      <button
                        key={mins}
                        onClick={() => {
                          setDurationMinutes(mins);
                          setTimeRemaining(mins * 60);
                        }}
                        className={`group flex flex-col items-center justify-center py-6 px-4 rounded-xl transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer ${
                          isActive 
                            ? 'glass-card border-[#a5e7ff]/50 bg-[#a5e7ff]/10 shadow-[0_0_20px_rgba(71,214,255,0.15)] text-[#a5e7ff]' 
                            : 'glass-card border-white/10 hover:border-[#a5e7ff]/30 text-white/40'
                        }`}
                      >
                        <span className={`text-3xl sm:text-4xl font-bold transition-all ${isActive ? 'text-[#a5e7ff] scale-110' : 'text-[#e5e1e8]/30 group-hover:text-[#e5e1e8]'}`}>
                          {mins}
                        </span>
                        <span className={`text-[9px] font-bold tracking-[0.15em] font-mono mt-1.5 uppercase ${isActive ? 'text-[#a5e7ff]/80' : 'text-[#bbc9cf]/30'}`}>
                          MIN
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Mission Card */}
                {mission && (
                  <div className="glass-card p-4 sm:p-5 rounded-xl relative overflow-hidden border-l-4 border-l-[#a5e7ff] shadow-2xl">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-[#a5e7ff]" />
                      <span className="font-bold text-[9px] text-[#a5e7ff] tracking-[0.15em] font-mono uppercase">TODAY'S FOCUS MISSION</span>
                    </div>
                    <p className="text-[#e5e1e8]/90 leading-relaxed max-w-xl text-xs sm:text-sm font-sans">
                      {mission}
                    </p>
                    <div className="absolute -right-10 -bottom-10 w-24 h-24 bg-[#a5e7ff]/5 blur-3xl rounded-full" />
                  </div>
                )}

                {/* CTA Play Button */}
                <button
                  onClick={startSession}
                  className="mt-1 flex items-center justify-center gap-4 bg-[#e5e1e8] hover:bg-white text-[#020204] font-bold text-base sm:text-lg py-4 px-10 rounded-full neo-glow-cyan w-fit group transition-all duration-300 hover:scale-[1.02] active:scale-95 cursor-pointer"
                >
                  <Play className="w-5 h-5 fill-current group-hover:rotate-12 transition-transform duration-300" />
                  <span>Initialize Deep Work</span>
                </button>
              </div>

              {/* Right Column: Focus Analytics Sticky Panel */}
              <aside className="lg:col-span-5 w-full">
                <div className="glass-card p-4 sm:p-6 rounded-2xl sticky top-24 h-fit border-white/5 space-y-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <Compass className="w-5 h-5 text-[#a5e7ff] animate-spin-slow" />
                      <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">Focus Analytics</h2>
                    </div>
                    <span className="w-1.5 h-1.5 rounded-full bg-[#a5e7ff]/30" />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {/* Daily Focus */}
                    <div className="glass-card p-3 rounded-xl bg-white/[0.02] border-white/5 hover:bg-white/[0.05] transition-all duration-300">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Clock className="w-3 h-3 text-[#a5e7ff]" />
                        <span className="font-bold text-[8px] text-[#bbc9cf] tracking-widest font-mono uppercase">DAILY FOCUS</span>
                      </div>
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-2xl font-bold text-white leading-none">{stats.dailyTime}</span>
                        <span className="text-[10px] text-[#bbc9cf]/60 font-mono">min</span>
                      </div>
                    </div>

                    {/* Focus Streak */}
                    <div className="glass-card p-3 rounded-xl bg-white/[0.02] border-white/5 hover:bg-white/[0.05] transition-all duration-300">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Flame className="w-3 h-3 text-[#ffb77f]" />
                        <span className="font-bold text-[8px] text-[#bbc9cf] tracking-widest font-mono uppercase">STREAK</span>
                      </div>
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-2xl font-bold text-white leading-none">{stats.streak}</span>
                        <span className="text-[10px] text-[#bbc9cf]/60 font-mono">days</span>
                      </div>
                    </div>

                    {/* Weekly Focus */}
                    <div className="glass-card p-3 rounded-xl bg-white/[0.02] border-white/5 hover:bg-white/[0.05] transition-all duration-300">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Calendar className="w-3 h-3 text-[#a5e7ff]" />
                        <span className="font-bold text-[8px] text-[#bbc9cf] tracking-widest font-mono uppercase">WEEKLY</span>
                      </div>
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-2xl font-bold text-white leading-none">{stats.weeklyTime}</span>
                        <span className="text-[10px] text-[#bbc9cf]/60 font-mono">min</span>
                      </div>
                    </div>

                    {/* Longest Session */}
                    <div className="glass-card p-3 rounded-xl bg-white/[0.02] border-white/5 hover:bg-white/[0.05] transition-all duration-300">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Award className="w-3 h-3 text-[#a5e7ff]" />
                        <span className="font-bold text-[8px] text-[#bbc9cf] tracking-widest font-mono uppercase">LONGEST</span>
                      </div>
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-2xl font-bold text-white leading-none">{stats.longestSession}</span>
                        <span className="text-[10px] text-[#bbc9cf]/60 font-mono">min</span>
                      </div>
                    </div>
                  </div>

                  {/* Monthly Focus Time */}
                  <div className="glass-card p-4 rounded-xl bg-white/[0.02] border-white/5 space-y-3">
                    <div>
                      <span className="font-bold text-[8px] text-[#bbc9cf] tracking-widest font-mono uppercase block mb-0.5">MONTHLY FOCUS TIME</span>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-3xl font-extrabold text-[#a5e7ff] tracking-tight">{stats.monthlyTime}</span>
                        <span className="text-[10px] text-[#bbc9cf] font-mono uppercase tracking-wider">minutes focused</span>
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-[#a5e7ff] to-[#00d2ff] rounded-full shadow-[0_0_10px_#a5e7ff]"
                        style={{ width: `${Math.min(100, (stats.monthlyTime / 1000) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              </aside>
            </motion.div>
          )}

          {(sessionState === 'active' || sessionState === 'paused') && (
            <motion.div 
              key="timer"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="text-center w-full flex flex-col items-center max-w-2xl mx-auto py-6"
            >
              {sunTask ? (
                <div className="mb-8 flex flex-col items-center">
                  <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#a5e7ff]/10 border border-[#a5e7ff]/20 text-[#a5e7ff] text-[10px] font-mono uppercase tracking-[0.2em] mb-3">
                    <Zap className="w-3.5 h-3.5 animate-pulse" />
                    <span>Active Target Protocol</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl text-white font-bold leading-tight max-w-lg text-center tracking-tight">
                    {sunTask.title}
                  </h3>
                </div>
              ) : (
                <div className="mb-8 flex flex-col items-center">
                  <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#a5e7ff]/10 border border-[#a5e7ff]/20 text-[#a5e7ff] text-[10px] font-mono uppercase tracking-[0.2em] mb-3">
                    <Compass className="w-3.5 h-3.5 animate-spin-slow" />
                    <span>Neural Flow State</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl text-white font-bold leading-tight max-w-lg text-center tracking-tight">
                    Pure Deep Work Session
                  </h3>
                </div>
              )}

              {/* Huge Outer Glowing Circular Orbit Timer */}
              <div className="relative w-64 sm:w-72 h-64 sm:h-72 flex flex-col items-center justify-center mb-10">
                <svg viewBox="0 0 320 320" className="absolute inset-0 w-full h-full -rotate-90">
                  <circle
                    cx="160"
                    cy="160"
                    r="150"
                    className="stroke-white/[0.03]"
                    strokeWidth="8"
                    fill="none"
                    style={{ cx: '50%', cy: '50%' }}
                  />
                  <motion.circle
                    cx="160"
                    cy="160"
                    r="150"
                    className="stroke-[#a5e7ff] drop-shadow-[0_0_15px_rgba(165,231,255,0.4)]"
                    strokeWidth="8"
                    fill="none"
                    strokeLinecap="round"
                    style={{ cx: '50%', cy: '50%' }}
                    initial={{ strokeDasharray: "942 942", strokeDashoffset: 942 }}
                    animate={{ strokeDashoffset: 942 - (942 * progress) / 100 }}
                    transition={{ duration: 1, ease: "linear" }}
                  />
                </svg>
                
                {/* Internal Glow Backdrop for active timer */}
                <div className="absolute inset-10 bg-[#a5e7ff]/5 rounded-full blur-2xl animate-pulse pointer-events-none" />

                <div className="relative z-10 text-[3.8rem] sm:text-[4.5rem] font-light text-[#a5e7ff] tracking-tighter tabular-nums leading-none drop-shadow-[0_0_20px_rgba(71,214,255,0.3)]">
                  {formatTime(timeRemaining)}
                </div>
                
                {sessionState === 'paused' && (
                  <div className="absolute bottom-12 text-[8px] font-mono uppercase tracking-[0.25em] text-[#ffb77f] animate-pulse bg-[#ffb77f]/10 px-2.5 py-0.5 rounded-full border border-[#ffb77f]/20">
                    PROTOCOL PAUSED
                  </div>
                )}
              </div>

              {/* Timer Action Buttons */}
              <div className="flex items-center gap-6">
                {sessionState === 'active' ? (
                  <button 
                    onClick={pauseSession}
                    className="w-14 h-14 rounded-full bg-[#131317] hover:bg-white/5 border border-white/10 hover:border-[#a5e7ff]/50 text-[#a5e7ff] flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer shadow-[0_0_15px_rgba(0,0,0,0.5)]"
                    title="Pause Focus"
                  >
                    <Pause size={20} className="fill-[#a5e7ff] stroke-[#a5e7ff]" />
                  </button>
                ) : (
                  <button 
                    onClick={resumeSession}
                    className="w-14 h-14 rounded-full bg-[#a5e7ff]/10 hover:bg-[#a5e7ff]/20 border border-[#a5e7ff]/50 text-white flex items-center justify-center shadow-[0_0_25px_rgba(165,231,255,0.3)] hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer"
                    title="Resume Focus"
                  >
                    <Play size={20} className="fill-[#a5e7ff] stroke-[#a5e7ff]" />
                  </button>
                )}
                <button 
                  onClick={endSession}
                  className="w-14 h-14 rounded-full bg-[#131317] border border-white/10 hover:border-red-500/50 text-[#bbc9cf]/60 hover:text-red-400 flex items-center justify-center hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer shadow-[0_0_15px_rgba(0,0,0,0.5)]"
                  title="Abandon Session"
                >
                  <Square size={18} className="fill-current" />
                </button>
              </div>
            </motion.div>
          )}

          {sessionState === 'completed' && (
            <motion.div 
              key="completed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center max-w-md mx-auto py-12"
            >
              <div className="w-24 h-24 bg-[#a5e7ff]/10 rounded-full flex items-center justify-center mx-auto mb-8 border border-[#a5e7ff]/30 shadow-[0_0_30px_rgba(165,231,255,0.2)] animate-pulse">
                <CheckCircle size={40} className="text-[#a5e7ff]" />
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-3 tracking-tight">Session Complete</h2>
              <p className="text-[#bbc9cf] text-[16px] mb-10 leading-relaxed">
                Superb concentration. You focused for <strong className="text-white">{Math.round((durationMinutes * 60 - timeRemaining) / 60)} minutes</strong> on your task.
              </p>
              
              {sunTask && !sunTask.completed ? (
                <div className="glass-card border-white/10 rounded-2xl p-6 sm:p-8 mb-8 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1 h-full bg-[#a5e7ff]" />
                  <p className="text-white text-[15px] font-semibold mb-6">Were you able to fully complete <span className="text-[#a5e7ff]">"{sunTask.title}"</span> during this session?</p>
                  <div className="flex gap-4 justify-center relative z-10">
                    <button 
                      onClick={() => {
                        onCompleteTask(sunTask.id);
                        onExit();
                      }}
                      className="bg-[#a5e7ff]/10 text-[#a5e7ff] hover:bg-[#a5e7ff] hover:text-[#020204] border border-[#a5e7ff]/30 px-6 py-3 rounded-full font-bold text-xs uppercase tracking-widest transition-all duration-300 flex items-center gap-2 cursor-pointer hover:scale-102 active:scale-98"
                    >
                      <CheckCircle size={16} /> Yes, mark complete
                    </button>
                    <button 
                      onClick={onExit}
                      className="bg-white/5 text-white hover:bg-white/10 border border-white/10 px-6 py-3 rounded-full font-bold text-xs uppercase tracking-widest transition-all duration-300 cursor-pointer hover:scale-102 active:scale-98"
                    >
                      Not yet
                    </button>
                  </div>
                </div>
              ) : (
                <button 
                  onClick={onExit}
                  className="bg-[#e5e1e8] hover:bg-white text-[#020204] px-10 py-4 rounded-full font-bold text-sm uppercase tracking-widest hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer shadow-lg"
                >
                  Return to Orbit Dashboard
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation Mobile - Hidden on desktop */}
      <nav className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] rounded-full bg-[#131317]/20 backdrop-blur-2xl border border-white/15 shadow-[0_8px_32px_rgba(0,0,0,0.5)] flex justify-around items-center p-2.5 z-50">
        <div className="flex flex-col items-center p-2 text-[#bbc9cf]/40 cursor-pointer">
          <Compass className="w-5 h-5" />
          <span className="font-semibold text-[8px] tracking-wider mt-1 uppercase font-mono">Modules</span>
        </div>
        <div className="flex flex-col items-center bg-[#a5e7ff]/20 text-[#a5e7ff] shadow-[0_0_15px_rgba(71,214,255,0.4)] rounded-full px-5 py-2 scale-105 cursor-pointer">
          <Activity className="w-5 h-5" />
          <span className="font-bold text-[8px] tracking-wider mt-1 uppercase font-mono">Neural</span>
        </div>
        <div className="flex flex-col items-center p-2 text-[#bbc9cf]/40 cursor-pointer">
          <TrendingUp className="w-5 h-5" />
          <span className="font-semibold text-[8px] tracking-wider mt-1 uppercase font-mono">Sync</span>
        </div>
      </nav>
    </div>
  );
}

