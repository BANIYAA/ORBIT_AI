import React, { useState, useMemo, useEffect } from 'react';
import { Task } from '../types';

interface SolarSystemProps {
  tasks: Task[];
  onTaskComplete: (id: string) => void;
}

export default function SolarSystem({ tasks, onTaskComplete }: SolarSystemProps) {
  const [explodingSunId, setExplodingSunId] = useState<string | null>(null);
  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1024);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const sortedTasks = useMemo(() => {
    return [...tasks].filter(t => !t.completed).sort((a, b) => {
      if (a.aiRank !== undefined && b.aiRank !== undefined) return a.aiRank - b.aiRank;
      if (a.aiPriorityScore !== undefined && b.aiPriorityScore !== undefined) return b.aiPriorityScore - a.aiPriorityScore;
      return 0;
    });
  }, [tasks]);

  const sunTask = sortedTasks.length > 0 ? sortedTasks[0] : null;
  const planetTasks = sortedTasks.slice(1, 6);

  const handleSunComplete = () => {
    if (!sunTask || explodingSunId) return;
    setExplodingSunId(sunTask.id);
    setTimeout(() => {
      onTaskComplete(sunTask.id);
      setExplodingSunId(null);
    }, 4000);
  };

  return (
    <div className="w-full h-[600px] bg-black border border-[#222] relative overflow-hidden flex items-center justify-center rounded-2xl">
      {/* Deep Space Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(30,30,30,0.5)_0%,rgba(0,0,0,1)_100%)]"></div>

      {sortedTasks.length === 0 ? (
        <div className="z-10 text-[#555] font-mono uppercase tracking-widest text-xs text-center space-y-2 animate-pulse">
          <p>Universe Empty</p>
          <p className="text-[10px]">Add tasks to ignite your solar system.</p>
        </div>
      ) : (
        <>
          {/* Sun Task */}
          {sunTask && (
            <div className={`absolute z-20 flex flex-col items-center justify-center transition-all duration-[3000ms] ${explodingSunId === sunTask.id ? 'scale-[3] opacity-0 blur-3xl' : 'scale-100 opacity-100'}`}>
              <button 
                onClick={handleSunComplete}
                className="group relative w-32 h-32 md:w-40 md:h-40 rounded-full flex items-center justify-center cursor-pointer transition-transform hover:scale-105"
              >
                {/* Sun Glow */}
                <div className={`absolute inset-0 rounded-full blur-2xl transition-colors duration-1000 ${explodingSunId === sunTask.id ? 'bg-orange-500/80 scale-150' : 'bg-amber-500/20 group-hover:bg-amber-500/40'}`}></div>
                {/* Sun Core */}
                <div className={`absolute inset-2 rounded-full bg-gradient-to-br shadow-[0_0_60px_rgba(245,158,11,0.6)] transition-all duration-1000 ${explodingSunId === sunTask.id ? 'from-orange-100 via-white to-amber-200 shadow-[0_0_200px_rgba(255,255,255,1)] animate-ping' : 'from-amber-300 via-amber-500 to-orange-600 animate-pulse'}`}></div>
                {/* Sun Content */}
                <div className={`relative z-10 text-center px-4 w-full transition-opacity duration-500 ${explodingSunId === sunTask.id ? 'opacity-0' : 'opacity-100'}`}>
                  <p className="text-black font-bold text-sm tracking-wide uppercase line-clamp-2 leading-tight drop-shadow-md">
                    {sunTask.title}
                  </p>
                  <p className="text-black/70 text-[10px] font-bold tracking-widest uppercase mt-1">Sun Task</p>
                </div>
              </button>
            </div>
          )}

          {/* Planets */}
          {planetTasks.map((task, index) => {
            // Calculate orbital mechanics
            
            // Dynamic scaling based on viewport width to prevent clipping
            const isSmallMobile = windowWidth <= 375;
            const isMobile = windowWidth <= 768;
            
            const baseRadius = isSmallMobile ? 80 : (isMobile ? 100 : 140);
            const radiusIncrement = isSmallMobile ? 25 : (isMobile ? 35 : 50);
            
            const radius = baseRadius + index * radiusIncrement; // Orbit distance
            const orbitDuration = Math.max(20, 60 - index * 8); // Outer planets move slower
            
            // Limit planet sizes on mobile
            const maxPlanetSize = isSmallMobile ? 40 : (isMobile ? 45 : 60);
            const minPlanetSize = isSmallMobile ? 18 : (isMobile ? 20 : 24);
            const size = Math.min(maxPlanetSize, Math.max(minPlanetSize, (task.duration || 30) * 0.8)); // Planet size based on duration
            
            const colors = [
              "from-blue-400 to-indigo-600",
              "from-emerald-400 to-teal-600",
              "from-purple-400 to-fuchsia-600",
              "from-rose-400 to-red-600",
              "from-cyan-400 to-blue-600"
            ];
            const colorClass = colors[index % colors.length];

            return (
              <div 
                key={task.id}
                className="absolute inset-0 m-auto flex items-center justify-center rounded-full border border-white/[0.03]"
                style={{ width: radius * 2, height: radius * 2 }}
              >
                {/* The orbiting container */}
                <div 
                  className="absolute inset-0 w-full h-full animate-spin-slow"
                  style={{ animationDuration: `${orbitDuration}s`, animationDirection: index % 2 === 0 ? 'normal' : 'reverse' }}
                >
                  {/* The planet itself */}
                  <div 
                    className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer"
                    style={{ width: size, height: size }}
                  >
                    <button 
                      onClick={() => onTaskComplete(task.id)}
                      className={`w-full h-full rounded-full bg-gradient-to-br ${colorClass} shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:scale-125 hover:shadow-[0_0_25px_rgba(255,255,255,0.4)] transition-all`}
                    />
                    
                    {/* Hover Info */}
                    <div className="absolute top-full mt-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap bg-black/80 backdrop-blur-sm border border-[#333] px-3 py-1.5 rounded text-white text-[10px] pointer-events-none z-30 flex flex-col items-center">
                      <span className="font-bold">{task.title}</span>
                      <span className="text-[#888] font-mono">{task.duration}m | {task.aiOptimalTime || 'Anytime'}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </>
      )}
    </div>
  );
}
