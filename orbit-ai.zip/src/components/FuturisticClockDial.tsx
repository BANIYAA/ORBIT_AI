import React from 'react';
import { ChevronLeft, ChevronRight, Sun, Moon } from 'lucide-react';
import { synthSfx } from '../utils/audioSynth';

interface FuturisticClockDialProps {
  label: string;
  value: string; // '09:00' format (24 hour)
  onChange: (newValue: string) => void;
}

export default function FuturisticClockDial({ label, value, onChange }: FuturisticClockDialProps) {
  // Parse 24h time to 12h components
  const [hour24Str, minuteStr] = value.split(':');
  const hour24 = parseInt(hour24Str, 10);
  const minute = parseInt(minuteStr, 10);

  const ampm = hour24 >= 12 ? 'PM' : 'AM';
  let hour12 = hour24 % 12;
  if (hour12 === 0) hour12 = 12;

  const setTime = (h12: number, m: number, ap: 'AM' | 'PM') => {
    let h24 = h12 % 12;
    if (ap === 'PM') h24 += 12;
    const padH = String(h24).padStart(2, '0');
    const padM = String(m).padStart(2, '0');
    onChange(`${padH}:${padM}`);
  };

  const handleHourSelect = (h: number) => {
    synthSfx.playClickBlip();
    setTime(h, minute, ampm);
  };

  const handleAmpmToggle = () => {
    synthSfx.playSelectChord();
    const newAp = ampm === 'AM' ? 'PM' : 'AM';
    setTime(hour12, minute, newAp);
  };

  const incrementMinutes = (amount: number) => {
    synthSfx.playClickBlip();
    let newM = (minute + amount + 60) % 60;
    // Snap to 5 mins increments if clicked fine-tuning
    if (newM % 5 !== 0) {
      newM = Math.round(newM / 5) * 5 % 60;
    }
    setTime(hour12, newM, ampm);
  };

  // SVG Hour node positions (radius 70, center 100,100)
  const radius = 68;
  const cx = 100;
  const cy = 100;

  const getCoordinates = (h: number) => {
    // 12 is at top (angle -90 deg), 3 is at 0 deg, etc. Each hour is 30 deg.
    const angle = ((h * 30 - 90) * Math.PI) / 180;
    return {
      x: cx + radius * Math.cos(angle),
      y: cy + radius * Math.sin(angle),
    };
  };

  const selectedCoords = getCoordinates(hour12);

  return (
    <div className="flex flex-col items-center bg-black/40 border border-cyan-500/10 rounded-2xl p-5 hover:border-cyan-500/20 transition-all shadow-[0_0_20px_rgba(0,243,255,0.02)]">
      <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-cyan-400 mb-4">{label}</span>

      {/* Analog Clock Dial */}
      <div className="relative w-44 h-44 mb-4 select-none">
        <svg className="w-full h-full" viewBox="0 0 200 200">
          {/* Glowing Outer Ring */}
          <circle cx={cx} cy={cy} r={radius + 12} className="fill-none stroke-cyan-500/10 stroke-1" />
          <circle cx={cx} cy={cy} r={radius} className="fill-none stroke-cyan-500/5 stroke-[0.5]" />
          <circle cx={cx} cy={cy} r={6} className="fill-cyan-400" />

          {/* Hand Pointer */}
          <line
            x1={cx}
            y1={cy}
            x2={selectedCoords.x}
            y2={selectedCoords.y}
            className="stroke-cyan-400 stroke-2"
            strokeDasharray="1,1"
          />
          <circle
            cx={selectedCoords.x}
            cy={selectedCoords.y}
            r={12}
            className="fill-cyan-500/20 stroke-cyan-400 stroke-2 cursor-pointer filter drop-shadow-[0_0_6px_rgba(0,243,255,0.8)]"
          />

          {/* Hour nodes */}
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((h) => {
            const { x, y } = getCoordinates(h);
            const isSelected = h === hour12;
            return (
              <g key={h} className="cursor-pointer" onClick={() => handleHourSelect(h)}>
                {/* Bigger target area for clicks */}
                <circle cx={x} cy={y} r={14} className="fill-transparent hover:fill-white/5 transition-colors" />
                
                {/* Node indicator */}
                <circle
                  cx={x}
                  cy={y}
                  r={isSelected ? 5 : 2}
                  className={isSelected ? 'fill-cyan-400' : 'fill-cyan-400/40 hover:fill-cyan-400/80 transition-all'}
                />
                
                {/* Hour number label */}
                <text
                  x={x}
                  y={y + 3.5}
                  textAnchor="middle"
                  className={`text-[8px] font-mono select-none pointer-events-none font-bold ${
                    isSelected ? 'fill-cyan-400 font-extrabold scale-110' : 'fill-gray-600'
                  }`}
                >
                  {h}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hour/Min digital display overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-16">
          <span className="text-lg font-mono font-bold tracking-wider text-white">
            {String(hour12).padStart(2, '0')}:{String(minute).padStart(2, '0')}
          </span>
        </div>
      </div>

      {/* AM/PM Toggle and Minute Chevrons */}
      <div className="flex items-center gap-4 w-full">
        {/* Toggle Button */}
        <button
          onClick={handleAmpmToggle}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl border text-[10px] font-mono tracking-widest uppercase transition-all duration-300 cursor-pointer ${
            ampm === 'AM'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
              : 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/20'
          }`}
        >
          {ampm === 'AM' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          {ampm}
        </button>

        {/* Minutes Fine-tuning */}
        <div className="flex items-center gap-1 border border-[#222] rounded-xl px-1.5 py-1 bg-black/20">
          <button
            onClick={() => incrementMinutes(-5)}
            className="p-1 text-gray-400 hover:text-white hover:bg-white/5 rounded transition-all cursor-pointer"
            title="-5 Minutes"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono text-gray-400 px-1 w-8 text-center">MINS</span>
          <button
            onClick={() => incrementMinutes(5)}
            className="p-1 text-gray-400 hover:text-white hover:bg-white/5 rounded transition-all cursor-pointer"
            title="+5 Minutes"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
