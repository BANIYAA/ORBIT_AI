import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Loader2, X, Sparkles, Terminal, Send, HelpCircle, CornerDownLeft, Volume2, Info } from 'lucide-react';
import { Task, Habit, DailyPlanResponse, UserSettings } from '../types';
import { apiFetch } from '../utils/apiFetch';
import { speak } from '../services/voiceService';

interface VoiceAssistantProps {
  tasks: Task[];
  habits: Habit[];
  dailyPlan: DailyPlanResponse | null;
  sunTask: Task | null;
  onCommandResult: (action: string, payload: any) => { success: boolean; error?: string; message?: string; payload?: any };
  hideFloatingButton?: boolean;
  settings?: UserSettings;
  onUpdateSettings?: (settings: UserSettings) => void;
}

export default function VoiceAssistant({ tasks, habits, dailyPlan, sunTask, onCommandResult, hideFloatingButton = false, settings, onUpdateSettings }: VoiceAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [history, setHistory] = useState<{role: string, content: string}[]>([]);
  const [typedCommand, setTypedCommand] = useState('');
  
  // Keep memory to resolve "it"
  const [memory, setMemory] = useState<any>({
    lastTask: null,
    lastHabit: null,
    lastIntent: null,
    lastAction: null,
    currentTopic: null
  });

  const [debugData, setDebugData] = useState<any>(null);
  const [showDebug, setShowDebug] = useState(false);
  
  // Speech Synthesis states and permissions
  const [speechPermissionState, setSpeechPermissionState] = useState<'granted' | 'pending' | 'blocked' | 'unsupported'>('pending');

  useEffect(() => {
    if (!('speechSynthesis' in window)) {
      setSpeechPermissionState('unsupported');
    } else {
      const hasInteracted = sessionStorage.getItem('orbit_speech_authorized') === 'true';
      if (hasInteracted) {
        setSpeechPermissionState('granted');
      } else {
        setSpeechPermissionState('pending');
      }
    }
  }, []);

  const requestSpeechPermission = () => {
    if (!('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
      const utterance = new SpeechSynthesisUtterance("Voice connection established. High fidelity audio system is now fully authorized.");
      utterance.rate = settings?.voiceSpeed ?? 0.95;
      utterance.volume = settings?.voiceVolume ?? 1.0;
      
      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => v.name.includes('Google US English') || v.name.includes('Samantha') || v.name.includes('Daniel'));
      if (preferred) utterance.voice = preferred;
      
      window.speechSynthesis.speak(utterance);
      setSpeechPermissionState('granted');
      sessionStorage.setItem('orbit_speech_authorized', 'true');
      
      // Also automatically ensure voiceEnabled setting is set to true in the state
      if (settings && !settings.voiceEnabled && onUpdateSettings) {
        onUpdateSettings({ ...settings, voiceEnabled: true });
      }
    } catch (err) {
      console.error("Speech permission request error:", err);
      setSpeechPermissionState('blocked');
    }
  };

  const toggleVoiceEnabled = () => {
    if (settings && onUpdateSettings) {
      const nextVal = !settings.voiceEnabled;
      onUpdateSettings({ ...settings, voiceEnabled: nextVal });
      if (nextVal) {
        // Automatically trigger test speech to confirm to browser that interaction occurred
        setTimeout(() => {
          speakVoiceAssistant("Voice feedback is now active.", true);
        }, 150);
      }
    }
  };

  const recognitionRef = useRef<any>(null);

  const tasksRef = useRef(tasks);
  const habitsRef = useRef(habits);
  const dailyPlanRef = useRef(dailyPlan);
  const sunTaskRef = useRef(sunTask);
  const memoryRef = useRef(memory);
  const historyRef = useRef(history);

  useEffect(() => {
    tasksRef.current = tasks;
    habitsRef.current = habits;
    dailyPlanRef.current = dailyPlan;
    sunTaskRef.current = sunTask;
    memoryRef.current = memory;
    historyRef.current = history;
  }, [tasks, habits, dailyPlan, sunTask, memory, history]);

  useEffect(() => {
    // Hidden key combo to show debug panel: Shift + D
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.shiftKey && e.key === 'D') {
        setShowDebug(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const handleToggleEvent = () => {
      setIsOpen(true);
      // Wait a tiny moment to ensure state updates before starting recognition
      setTranscript('');
      setFeedback(null);
      if (!isListening) {
        try {
          recognitionRef.current?.start();
          setIsListening(true);
        } catch (e) {
          console.error("Speech start error:", e);
          setFeedback("Cannot start microphone.");
          setIsListening(false);
        }
      } else {
        recognitionRef.current?.stop();
        setIsListening(false);
      }
    };
    window.addEventListener('toggle-orbit-voice', handleToggleEvent);
    return () => window.removeEventListener('toggle-orbit-voice', handleToggleEvent);
  }, [isListening]);

  useEffect(() => {
    const event = new CustomEvent('orbit-voice-state-update', {
      detail: { isListening, isProcessing }
    });
    window.dispatchEvent(event);
  }, [isListening, isProcessing]);

  useEffect(() => {
    // Initialize Web Speech API
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const trans = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            currentTranscript += trans;
          }
        }
        if (currentTranscript) {
          setTranscript(currentTranscript);
          handleVoiceCommand(currentTranscript);
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        if (event.error !== 'no-speech') {
          console.log('Speech recognition error', event.error);
        }
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setFeedback("Microphone access denied. Please check permissions or open in a new tab.");
        } else if (event.error !== 'no-speech') {
          setFeedback("I couldn't hear that properly.");
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    } else {
      setFeedback("Speech recognition is not supported in this browser. Please use Chrome/Edge or open in a new tab.");
    }
  }, []); // Only run once on mount

  const toggleListening = () => {
    setIsOpen(true);
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      setTranscript('');
      setFeedback(null);
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (e) {
        console.error("Speech start error:", e);
        setFeedback("Cannot start microphone.");
        setIsListening(false);
      }
    }
  };

  const handleCloseModal = () => {
    setIsOpen(false);
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  const speakVoiceAssistant = (text: string, force = false) => {
    if (force) {
      speak(text, settings ? { ...settings, voiceEnabled: true } : { voiceEnabled: true, voiceSpeed: 1.0, voiceVolume: 1.0, voiceGender: 'neutral' } as any);
    } else {
      speak(text, settings || null);
    }
  };

  const handleVoiceCommand = async (command: string) => {
    setIsListening(false);
    setIsProcessing(true);
    setFeedback("Thinking...");

    try {
      const response = await apiFetch('/api/command', {
        method: 'POST',
        body: JSON.stringify({ 
          command, 
          history: historyRef.current, 
          context: { 
            currentTasks: tasksRef.current,
            currentHabits: habitsRef.current,
            dailyPlan: dailyPlanRef.current,
            sunTask: sunTaskRef.current,
            memory: memoryRef.current
          } 
        })
      });
      const data = await response.json();
      
      setHistory(prev => [...prev, { role: 'user', content: command }, { role: 'assistant', content: JSON.stringify(data) }].slice(-20));
      
      setFeedback(data.responseMessage);
      speakVoiceAssistant(data.responseMessage);
      
      const executionResult = onCommandResult(data.action, data.payload);

      // Update memory based on the execution result
      setMemory((prev: any) => ({
        ...prev,
        lastIntent: data.action,
        lastAction: executionResult.success ? 'success' : 'failed',
        lastTask: (executionResult.payload && executionResult.payload.title) || (data.payload && data.payload.title) || prev.lastTask,
        currentTopic: data.action
      }));

      setDebugData({
        transcript: command,
        detectedIntent: data.action,
        confidence: data.confidence,
        parsedJSON: data,
        executedAction: executionResult.success ? 'Success' : 'Failed',
        dbResult: executionResult.success ? (executionResult.message || 'Updated Orbit Dashboard') : (executionResult.error || 'Execution failed'),
        orbitUpdateResult: executionResult.success ? 'Synced' : 'Error',
        updatedMemory: {
          lastIntent: data.action,
          lastTask: (data.payload && data.payload.title) || memory.lastTask
        }
      });

    } catch (err) {
      const fallbackMsg = "I couldn't understand that request. Could you rephrase it?";
      setFeedback(fallbackMsg);
      speakVoiceAssistant(fallbackMsg);
      setDebugData({ error: String(err) });
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePillClick = (commandText: string) => {
    if (isProcessing) return;
    setTranscript(commandText);
    handleVoiceCommand(commandText);
  };

  const handleTypedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedCommand.trim() || isProcessing) return;
    const cmd = typedCommand;
    setTypedCommand('');
    setTranscript(cmd);
    handleVoiceCommand(cmd);
  };

  const suggestionPills = [
    { text: "What should I do now?", label: "What should I do now?" },
    { text: "Plan my day.", label: "Plan my day." },
    { text: "Add a task.", label: "Add a task" },
    { text: "How am I doing?", label: "How am I doing?" }
  ];

  return (
    <>
      {/* Dynamic Keyframes injected locally for the Celestial Planetary Orb */}
      <style>{`
        @keyframes celestial-orbit {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes celestial-spin-nebula {
          0% { transform: rotate(0deg) scale(1); }
          50% { transform: rotate(180deg) scale(1.05); }
          100% { transform: rotate(360deg) scale(1); }
        }
        @keyframes celestial-pulse-idle {
          0%, 100% { box-shadow: 0 0 15px rgba(148, 163, 184, 0.15), inset 0 0 10px rgba(255, 255, 255, 0.05); transform: scale(1); }
          50% { box-shadow: 0 0 25px rgba(148, 163, 184, 0.3), inset 0 0 15px rgba(255, 255, 255, 0.1); transform: scale(1.02); }
        }
        @keyframes celestial-pulse-listening {
          0%, 100% { box-shadow: 0 0 30px rgba(6, 182, 212, 0.5), 0 0 15px rgba(16, 185, 129, 0.3), inset 0 0 12px rgba(255, 255, 255, 0.2); transform: scale(1.04); }
          50% { box-shadow: 0 0 50px rgba(6, 182, 212, 0.8), 0 0 25px rgba(16, 185, 129, 0.5), inset 0 0 20px rgba(255, 255, 255, 0.35); transform: scale(1.1); }
        }
        @keyframes celestial-pulse-thinking {
          0%, 100% { box-shadow: 0 0 25px rgba(139, 92, 246, 0.4), 0 0 15px rgba(59, 130, 246, 0.3), inset 0 0 12px rgba(255, 255, 255, 0.1); transform: scale(1.02); }
          50% { box-shadow: 0 0 40px rgba(139, 92, 246, 0.7), 0 0 25px rgba(59, 130, 246, 0.5), inset 0 0 18px rgba(255, 255, 255, 0.2); transform: scale(1.06); }
        }
        @keyframes celestial-ripple {
          0% { transform: scale(0.9); opacity: 0.8; }
          100% { transform: scale(1.6); opacity: 0; }
        }
      `}</style>

      {/* Floating Button (when configured and closed) */}
      {!hideFloatingButton && !isOpen && (
        <div className="fixed bottom-6 right-6 z-50 pointer-events-auto">
          <button
            onClick={toggleListening}
            className="w-14 h-14 rounded-full flex items-center justify-center bg-[#0b0c10] border border-cyan-500/30 hover:border-cyan-400 text-white shadow-lg shadow-cyan-500/10 transition-all duration-300 hover:scale-105 cursor-pointer"
          >
            <Mic className="w-5 h-5 text-cyan-400" />
          </button>
        </div>
      )}

      {/* Main Simplistic Dialog Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
            {/* Soft dark backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseModal}
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            />

            {/* Simplistic Dialog Container */}
            <div className="relative w-full max-w-sm pointer-events-auto z-10">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 15 }}
                className="relative w-full bg-[#0b0c10]/95 border border-white/10 rounded-2xl shadow-2xl flex flex-col p-5 text-white"
              >
                
                {/* Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                    <span className="text-[10px] tracking-wider uppercase text-cyan-400 font-mono font-bold">ORBIT Assistant</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {/* Voice Output Status Indicator and Toggle */}
                    <button
                      type="button"
                      onClick={toggleVoiceEnabled}
                      className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 flex items-center justify-center transition-colors cursor-pointer text-white/70 hover:text-white"
                      title={settings?.voiceEnabled ? "Mute Voice Output" : "Unmute Voice Output"}
                    >
                      {settings?.voiceEnabled ? (
                        <Volume2 className="w-4 h-4 text-cyan-400" />
                      ) : (
                        <MicOff className="w-4 h-4 text-white/40" />
                      )}
                    </button>
                    {/* Close */}
                    <button 
                      onClick={handleCloseModal}
                      className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 flex items-center justify-center transition-colors cursor-pointer text-white/70 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Central Microphone / Pulse Trigger (Celestial Orb Theme) */}
                <div className="relative w-28 h-28 flex items-center justify-center mb-3 mx-auto select-none">
                  
                  {/* Dashed orbital shroud / track */}
                  <div className="absolute w-20 h-20 rounded-full border border-dashed border-cyan-500/20 pointer-events-none" />

                  {/* Active satellite moon orbiting dynamically */}
                  <div 
                    className="absolute w-20 h-20 rounded-full pointer-events-none"
                    style={{ animation: 'celestial-orbit 8s linear infinite' }}
                  >
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                  </div>

                  {/* Radiant atmospheric ripple waves when listening */}
                  {isListening && (
                    <>
                      <div className="absolute w-12 h-12 rounded-full border border-cyan-400/40 pointer-events-none" style={{ animation: 'celestial-ripple 1.8s infinite cubic-bezier(0.1, 0.8, 0.3, 1)' }} />
                      <div className="absolute w-12 h-12 rounded-full border border-emerald-400/30 pointer-events-none" style={{ animation: 'celestial-ripple 1.8s infinite cubic-bezier(0.1, 0.8, 0.3, 1) 0.9s' }} />
                    </>
                  )}

                  <button
                    onClick={() => {
                      if (isProcessing) return;
                      toggleListening();
                    }}
                    disabled={isProcessing}
                    className="relative w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 z-10 outline-none cursor-pointer overflow-hidden group border border-white/15"
                    style={{
                      background: isListening
                        ? 'radial-gradient(circle, #06b6d4 0%, #047857 60%, #064e3b 100%)' // emerald-cyan star
                        : isProcessing
                          ? 'radial-gradient(circle, #8b5cf6 0%, #4f46e5 50%, #1e1b4b 100%)' // violet-indigo nebula
                          : 'radial-gradient(circle, #475569 0%, #1e293b 60%, #0f172a 100%)', // cold dark-slate gas giant
                      animation: isListening
                        ? 'celestial-pulse-listening 2s infinite ease-in-out'
                        : isProcessing
                          ? 'celestial-pulse-thinking 2.5s infinite ease-in-out'
                          : 'celestial-pulse-idle 4s infinite ease-in-out'
                    }}
                  >
                    {/* Swirling Nebula rotational overlay for Thinking State */}
                    {isProcessing && (
                      <div 
                        className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 via-transparent to-blue-500/20 pointer-events-none mix-blend-color-dodge"
                        style={{ animation: 'celestial-spin-nebula 6s linear infinite' }}
                      />
                    )}

                    {/* Elegant subtle 3D surface glare/overlay */}
                    <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent pointer-events-none rounded-full" />
                    <div className="absolute -top-1 -left-1 w-6 h-3 bg-white/15 blur-[1px] rounded-full rotate-[-30deg] pointer-events-none" />

                    {/* Icy ring band for Idle state */}
                    {!isListening && !isProcessing && (
                      <div className="absolute w-14 h-1.5 border border-slate-400/20 rounded-full rotate-[15deg] pointer-events-none" />
                    )}

                    {/* Outer shadow/glow overlay */}
                    <div className="absolute inset-0 rounded-full shadow-inner pointer-events-none" />

                    {/* Dynamic central icon representation */}
                    <div className="relative z-20 flex items-center justify-center">
                      {isProcessing ? (
                        <Loader2 className="w-4 h-4 text-indigo-200 animate-spin drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]" />
                      ) : isListening ? (
                        <Mic className="w-4 h-4 text-cyan-100 animate-pulse drop-shadow-[0_0_6px_rgba(6,182,212,0.8)]" />
                      ) : (
                        <Mic className="w-4 h-4 text-slate-300 group-hover:text-white transition-colors duration-200" />
                      )}
                    </div>
                  </button>
                </div>

                {/* Clean SoundWave Indicator */}
                <div className="flex items-end justify-center h-4 w-full max-w-[120px] mb-4 gap-0.5 mx-auto">
                  {Array.from({ length: 15 }).map((_, i) => {
                    const duration = 0.5 + Math.random() * 0.7;
                    const delay = Math.random() * 0.3;
                    return (
                      <motion.div
                        key={i}
                        animate={{
                          height: isListening 
                            ? [3, 10 + Math.random() * 8, 3] 
                            : isProcessing 
                              ? [3, 5 + Math.random() * 4, 3] 
                              : 3
                        }}
                        transition={{
                          duration: isListening || isProcessing ? duration : 1.5,
                          repeat: Infinity,
                          ease: "easeInOut",
                          delay: delay
                        }}
                        className={`w-0.5 rounded-full transition-colors duration-300 ${
                          isListening 
                            ? 'bg-cyan-400' 
                            : isProcessing 
                              ? 'bg-indigo-400' 
                              : 'bg-white/10'
                        }`}
                        style={{ height: '3px' }}
                      />
                    );
                  })}
                </div>

                {/* Dialog response and transcript card */}
                <div className="bg-white/[0.03] border border-white/10 rounded-xl p-3 mb-4 max-h-24 overflow-y-auto relative">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[8px] tracking-widest uppercase text-white/40 font-mono font-bold">
                      {isListening ? 'Listening' : isProcessing ? 'Thinking' : 'Response'}
                    </span>
                    {!isListening && !isProcessing && feedback && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          speakVoiceAssistant(feedback, true);
                        }}
                        className="p-1 hover:bg-white/5 text-cyan-400 hover:text-cyan-300 rounded border border-white/5 transition-all cursor-pointer flex items-center gap-1 text-[8px] font-mono uppercase tracking-wider"
                        title="Read Aloud"
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>Speak</span>
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-white/95 leading-relaxed font-sans">
                    {isListening 
                      ? (transcript ? `"${transcript}"` : '"Listening... speak to ORBIT"') 
                      : isProcessing 
                        ? '"Processing request..."' 
                        : feedback 
                          ? `"${feedback}"` 
                          : '"Type or speak a command to manage your workspace."'}
                  </p>
                </div>

                {/* Minimal Suggestion Options */}
                <div className="flex flex-wrap gap-1.5 items-center justify-center mb-4">
                  {suggestionPills.map((pill, idx) => (
                    <button
                      key={idx}
                      onClick={() => handlePillClick(pill.text)}
                      disabled={isProcessing}
                      className="px-2.5 py-1 bg-white/[0.03] border border-white/10 hover:border-cyan-500/30 hover:bg-cyan-500/5 text-cyan-400 rounded-md text-[9px] uppercase font-mono tracking-wider font-semibold transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      {pill.label}
                    </button>
                  ))}
                </div>

                {/* Minimalist text alternative input bar */}
                <form onSubmit={handleTypedSubmit} className="relative group bg-white/[0.02] border border-white/10 rounded-lg pl-3 pr-1 py-1 flex items-center gap-1.5 transition-all focus-within:border-cyan-500/50 focus-within:bg-white/[0.04]">
                  <Terminal className="w-3 h-3 text-cyan-400 shrink-0" />
                  <input 
                    type="text"
                    value={typedCommand}
                    onChange={(e) => setTypedCommand(e.target.value)}
                    disabled={isProcessing}
                    placeholder="Type a command..."
                    className="bg-transparent border-none focus:ring-0 text-[11px] text-white placeholder:text-white/30 outline-none w-full py-0.5"
                  />
                  <button 
                    type="submit"
                    disabled={!typedCommand.trim() || isProcessing}
                    className="w-7 h-7 rounded-md bg-cyan-500 hover:bg-cyan-400 text-black flex items-center justify-center transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
                  >
                    <Send className="w-3 h-3" />
                  </button>
                </form>

              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Debug Panel */}
      {showDebug && debugData && (
        <div className="fixed bottom-6 right-6 z-[130] bg-[#050505]/95 backdrop-blur-xl border border-red-500/30 text-white p-4 w-[calc(100vw-48px)] sm:w-80 md:w-96 pointer-events-auto rounded-xl shadow-2xl mb-2 flex flex-col gap-2 max-h-[60vh] overflow-y-auto font-mono text-xs">
          <h3 className="text-red-400 font-bold uppercase border-b border-red-500/30 pb-1 mb-2">Voice Debug Panel</h3>
          
          <div className="flex flex-col gap-1">
            <span className="text-gray-500">Transcript:</span>
            <span className="text-green-400 break-words">{debugData.transcript || 'N/A'}</span>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-gray-500">Detected Intent:</span>
            <span className="text-yellow-400">{debugData.detectedIntent || 'N/A'}</span>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-gray-500">Confidence:</span>
            <span className="text-purple-400">{debugData.confidence !== undefined ? debugData.confidence : 'N/A'}</span>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-gray-500">Memory State:</span>
            <pre className="text-purple-300 overflow-x-auto bg-black/50 p-2 rounded">
              {JSON.stringify(debugData.updatedMemory, null, 2)}
            </pre>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-gray-500">Parsed JSON:</span>
            <pre className="text-blue-300 overflow-x-auto bg-black/50 p-2 rounded">
              {JSON.stringify(debugData.parsedJSON, null, 2)}
            </pre>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-gray-500">Executed Action:</span>
            <span className={debugData.executedAction === 'Success' ? 'text-green-400' : 'text-red-400'}>
              {debugData.executedAction || 'N/A'}
            </span>
          </div>
          
          {debugData.error && (
             <div className="flex flex-col gap-1">
              <span className="text-red-500 font-bold">Error:</span>
              <span className="text-red-400">{debugData.error}</span>
            </div>
          )}
        </div>
      )}
    </>
  );
}
