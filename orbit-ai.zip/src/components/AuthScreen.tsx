import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Play } from "lucide-react";
import { User } from "../types";
import { apiFetch } from "../utils/apiFetch";
import { googleSignIn } from "../lib/auth";

import NebulaBackground from "./3d/NebulaBackground";

interface AuthScreenProps {
  onLogin: (token: string, user: User, onboardingCompleted?: boolean) => void;
  onDemoLogin: () => void;
}

export default function AuthScreen({ onLogin, onDemoLogin }: AuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const handleResetPassword = () => {
    if (!email) {
      setError("Please enter your email terminal first.");
      setMessage("");
      return;
    }
    setError("");
    setMessage("Encryption key reset instructions transmitted to " + email);
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError("");
    try {
      const result = await googleSignIn();
      if (result) {
        // Save google token for Workspace APIs
        localStorage.setItem("google_token", result.accessToken);

        // Authenticate with backend
        const res = await apiFetch("/api/auth/google", {
          method: "POST",
          body: JSON.stringify({
            email: result.user.email,
            name: result.user.displayName,
            uid: result.user.uid,
          }),
        });

        const data = await res.json();
        if (!res.ok)
          throw new Error(data.error || "Google authentication failed");

        onLogin(data.token, data.user, data.onboardingCompleted);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!isLogin && password !== confirmPassword) {
      return setError("Passwords do not match");
    }

    setLoading(true);
    try {
      const endpoint = isLogin ? "/api/auth/login" : "/api/auth/register";
      const body = isLogin ? { email, password } : { name, email, password };

      const res = await apiFetch(endpoint, {
        method: "POST",
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Authentication failed");

      onLogin(data.token, data.user, data.onboardingCompleted);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#020204] text-[#e5e1e8] min-h-screen selection:bg-[#47d6ff]/30 font-sans overflow-x-hidden relative">
      <NebulaBackground />

      {/* Interactive Mouse Glow */}
      <div
        className="fixed pointer-events-none z-0 w-[600px] h-[600px] rounded-full blur-[120px] transition-opacity duration-1000 -translate-x-1/2 -translate-y-1/2"
        style={{
          left: mousePos.x,
          top: mousePos.y,
          backgroundColor: "rgba(165, 231, 255, 0.1)",
          opacity: 1,
        }}
      />

      <main className="relative z-10 flex flex-col md:flex-row items-center justify-center min-h-screen py-10 px-6 md:px-10 gap-12 md:gap-32">
        {/* Left Side: Identity & Description */}
        <div className="flex flex-col items-center md:items-start text-center md:text-left max-w-xl">
          <h1 className="text-5xl md:text-4xl lg:text-5xl font-bold text-[#a5e7ff] mb-3 drop-shadow-2xl animate-[pulse_4s_ease-in-out_infinite]">
            ORBIT
          </h1>
          <p className="text-lg md:text-xl font-semibold text-[#e5e1e8] mb-2">
            Your AI-Powered Universe of Productivity
          </p>
          <p className="text-xs text-[#bbc9cf] max-w-md leading-relaxed">
            Tasks, habits, scheduling and coaching powered by Gemini AI.
            Experience the silent, vast precision of a futuristic command deck.
          </p>
        </div>

        {/* Right Side: Vertical Glassmorphic Login Card */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="w-full max-w-[360px] md:max-w-[400px] animate-[float_8s_ease-in-out_infinite]"
        >
          <div className="w-full p-5 sm:p-6 md:p-8 rounded-[20px] md:rounded-[24px] bg-white/5 backdrop-blur-[30px] border border-white/[0.12] shadow-[0_25px_50px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(255,255,255,0.08)] flex flex-col relative overflow-hidden">
            <header className="mb-4 md:mb-5 text-center md:text-left">
              <h2 className="text-xl md:text-2xl font-bold text-white mb-1.5">
                {isLogin ? "Welcome Back" : "Initiate Profile"}
              </h2>
              <p className="text-[10px] text-[#8b95a7] tracking-[2px] uppercase">
                Access your intelligence hub
              </p>
            </header>

            {error && (
              <div className="p-2.5 bg-red-900/30 border border-red-500/30 rounded-lg text-red-200 text-xs text-center mb-3">
                {error}
              </div>
            )}

            {message && (
              <div className="p-2.5 bg-[#00d2ff]/10 border border-[#00d2ff]/30 rounded-lg text-[#a5e7ff] text-xs text-center mb-3">
                {message}
              </div>
            )}

            <form
              className="flex flex-col gap-3 md:gap-4"
              onSubmit={handleSubmit}
            >
              {!isLogin && (
                <div className="group">
                  <label className="block text-[#9ca3af] text-[0.65rem] md:text-[0.7rem] uppercase tracking-[2px] mb-1.5 md:mb-2">
                    Designation
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full h-[44px] md:h-[48px] px-3 md:px-4 rounded-full border border-white/10 bg-black/25 text-white text-[13px] md:text-[14px] outline-none transition-all duration-300 placeholder:text-[#6b7280] focus:border-[#22d3ee] focus:shadow-[0_0_25px_rgba(34,211,238,0.2)]"
                    placeholder="Commander Shepard"
                    required
                  />
                </div>
              )}

              <div className="group">
                <label className="block text-[#9ca3af] text-[0.65rem] md:text-[0.7rem] uppercase tracking-[2px] mb-1.5 md:mb-2">
                  Email Terminal
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-[44px] md:h-[48px] px-3 md:px-4 rounded-full border border-white/10 bg-black/25 text-white text-[13px] md:text-[14px] outline-none transition-all duration-300 placeholder:text-[#6b7280] focus:border-[#22d3ee] focus:shadow-[0_0_25px_rgba(34,211,238,0.2)]"
                  placeholder="alex@nebula.io"
                  required
                />
              </div>

              <div className="group">
                <div className="flex justify-between items-center mb-1.5 md:mb-2">
                  <label className="block text-[#9ca3af] text-[0.65rem] md:text-[0.7rem] uppercase tracking-[2px] mb-0">
                    Encryption Key
                  </label>
                  {isLogin && (
                    <button
                      type="button"
                      onClick={handleResetPassword}
                      className="text-[0.7rem] md:text-[0.75rem] text-[#22d3ee] uppercase tracking-[1px] hover:underline"
                    >
                      Lost Key?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-[44px] md:h-[48px] px-3 md:px-4 rounded-full border border-white/10 bg-black/25 text-white text-[13px] md:text-[14px] outline-none transition-all duration-300 placeholder:text-[#6b7280] focus:border-[#22d3ee] focus:shadow-[0_0_25px_rgba(34,211,238,0.2)]"
                  placeholder="••••••••"
                  required
                />
              </div>

              {!isLogin && (
                <div className="group">
                  <label className="block text-[#9ca3af] text-[0.65rem] md:text-[0.7rem] uppercase tracking-[2px] mb-1.5 md:mb-2">
                    Verify Key
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full h-[44px] md:h-[48px] px-3 md:px-4 rounded-full border border-white/10 bg-black/25 text-white text-[13px] md:text-[14px] outline-none transition-all duration-300 placeholder:text-[#6b7280] focus:border-[#22d3ee] focus:shadow-[0_0_25px_rgba(34,211,238,0.2)]"
                    placeholder="••••••••"
                    required
                  />
                </div>
              )}

              {isLogin && (
                <div className="flex items-center gap-2 mt-[-4px] mb-0">
                  <label className="flex items-center gap-[6px] text-[#9ca3af] text-[0.8rem] md:text-[0.85rem] cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-3.5 h-3.5 md:w-4 md:h-4 cursor-pointer accent-[#22d3ee]"
                    />
                    Maintain Persistence
                  </label>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full h-[44px] md:h-[48px] mt-1 rounded-full border-none bg-gradient-to-r from-[#2563eb] to-[#06b6d4] text-white text-[0.8rem] md:text-[0.85rem] font-bold tracking-[2px] uppercase shadow-[0_0_35px_rgba(6,182,212,0.35)] transition-all duration-300 hover:-translate-y-[2px] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] disabled:opacity-50 flex items-center justify-center"
              >
                {loading ? (
                  <div className="w-4 h-4 md:w-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                ) : isLogin ? (
                  "Launch Dashboard"
                ) : (
                  "Initialize"
                )}
              </button>
            </form>

            <div className="flex items-center gap-3 md:gap-[15px] my-4 md:my-[20px]">
              <div className="flex-1 h-[1px] bg-white/[0.08]"></div>
              <span className="text-[0.65rem] md:text-[0.7rem] tracking-[2px] uppercase text-[#6b7280]">
                OR CONTINUE WITH
              </span>
              <div className="flex-1 h-[1px] bg-white/[0.08]"></div>
            </div>

            <button
              onClick={handleGoogleLogin}
              type="button"
              className="w-full h-[44px] md:h-[48px] rounded-full border border-white/10 bg-white/[0.04] text-white text-[0.85rem] md:text-[0.9rem] font-semibold flex items-center justify-center gap-2 transition-all duration-300 hover:bg-white/[0.08] group"
            >
              <svg
                className="w-5 h-5 group-hover:scale-110 transition-transform"
                viewBox="0 0 48 48"
              >
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                ></path>
                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                ></path>
                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                ></path>
                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                ></path>
                <path fill="none" d="M0 0h48v48H0z"></path>
              </svg>
              <span>Continue with Google</span>
            </button>

            <button
              onClick={onDemoLogin}
              type="button"
              className="mt-2 text-[10px] tracking-widest text-[#bbc9cf] uppercase hover:text-white transition-colors"
            >
              Continue with Demo
            </button>

            <div className="mt-4 md:mt-[20px] text-center text-[#9ca3af] text-[0.75rem] md:text-[0.8rem]">
              {isLogin ? "Don't have an account?" : "Already have an account?"}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="ml-1.5 text-[#22d3ee] font-semibold hover:underline"
              >
                {isLogin ? "Sign Up" : "Log In"}
              </button>
            </div>
          </div>
        </motion.div>
      </main>

      <style>{`
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
          100% { transform: translateY(0px); }
        }
      `}</style>
    </div>
  );
}
