import React from 'react';
import { Orbit, Sparkles, TriangleAlert, ShieldCheck, CircleHelp } from 'lucide-react';

interface AIHeaderProps {
  dailyDirective: string;
  isPrioritizing: boolean;
  isFallbackMode: boolean;
  onPrioritize: () => void;
  hasTasks: boolean;
}

export default function AIHeader({
  dailyDirective,
  isPrioritizing,
  isFallbackMode,
  onPrioritize,
  hasTasks,
}: AIHeaderProps) {
  return (
    <div className="space-y-4" id="orbit-ai-header-panel">
      {/* Visual Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-4 pointer-events-auto">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center bg-black/40 backdrop-blur-md border border-white/10 w-10 h-10 rounded-full shadow-lg">
            <Orbit className="w-4 h-4 text-white/80 animate-spin" style={{ animationDuration: '30s' }} />
            <Sparkles className="w-2.5 h-2.5 text-white absolute top-1.5 right-1.5" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-[0.2em] uppercase italic text-white flex items-center gap-2 drop-shadow-md">
              Orbit OS <span className="text-[9px] bg-black/50 text-[#bbb] font-mono px-1.5 py-0.5 rounded border border-white/10 tracking-normal not-italic">v2.0.0 (3D)</span>
            </h1>
            <p className="text-[9px] uppercase tracking-widest text-[#bbb] mt-0.5 drop-shadow-sm">AI-Prioritized 3D Productivity Command Center</p>
          </div>
        </div>

        {/* Action Trigger */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            id="run-prioritization-btn"
            onClick={onPrioritize}
            disabled={isPrioritizing || !hasTasks}
            className={`w-full sm:w-auto px-4 py-2.5 border text-[9px] font-bold tracking-widest uppercase transition-colors duration-200 cursor-pointer backdrop-blur-sm rounded-lg ${
              !hasTasks
                ? 'bg-black/20 border-white/10 text-[#666] cursor-not-allowed'
                : isPrioritizing
                ? 'bg-black/50 border-white/20 text-[#999]'
                : 'bg-white/90 border-white text-black hover:bg-black/50 hover:text-white hover:border-white/50'
            }`}
          >
            {isPrioritizing ? (
              <span className="flex items-center gap-2 justify-center">
                <svg className="animate-spin h-3.5 w-3.5 text-current" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Orbiting algorithms...
              </span>
            ) : (
              <span className="flex items-center gap-2 justify-center">
                <Sparkles className="w-3.5 h-3.5" />
                Trigger Orbit Prioritizer
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Dynamic Directive Alert Box */}
      <div id="ai-strategic-directive" className="p-4 rounded-none bg-[#0a0a0a] border border-[#1a1a1a] relative overflow-hidden">
        {/* Subtle decorative layout */}
        <div className="absolute right-4 top-4 opacity-[0.02]">
          <Orbit className="w-24 h-24 text-white" />
        </div>

        <div className="relative space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-bold tracking-widest text-[#888] uppercase flex items-center gap-1.5">
              <Sparkles className="w-2.5 h-2.5 text-white" /> Orbit Strategic Directive
            </span>

            {/* Live Indicator */}
            {isFallbackMode ? (
              <span className="text-[8px] font-mono text-amber-500 bg-amber-950/10 px-2 py-0.5 border border-amber-900/30 flex items-center gap-1">
                <TriangleAlert className="w-2.5 h-2.5" /> Heuristics Engine
              </span>
            ) : (
              <span className="text-[8px] font-mono text-green-500 bg-green-950/10 px-2 py-0.5 border border-green-900/30 flex items-center gap-1">
                <ShieldCheck className="w-2.5 h-2.5" /> Gemini Engaged
              </span>
            )}
          </div>

          <p className="text-sm sm:text-base font-serif italic text-white leading-relaxed">
            "{dailyDirective}"
          </p>

          <div className="flex items-center justify-between text-[9px] text-[#555] pt-1">
            <span className="uppercase tracking-wider">Dynamic timeline resource allocation</span>
            {isFallbackMode && (
              <span className="text-amber-500 flex items-center gap-0.5 uppercase tracking-wider">
                Heuristic sorting active
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
