import React from 'react';
import { Target, Hourglass, Flame, ClipboardList } from 'lucide-react';
import { Task, Habit } from '../types';

interface MetricCardsProps {
  tasks: Task[];
  habits: Habit[];
}

export default function MetricCards({ tasks, habits }: MetricCardsProps) {
  // Task calculations
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.completed).length;
  const pendingTasks = tasks.filter((t) => !t.completed).length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Workload overhead in minutes & hours
  const remainingMinutes = tasks
    .filter((t) => !t.completed)
    .reduce((sum, t) => sum + t.duration, 0);
  const remainingHours = (remainingMinutes / 60).toFixed(1);

  // Habits calculations
  const activeHabitsCount = habits.length;
  const maxStreak = habits.reduce((max, h) => Math.max(max, h.streak), 0);
  const allTimeBestStreak = habits.reduce((max, h) => Math.max(max, h.bestStreak), 0);

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="stats-dashboard-grid">
      {/* Metric 1: Completion */}
      <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-5 rounded-none flex items-center gap-4 transition-all hover:border-[#333333]">
        <div className="p-2 bg-[#111111] text-[#e0e0e0] border border-[#222222] shrink-0">
          <Target className="w-5 h-5" />
        </div>
        <div>
          <span className="text-[10px] text-[#555] font-bold uppercase tracking-widest block">
            Resolution Rate
          </span>
          <span className="text-2xl font-light font-mono text-white block mt-0.5">
            {completionRate}%
          </span>
          <span className="text-[9px] text-[#888] font-mono block">
            {completedTasks} / {totalTasks} completed
          </span>
        </div>
      </div>

      {/* Metric 2: Estimated Workload */}
      <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-5 rounded-none flex items-center gap-4 transition-all hover:border-[#333333]">
        <div className="p-2 bg-[#111111] text-[#e0e0e0] border border-[#222222] shrink-0">
          <Hourglass className="w-5 h-5" />
        </div>
        <div>
          <span className="text-[10px] text-[#555] font-bold uppercase tracking-widest block">
            Attention Budget
          </span>
          <span className="text-2xl font-light font-mono text-white block mt-0.5">
            {remainingHours}h
          </span>
          <span className="text-[9px] text-[#888] font-mono block">
            {remainingMinutes}m remaining time
          </span>
        </div>
      </div>

      {/* Metric 3: Habit Streak */}
      <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-5 rounded-none flex items-center gap-4 transition-all hover:border-[#333333]">
        <div className="p-2 bg-[#111111] text-[#e0e0e0] border border-[#222222] shrink-0">
          <Flame className="w-5 h-5" />
        </div>
        <div>
          <span className="text-[10px] text-[#555] font-bold uppercase tracking-widest block">
            Consistency Streak
          </span>
          <span className="text-2xl font-light font-mono text-white block mt-0.5">
            {maxStreak}d
          </span>
          <span className="text-[9px] text-[#888] font-mono block">
            Peak record: {allTimeBestStreak}d
          </span>
        </div>
      </div>

      {/* Metric 4: Audit Registry */}
      <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-5 rounded-none flex items-center gap-4 transition-all hover:border-[#333333]">
        <div className="p-2 bg-[#111111] text-[#e0e0e0] border border-[#222222] shrink-0">
          <ClipboardList className="w-5 h-5" />
        </div>
        <div>
          <span className="text-[10px] text-[#555] font-bold uppercase tracking-widest block">
            Active Core Node
          </span>
          <span className="text-2xl font-light font-mono text-white block mt-0.5">
            {pendingTasks + activeHabitsCount}
          </span>
          <span className="text-[9px] text-[#888] font-mono block">
            {pendingTasks} tasks • {activeHabitsCount} habits
          </span>
        </div>
      </div>
    </div>
  );
}
