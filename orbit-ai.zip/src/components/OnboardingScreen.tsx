import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Rocket, 
  Target, 
  Clock, 
  Zap, 
  ArrowRight, 
  Brain, 
  Volume2, 
  VolumeX, 
  Terminal, 
  ShieldAlert, 
  Cpu, 
  Activity,
  Compass
} from 'lucide-react';
import { apiFetch } from '../utils/apiFetch';
import Onboarding3DScene from './Onboarding3DScene';
import FuturisticClockDial from './FuturisticClockDial';
import { synthSfx } from '../utils/audioSynth';

interface OnboardingScreenProps {
  onComplete: (preferences: any) => void;
}

export default function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  // Step 0: Boot Sequence, Step 1: Welcome, Step 2: Work Parameters, Step 3: Focus Engine, Step 4: Warp Speed Leaping
  const [step, setStep] = useState(0);
  const [focusDuration, setFocusDuration] = useState(45);
  const [workHours, setWorkHours] = useState({ start: '09:00', end: '17:00' });
  const [loading, setLoading] = useState(false);
  const [isWarping, setIsWarping] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Boot sequence logs
  const [bootLogs, setBootLogs] = useState<string[]>([]);
  const [bootLogIndex, setBootLogIndex] = useState(0);
  const [bootFinished, setBootFinished] = useState(false);

  const logsSequence = [
    { text: 'LOADING ORBIT SYSTEM V2.0.0...', type: 'info' },
    { text: 'ESTABLISHING SECURE COGNITIVE DEEP SPACE RELAY...', type: 'info' },
    { text: 'CALIBRATING QUANTUM GRAVITY COILS... [ONLINE]', type: 'success' },
    { text: 'LINKING NEURAL CORE PILOT PROXY... [CONNECTED]', type: 'success' },
    { text: 'MEASURING TEMPORAL STELLAR WORKPLACE SLOTS... [100%]', type: 'success' },
    { text: 'READY FOR COMMAND SIGNATURE. PROCEED CHAIR MANIFEST.', type: 'alert' }
  ];

  // Warp messages scrolling
  const [warpLogs, setWarpLogs] = useState<string[]>([]);

  // Speech synthesis reference
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Handle Speech Synthesis TTS
  const speakText = (text: string) => {
    if (!voiceEnabled) return;
    try {
      window.speechSynthesis.cancel(); // Stop current speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 0.95; // slightly robotic, commanding spacecraft voice
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      
      speechRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis not fully supported or blocked:', err);
    }
  };

  // Typewriter boot sequence
  useEffect(() => {
    if (step === 0) {
      if (bootLogIndex < logsSequence.length) {
        const timer = setTimeout(() => {
          setBootLogs(prev => [...prev, logsSequence[bootLogIndex].text]);
          synthSfx.playBootBeep();
          setBootLogIndex(prev => prev + 1);
        }, 600);
        return () => clearTimeout(timer);
      } else {
        setBootFinished(true);
        speakText("Welcome pilot. Click start calibration to initialize spacecraft systems.");
      }
    }
  }, [step, bootLogIndex]);

  // Voice introduction when steps change
  const handleStepTransition = (nextStep: number) => {
    synthSfx.playSelectChord();
    setStep(nextStep);

    if (nextStep === 1) {
      speakText("Welcome to Orbit. Your AI-powered deep space operating system. We will now calibrate your system parameters.");
    } else if (nextStep === 2) {
      speakText("Calibration step two: Work Parameters. Define your optimal operating hours on the radial dial.");
    } else if (nextStep === 3) {
      speakText("Calibration step three: Focus Engine. Select your preferred capsule for deep work duration.");
    }
  };

  const startWarpJump = async () => {
    setIsWarping(true);
    setStep(4);
    synthSfx.playWarpCharge();
    speakText("Engaging hyper-speed warp stabilizers. Launching Orbit Operating System now. Prepare for leap.");

    // Warp sequence logs scrolling
    const warpMsgs = [
      'INITIATING SPACE JUMP PROTOCOL...',
      'QUANTUM ENGINE THRUSTER AT 150%...',
      'DILATING SPACE TIME METRIC... [OK]',
      'WARPING COORDS TO SYSTEM HUD DRIFT...',
      'LANDING COGNITIVE ORBIT ENGINE...'
    ];

    warpMsgs.forEach((msg, idx) => {
      setTimeout(() => {
        setWarpLogs(prev => [...prev, msg]);
        synthSfx.playBootBeep();
      }, idx * 450);
    });

    try {
      const preferences = { focusDuration, workHours };
      await apiFetch('/api/onboarding', {
        method: 'POST',
        body: JSON.stringify({ preferences })
      });

      // Complete jump after logs print and sound finishes
      setTimeout(() => {
        synthSfx.playSuccessChime();
        onComplete(preferences);
      }, 2600);

    } catch (err) {
      console.error(err);
      // Fallback transition
      setTimeout(() => {
        onComplete({ focusDuration, workHours });
      }, 2600);
    }
  };

  return (
    <div className="min-h-screen bg-[#020408] text-white flex flex-col md:flex-row relative overflow-hidden font-sans">
      
      {/* 3D Interactive Canvas Scene taking up left part (or full on mobile background) */}
      <div className="w-full md:w-[55%] h-[40vh] md:h-screen relative z-0">
        <Onboarding3DScene step={step} isWarping={isWarping} isSpeaking={isSpeaking} />
        
        {/* Absolute top badge overlay on canvas */}
        <div className="absolute top-5 left-5 z-10 flex items-center gap-2 bg-black/40 border border-cyan-500/20 backdrop-blur-md px-3.5 py-1.5 rounded-full">
          <Activity className={`w-4 h-4 text-cyan-400 ${isSpeaking ? 'animate-pulse' : ''}`} />
          <span className="text-[9px] font-mono uppercase tracking-[0.25em] text-cyan-300">
            {isSpeaking ? 'PILOT VOICE RELAY ACTIVE' : 'AI SPACE VOYAGER COGNITIVE LINK'}
          </span>
        </div>
      </div>

      {/* Holographic Right HUD Controls Side Panel */}
      <div className="w-full md:w-[45%] h-[60vh] md:h-screen flex flex-col justify-between p-6 sm:p-10 relative z-10 border-t md:border-t-0 md:border-l border-cyan-500/10 bg-radial-gradient from-[#02050e]/95 via-[#030308]/98 to-[#010103] backdrop-blur-md">
        
        {/* HUD Top bar */}
        <div className="flex items-center justify-between border-b border-cyan-500/10 pb-4">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400 animate-spin-slow" />
            <div>
              <h1 className="text-sm font-mono font-bold uppercase tracking-wider text-white">ORBIT PILOT INTERFACE</h1>
              <p className="text-[9px] font-mono text-cyan-400/60 uppercase">CALIBRATION ENGINE ACTIVE</p>
            </div>
          </div>

          {/* Polite Voice Speech Toggle with Visual Feedback */}
          <button
            onClick={() => {
              synthSfx.playClickBlip();
              setVoiceEnabled(!voiceEnabled);
              if (voiceEnabled) window.speechSynthesis.cancel();
            }}
            className={`flex items-center gap-2 border px-3 py-1.5 rounded-full transition-all text-[9px] font-mono uppercase tracking-wider cursor-pointer ${
              voiceEnabled 
                ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/20' 
                : 'bg-transparent border-white/10 text-gray-500 hover:border-white/20'
            }`}
          >
            {voiceEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                <span>Voice: On</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5" />
                <span>Voice: Muted</span>
              </>
            )}
          </button>
        </div>

        {/* Core Wizard Container */}
        <div className="flex-1 flex items-center justify-center my-6">
          <div className="w-full max-w-md">
            
            <AnimatePresence mode="wait">
              
              {/* Step 0: Holographic Typewriter Boot Sequence */}
              {step === 0 && (
                <motion.div
                  key="boot"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-6"
                >
                  <div className="bg-black/60 border border-cyan-500/20 rounded-2xl p-6 font-mono text-[11px] space-y-3 leading-relaxed relative overflow-hidden shadow-[0_0_25px_rgba(0,243,255,0.03)]">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
                    
                    <div className="flex items-center justify-between text-cyan-400 border-b border-cyan-500/10 pb-2 mb-2">
                      <div className="flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5" />
                        <span>BOOT_SEQUENCE_MANIFEST.LOG</span>
                      </div>
                      <span className="text-[8px] animate-pulse">● ENGINE_READY</span>
                    </div>

                    <div className="space-y-2">
                      {bootLogs.map((log, i) => (
                        <div key={i} className="flex items-start gap-1.5">
                          <span className="text-cyan-500 select-none">&gt;</span>
                          <span className={log.includes('[ONLINE]') || log.includes('[CONNECTED]') ? 'text-emerald-400 font-semibold' : 'text-gray-300'}>
                            {log}
                          </span>
                        </div>
                      ))}
                    </div>

                    {!bootFinished && (
                      <div className="flex items-center gap-1 text-cyan-400 animate-pulse mt-4">
                        <span className="w-1.5 h-3 bg-cyan-400" />
                        <span className="text-[9px]">CALIBRATING_PROXIES...</span>
                      </div>
                    )}
                  </div>

                  {bootFinished && (
                    <motion.button
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleStepTransition(1)}
                      className="w-full bg-linear-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-black font-mono text-xs uppercase tracking-widest py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,243,255,0.25)] border border-cyan-400/40 cursor-pointer"
                    >
                      <span>Enter Spacecraft Command Chair</span>
                      <ArrowRight className="w-4 h-4 text-black" />
                    </motion.button>
                  )}
                </motion.div>
              )}

              {/* Step 1: Welcome to spaceship command */}
              {step === 1 && (
                <motion.div
                  key="welcome"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8 text-center"
                >
                  <div className="inline-flex p-5 bg-gradient-to-tr from-cyan-500/20 to-indigo-500/20 rounded-full border border-cyan-500/30 filter drop-shadow-[0_0_15px_rgba(0,243,255,0.15)] relative">
                    <Rocket className="w-10 h-10 text-cyan-400 animate-pulse" />
                    <div className="absolute inset-0 border border-indigo-500/30 rounded-full animate-ping scale-110 opacity-30 pointer-events-none" />
                  </div>
                  
                  <div>
                    <h2 className="text-2xl font-mono font-black tracking-wide text-white uppercase">
                      Welcome pilot
                    </h2>
                    <p className="text-gray-400 leading-relaxed font-mono text-xs mt-3">
                      Your high-fidelity neural proxy interface has loaded. We will calibrate your operating parameters to optimize deep cosmic focus streaks.
                    </p>
                  </div>

                  <button
                    onClick={() => handleStepTransition(2)}
                    className="w-full bg-white text-black hover:bg-gray-100 font-mono text-xs uppercase tracking-widest py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 hover:shadow-[0_0_15px_rgba(255,255,255,0.15)] cursor-pointer"
                  >
                    Start Systems Calibration
                    <ArrowRight className="w-4 h-4 text-black" />
                  </button>
                </motion.div>
              )}

              {/* Step 2: Work Parameters (Two dial-linked clockfaces) */}
              {step === 2 && (
                <motion.div
                  key="hours"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center">
                    <div className="inline-flex p-3 bg-cyan-500/10 rounded-full border border-cyan-500/20 mb-3">
                      <Clock className="w-6 h-6 text-cyan-400" />
                    </div>
                    <h2 className="text-xl font-mono font-bold uppercase tracking-wider text-white">Stellar Work Slot</h2>
                    <p className="text-gray-400 font-mono text-[10px] mt-1">CALIBRATE YOUR TEMPORAL ORBIT WINDOWS</p>
                  </div>

                  {/* Two futuristic radial SVG linked clocks */}
                  <div className="grid grid-cols-2 gap-4">
                    <FuturisticClockDial
                      label="Day Start Hour"
                      value={workHours.start}
                      onChange={(val) => setWorkHours({ ...workHours, start: val })}
                    />
                    <FuturisticClockDial
                      label="Day End Hour"
                      value={workHours.end}
                      onChange={(val) => setWorkHours({ ...workHours, end: val })}
                    />
                  </div>

                  <button
                    onClick={() => handleStepTransition(3)}
                    className="w-full bg-linear-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-black font-mono text-xs uppercase tracking-widest py-3.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,243,255,0.1)] cursor-pointer"
                  >
                    Confirm Temporal Slots
                    <ArrowRight className="w-4 h-4 text-black" />
                  </button>
                </motion.div>
              )}

              {/* Step 3: Focus Engine (3D Floating interactive capsules with scanlines) */}
              {step === 3 && (
                <motion.div
                  key="focus"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center">
                    <div className="inline-flex p-3 bg-purple-500/10 rounded-full border border-purple-500/20 mb-3">
                      <Brain className="w-6 h-6 text-purple-400" />
                    </div>
                    <h2 className="text-xl font-mono font-bold uppercase tracking-wider text-white">Quantum Focus Engine</h2>
                    <p className="text-gray-400 font-mono text-[10px] mt-1">CHOOSE YOUR FOCUS SESSION AMPLITUDE</p>
                  </div>

                  {/* Floating capsules with glowing border & scanlines */}
                  <div className="space-y-3">
                    {[25, 45, 60, 90].map((duration) => {
                      const isSelected = focusDuration === duration;
                      return (
                        <motion.button
                          key={duration}
                          onClick={() => {
                            synthSfx.playSelectChord();
                            setFocusDuration(duration);
                          }}
                          whileHover={{ scale: 1.01, x: 4 }}
                          className={`w-full py-4 px-6 rounded-2xl border relative overflow-hidden transition-all duration-300 text-left flex items-center justify-between cursor-pointer ${
                            isSelected 
                              ? 'bg-gradient-to-r from-purple-500/20 via-indigo-500/10 to-transparent border-purple-500 text-purple-200 shadow-[0_0_20px_rgba(157,0,255,0.15)]' 
                              : 'bg-black/40 border-white/5 text-gray-400 hover:border-purple-500/30 hover:text-white'
                          }`}
                        >
                          {/* Scanline subtle scrolling grid overlay */}
                          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_4px,3px_100%] pointer-events-none opacity-20" />
                          
                          <div className="flex items-center gap-3">
                            <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-purple-400 animate-pulse' : 'bg-gray-600'}`} />
                            <span className="font-mono text-xs font-bold uppercase tracking-wider">{duration} Stellar Minutes</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-mono opacity-50">
                              {duration === 25 ? 'STANDARD_POMODORO' : duration === 45 ? 'COGNITIVE_OPTIMAL' : duration === 60 ? 'DEEP_DILATION' : 'FLOW_STATE_MAX'}
                            </span>
                            {isSelected && <Zap className="w-4 h-4 text-purple-400 animate-bounce" />}
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>

                  <button
                    onClick={startWarpJump}
                    disabled={loading}
                    className="w-full bg-linear-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-mono text-xs uppercase tracking-widest py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(157,0,255,0.3)] border border-purple-400/30 cursor-pointer"
                  >
                    <span>Initialize Orbit AI Interface</span>
                  </button>
                </motion.div>
              )}

              {/* Step 4: Cinematic Warp Speed Flight logs */}
              {step === 4 && (
                <motion.div
                  key="warp"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="text-center py-4">
                    <div className="inline-flex p-3 bg-amber-500/15 rounded-full border border-amber-500/30 animate-spin-slow mb-3">
                      <Compass className="w-6 h-6 text-amber-400" />
                    </div>
                    <h2 className="text-xl font-mono font-black uppercase tracking-[0.25em] text-amber-500 animate-pulse">WARP SPEED LEAP</h2>
                    <p className="text-gray-400 font-mono text-[9px] mt-1 uppercase tracking-widest">DIFFERENTIATING SPATIAL GRID VECTORS</p>
                  </div>

                  <div className="bg-black/80 border border-amber-500/20 rounded-2xl p-6 font-mono text-[10px] space-y-2.5 leading-relaxed shadow-[0_0_30px_rgba(245,158,11,0.05)]">
                    <div className="flex items-center justify-between text-amber-400 border-b border-amber-500/10 pb-2 mb-2">
                      <span>ORBIT_HYPERLEAP.LOG</span>
                      <span className="animate-ping">● LEAP_ENGAGED</span>
                    </div>

                    <div className="space-y-1.5 min-h-24">
                      {warpLogs.map((log, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <span className="text-amber-500 select-none">&gt;</span>
                          <span className="text-gray-200 font-bold uppercase">{log}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

            </AnimatePresence>
          </div>
        </div>

        {/* Orbital Progress Nodes Timeline in footer of panel */}
        <div className="border-t border-cyan-500/10 pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
            <span className="text-[8px] font-mono text-cyan-400/60 uppercase tracking-widest">GPS_COORD: ORBIT_PILOT_ALPHA</span>
          </div>

          {/* SVG Orbital rings connected by lasers */}
          <div className="flex items-center gap-2 select-none">
            <svg className="w-32 h-6" viewBox="0 0 120 20">
              {/* Connected active laser lines */}
              <line 
                x1={10} y1={10} x2={60} y2={10} 
                className={`stroke-2 transition-all duration-500 ${step >= 2 ? 'stroke-cyan-400' : 'stroke-white/10'}`} 
              />
              <line 
                x1={60} y1={10} x2={110} y2={10} 
                className={`stroke-2 transition-all duration-500 ${step >= 3 ? 'stroke-purple-500' : 'stroke-white/10'}`} 
              />

              {/* Orbital node 1 */}
              <circle cx={10} cy={10} r={6} className="fill-black stroke-cyan-400/40 stroke-1" />
              <circle 
                cx={10} cy={10} 
                r={step >= 1 ? 4 : 2} 
                className={`transition-all duration-300 ${step >= 1 ? 'fill-cyan-400' : 'fill-gray-600'}`} 
              />

              {/* Orbital node 2 */}
              <circle cx={60} cy={10} r={6} className="fill-black stroke-cyan-400/40 stroke-1" />
              <circle 
                cx={60} cy={10} 
                r={step >= 2 ? 4 : 2} 
                className={`transition-all duration-300 ${step >= 2 ? 'fill-cyan-400' : 'fill-gray-600'}`} 
              />

              {/* Orbital node 3 */}
              <circle cx={110} cy={10} r={6} className="fill-black stroke-purple-500/40 stroke-1" />
              <circle 
                cx={110} cy={10} 
                r={step >= 3 ? 4 : 2} 
                className={`transition-all duration-300 ${step >= 3 ? 'fill-purple-500 animate-pulse' : 'fill-gray-600'}`} 
              />
            </svg>
            <span className="text-[9px] font-mono text-gray-500 font-bold">
              {step === 0 ? 'BOOT' : step === 4 ? 'WARP' : `0${step}/03`}
            </span>
          </div>
        </div>

      </div>
    </div>
  );
}
