import React, { useEffect, useState } from 'react';
import { Activity, Server, Zap, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { apiFetch } from '../utils/apiFetch';

interface AIMetrics {
  requests: number;
  geminiSuccess: number;
  openrouterSuccess: number;
  mistralSuccess: number;
  ruleEngineFallback: number;
  totalLatency: number;
  failures: number;
}

interface ProviderHealth {
  configured: boolean;
  healthy: boolean;
  latency: number;
}

interface AIHealthData {
  gemini: ProviderHealth;
  openrouter: ProviderHealth;
  mistral: ProviderHealth;
  routingPriority: string[];
  usageMetrics: AIMetrics;
  healthMetrics: {
    status: 'healthy' | 'degraded';
  };
}

export default function AIHealthMonitor() {
  const [data, setData] = useState<AIHealthData | null>(null);
  const [expanded, setExpanded] = useState(false);

  const fetchHealth = async () => {
    try {
      const res = await apiFetch('/api/health/ai');
      if (res.ok) {
        setData(await res.json());
      }
    } catch (err) {
      console.log("Failed to fetch AI health", err);
    }
  };

  useEffect(() => {
    fetchHealth();
    const interval = setInterval(fetchHealth, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleResetCooldown = async () => {
    try {
      await apiFetch('/api/health/ai/reset', { method: 'POST' });
      fetchHealth();
    } catch (err) {
      console.log("Failed to reset cooldown", err);
    }
  };

  if (!data) return null;

  const { gemini, openrouter, mistral, usageMetrics, healthMetrics, routingPriority } = data;
  const metrics = usageMetrics;
  const status = healthMetrics.status;

  const getSuccessRate = (successes: number) => {
    if (metrics.requests === 0) return "100%";
    return Math.round((successes / metrics.requests) * 100) + "%";
  };

  const renderProviderInfo = (name: string, model: string, health: ProviderHealth, successes: number) => {
    const isHealthy = health.configured && health.healthy;
    return (
      <div className="mb-3">
        <div className="flex items-center gap-1.5 mb-1">
          {isHealthy ? <span className="text-emerald-400">🟢</span> : (health.configured ? <span className="text-orange-400">🟠</span> : <span className="text-red-400">🔴</span>)}
          <span className="font-semibold text-gray-200">{name}</span>
        </div>
        <div className="pl-6 space-y-0.5 text-gray-400 text-[11px]">
          <div>Model: {model}</div>
          <div>Latency: {health.latency > 0 ? (health.latency / 1000).toFixed(1) + 's' : 'N/A'}</div>
          <div>Success: {getSuccessRate(successes)}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed bottom-4 left-4 z-50 font-mono text-xs">
      <div 
        onClick={() => setExpanded(!expanded)}
        className={`flex items-center gap-2 px-3 py-2 rounded-full cursor-pointer backdrop-blur-md border transition-all duration-300 shadow-lg ${
          status === 'healthy' 
            ? 'bg-black/40 border-white/10 text-gray-300 hover:text-white' 
            : 'bg-orange-500/20 border-orange-500/50 text-orange-200'
        }`}
      >
        {status === 'healthy' ? <CheckCircle2 size={14} className="text-emerald-400" /> : <AlertTriangle size={14} className="text-orange-400" />}
        <span className="font-semibold tracking-wide uppercase">AI Engine {status}</span>
        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-1" />
      </div>

      {expanded && (
        <div className="absolute bottom-full mb-3 left-0 w-72 bg-gray-950/90 backdrop-blur-xl border border-white/10 rounded-xl p-4 shadow-2xl text-gray-300 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-between items-center mb-3 pb-3 border-b border-white/10">
             <div className="flex items-center gap-2">
                <Zap size={16} className="text-indigo-400" />
                <h3 className="text-sm font-semibold text-white tracking-wide">AI Health Dashboard</h3>
             </div>
             {metrics.failures > 0 && (
                <button 
                onClick={(e) => {
                    e.stopPropagation();
                    handleResetCooldown();
                }}
                className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded hover:bg-indigo-500/40 transition-colors text-[10px]"
                >
                Reset
                </button>
             )}
          </div>
          
          <div className="space-y-1">
             {renderProviderInfo("Gemini", "gemini-2.5-flash", gemini, metrics.geminiSuccess)}
             {renderProviderInfo("OpenRouter", "openrouter/free", openrouter, metrics.openrouterSuccess)}
             {renderProviderInfo("Mistral", "mistral-large-latest", mistral, metrics.mistralSuccess)}
             
             <div className="mb-3">
               <div className="flex items-center gap-1.5 mb-1">
                 <span className="text-emerald-400">🟢</span>
                 <span className="font-semibold text-gray-200">Offline Engine</span>
               </div>
               <div className="pl-6 space-y-0.5 text-gray-400 text-[11px]">
                 <div>Model: local-rule-engine</div>
                 <div>Latency: &lt;0.1s</div>
                 <div>Usage: {getSuccessRate(metrics.ruleEngineFallback)}</div>
               </div>
             </div>
          </div>
          
          <div className="mt-4 pt-3 border-t border-white/10 flex flex-col gap-1.5">
            <div className="text-[10px] text-gray-500 font-semibold mb-1">ROUTING PRIORITY:</div>
            <div className="flex items-center gap-1 text-[10px] text-gray-400 flex-wrap">
                {routingPriority.map((p, i) => (
                    <React.Fragment key={p}>
                        <span className="bg-white/5 px-1.5 py-0.5 rounded">{p}</span>
                        {i < routingPriority.length - 1 && <span>→</span>}
                    </React.Fragment>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
