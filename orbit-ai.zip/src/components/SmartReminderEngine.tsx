import React, { useEffect, useRef } from 'react';
import { Task, Habit, DailyPlanResponse, UserSettings, ReflectionData } from '../types';
import { apiFetch } from '../utils/apiFetch';
import { speak, notify } from '../services/voiceService';

interface SmartReminderEngineProps {
  tasks: Task[];
  habits: Habit[];
  dailyPlan: DailyPlanResponse | null;
  settings: UserSettings;
  reflections: ReflectionData[];
}

export default function SmartReminderEngine({ tasks, habits, dailyPlan, settings, reflections }: SmartReminderEngineProps) {
  const lastBriefingDate = useRef<string | null>(null);
  const lastEveningReviewDate = useRef<string | null>(null);
  const notifiedTaskIds = useRef<Set<string>>(new Set());

  useEffect(() => {
    // Only run if either voice or notifications are enabled
    if (!settings.voiceEnabled && !settings.notificationsEnabled) return;

    const checkReminders = async () => {
      const now = new Date();
      const currentHour = now.getHours();
      const todayString = now.toISOString().split('T')[0];

      // 1. Morning Briefing
      if (settings.morningBriefingEnabled && currentHour >= 6 && currentHour < 12 && lastBriefingDate.current !== todayString) {
        lastBriefingDate.current = todayString;
        
        // Fetch briefing from server
        try {
          const res = await apiFetch('/api/reminders/briefing', {
            method: 'POST',
            body: JSON.stringify({ tasks, dailyPlan })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.message) {
              speak(data.message, settings);
              notify("Morning Briefing", data.message, settings.notificationsEnabled);
            }
          }
        } catch (e) {
          console.error("Failed to generate morning briefing:", e);
        }
      }

      // 2. Evening Review
      if (settings.eveningReviewEnabled && currentHour >= 20 && lastEveningReviewDate.current !== todayString) {
        lastEveningReviewDate.current = todayString;
        
        try {
          const res = await apiFetch('/api/reminders/review', {
            method: 'POST',
            body: JSON.stringify({ tasks, habits, reflections })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.message) {
              speak(data.message, settings);
              notify("Evening Review", data.message, settings.notificationsEnabled);
            }
          }
        } catch (e) {
          console.error("Failed to generate evening review:", e);
        }
      }

      // 3. Task Reminders (Upcoming & Overdue)
      const upcomingThresholdMs = 2 * 60 * 60 * 1000; // 2 hours
      for (const task of tasks) {
        if (task.completed) continue;
        
        const deadlineDate = new Date(task.deadline);
        const timeDiff = deadlineDate.getTime() - now.getTime();
        
        // Skip if already notified for this task state (using a composite key)
        const isOverdue = timeDiff < 0;
        const notifKey = `${task.id}-${isOverdue ? 'overdue' : 'upcoming'}`;
        
        if (notifiedTaskIds.current.has(notifKey)) continue;

        // Trigger if overdue by less than 1 hour OR upcoming within 2 hours
        if ((isOverdue && timeDiff > -3600000) || (!isOverdue && timeDiff > 0 && timeDiff <= upcomingThresholdMs)) {
          // Limit frequency based on settings
          if (settings.reminderFrequency === 'low' && !isOverdue && task.importance !== 'high') {
            continue; // Low frequency only alerts for high importance upcoming tasks
          }

          notifiedTaskIds.current.add(notifKey);
          
          try {
            const res = await apiFetch('/api/reminders/task', {
              method: 'POST',
              body: JSON.stringify({ task, isOverdue })
            });
            if (res.ok) {
              const data = await res.json();
              if (data.message) {
                speak(data.message, settings);
                notify(isOverdue ? "Overdue Task" : "Upcoming Task", data.message, settings.notificationsEnabled);
              }
            }
          } catch (e) {
             console.error("Failed to generate task reminder:", e);
          }
        }
      }
      
      // 4. Habit Streak Risk
      if (currentHour >= 18) { // After 6 PM, check for habits at risk
        for (const habit of habits) {
          if (habit.frequency === 'daily' && !habit.completedDays.includes(todayString)) {
            const habitKey = `${habit.id}-streak-${todayString}`;
            if (!notifiedTaskIds.current.has(habitKey) && habit.streak > 0) {
              notifiedTaskIds.current.add(habitKey);
              const msg = `Your ${habit.title} streak is currently ${habit.streak} days. Missing today will reset the streak.`;
              speak(msg, settings);
              notify("Habit at Risk", msg, settings.notificationsEnabled);
            }
          }
        }
      }
      
      // 5. Journal Reflection Reminder (After 8 PM if not done)
      if (currentHour >= 20) {
        const hasReflectedToday = reflections.some(r => r.date.startsWith(todayString));
        if (!hasReflectedToday) {
          const refKey = `reflection-${todayString}`;
          if (!notifiedTaskIds.current.has(refKey)) {
            notifiedTaskIds.current.add(refKey);
            const msg = "You have not completed today's reflection. Recording your progress improves AI coaching accuracy.";
            speak(msg, settings);
            notify("Reflection Reminder", msg, settings.notificationsEnabled);
          }
        }
      }

    };

    // Run immediately, then every 5 minutes (300000 ms)
    // Using 1 minute (60000 ms) for development responsiveness
    checkReminders();
    const interval = setInterval(checkReminders, 60000);
    
    return () => clearInterval(interval);
  }, [tasks, habits, dailyPlan, settings, reflections]);

  return null;
}
