import React, { useState } from 'react';
import { Sparkles, MessageSquareHeart } from 'lucide-react';
import { Task, Habit } from '../types';
import { apiFetch } from '../utils/apiFetch';

interface AICoachCardProps {
  tasks: Task[];
  habits: Habit[];
}

export default function AICoachCard({ tasks, habits }: AICoachCardProps) {
  const [coachData, setCoachData] = useState<{ motivation: string; recommendation: string; observation: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const askCoach = async () => {
    setLoading(true);
    try {
      const response = await apiFetch('/api/coach', {
        method: 'POST',
        body: JSON.stringify({ tasks, habits })
      });
      const data = await response.json();
      setCoachData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-none p-5 mt-8 relative overflow-hidden group">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-bold tracking-widest text-[11px] uppercase flex items-center gap-2">
          <MessageSquareHeart className="w-4 h-4 text-emerald-500" />
          Orbit AI Coach
        </h3>
        <button
          onClick={askCoach}
          disabled={loading}
          className="text-[9px] uppercase tracking-wider bg-[#1a1a1a] hover:bg-[#222] border border-[#333] text-white px-3 py-1.5 transition-colors cursor-pointer disabled:opacity-50"
        >
          {loading ? 'Analyzing...' : 'Get Coaching'}
        </button>
      </div>

      {coachData ? (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
          <div className="bg-[#111] border border-[#222] p-4 text-sm text-[#ddd]">
            <p className="font-serif italic text-emerald-400 mb-2">"{typeof coachData.motivation === 'object' ? JSON.stringify(coachData.motivation) : coachData.motivation}"</p>
            <div className="space-y-2 mt-4 text-[11px] tracking-wide">
              <p><strong className="text-white">Observation:</strong> {typeof coachData.observation === 'object' ? JSON.stringify(coachData.observation) : coachData.observation}</p>
              <p><strong className="text-white">Recommendation:</strong> {typeof coachData.recommendation === 'object' ? JSON.stringify(coachData.recommendation) : coachData.recommendation}</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-[#555] text-[11px] tracking-wide italic">
          Coach is on standby. Request an analysis to get personalized insights on your workload.
        </div>
      )}
    </div>
  );
}
