import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Activity, 
  Clock, 
  Flame, 
  Brain, 
  Target, 
  Sparkles, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Compass, 
  Trophy, 
  Calendar,
  Hourglass
} from 'lucide-react';
import { ProductivityDna } from '../types';
import { apiFetch } from '../utils/apiFetch';

export default function ProductivityDnaView() {
  const [dna, setDna] = useState<ProductivityDna | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDna = async (forceRefresh = false) => {
    try {
      if (forceRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      setError(null);
      const url = `/api/productivity-dna${forceRefresh ? '?refresh=true' : ''}`;
      const res = await apiFetch(url);
      if (!res.ok) {
        throw new Error('Failed to retrieve behavioral profile from the server');
      }
      const data = await res.json();
      setDna(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred during pattern compilation');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDna();
  }, []);

  const getProcrastinationLevel = (score: number) => {
    if (score < 30) return { label: 'Optimal Control', color: 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5', bar: 'bg-emerald-500' };
    if (score < 60) return { label: 'Moderate Risk', color: 'text-amber-400 border-amber-500/20 bg-amber-500/5', bar: 'bg-amber-500' };
    return { label: 'High Delay Risk', color: 'text-rose-400 border-rose-500/20 bg-rose-500/5', bar: 'bg-rose-500' };
  };

  if (loading) {
    return (
      <div id="productivity-dna-loading" className="flex flex-col items-center justify-center py-20 space-y-4">
        <div className="relative flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin"></div>
          <Compass className="w-6 h-6 text-indigo-400 absolute animate-pulse" />
        </div>
        <p className="text-xs uppercase tracking-widest font-mono text-[#666]">Sequencing Behavioral Genome...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div id="productivity-dna-error" className="p-8 border border-rose-500/20 bg-rose-500/5 text-center space-y-4 rounded-none">
        <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto" />
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">DNA Extraction Offline</h3>
        <p className="text-xs text-[#999] max-w-md mx-auto">{error}</p>
        <button 
          onClick={() => fetchDna()}
          className="px-4 py-2 border border-[#333] text-white text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-all"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  if (!dna) return null;

  const proc = getProcrastinationLevel(dna.procrastinationScore);

  return (
    <div id="productivity-dna-container" className="space-y-8 animate-in fade-in duration-500">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-[#1a1a1a] pb-6 gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-none">
              <Brain className="w-5 h-5" />
            </span>
            <h2 className="text-2xl font-light font-serif italic text-white">Productivity DNA</h2>
          </div>
          <p className="text-xs text-[#888] max-w-2xl">
            Autonomous behavioral intelligence engine. Orbit continuously maps your schedule patterns, habit cycles, distraction response rate, and focus milestones to align coaching rules to your daily rhythms.
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-right font-mono">
            <p className="text-[9px] text-[#555] uppercase tracking-wider">Last Sequenced</p>
            <p className="text-xs text-white">{dna.analysisDate}</p>
          </div>
          
          <button
            onClick={() => fetchDna(true)}
            disabled={refreshing}
            className={`flex items-center gap-2 px-4 py-2 text-[10px] font-bold uppercase tracking-widest border transition-all ${
              refreshing 
                ? 'bg-neutral-900 border-[#333] text-[#555] cursor-not-allowed'
                : 'bg-indigo-600 border-indigo-500 text-white hover:bg-indigo-700 hover:border-indigo-600'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? 'Analyzing...' : 'Recalibrate DNA'}
          </button>
        </div>
      </div>

      {/* Primary Behavioral Dimensions (Bento Grid) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Dimension 1: Best Working Hours */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-6 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-indigo-500/10 font-mono text-7xl select-none">01</div>
          <div className="space-y-4 z-10">
            <div className="flex items-center gap-2 text-indigo-400">
              <Clock className="w-4 h-4" />
              <span className="text-[10px] uppercase font-mono tracking-wider">Optimal Focus Period</span>
            </div>
            <div className="space-y-1">
              <h3 className="text-2xl font-light text-white tracking-tight">{dna.bestWorkHours}</h3>
              <p className="text-xs text-[#666]">Peak cognitive window computed from your focus starts and completion metrics.</p>
            </div>
          </div>
        </div>

        {/* Dimension 2: Most Productive Day */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-6 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-indigo-500/10 font-mono text-7xl select-none">02</div>
          <div className="space-y-4 z-10">
            <div className="flex items-center gap-2 text-indigo-400">
              <Calendar className="w-4 h-4" />
              <span className="text-[10px] uppercase font-mono tracking-wider">Peak Velocity Day</span>
            </div>
            <div className="space-y-1">
              <h3 className="text-2xl font-light text-white tracking-tight">{dna.productiveDay}</h3>
              <p className="text-xs text-[#666]">The day of the week with the highest frequency of checklist clearance.</p>
            </div>
          </div>
        </div>

        {/* Dimension 3: Procrastination Risk Detection */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-6 flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-indigo-500/10 font-mono text-7xl select-none">03</div>
          <div className="space-y-4 z-10">
            <div className="flex items-center gap-2 text-indigo-400">
              <AlertTriangle className="w-4 h-4" />
              <span className="text-[10px] uppercase font-mono tracking-wider">Procrastination Index</span>
            </div>
            <div className="space-y-3">
              <div className="flex items-end justify-between">
                <span className="text-2xl font-mono text-white">{dna.procrastinationScore}%</span>
                <span className={`text-[9px] uppercase px-2 py-0.5 border ${proc.color}`}>{proc.label}</span>
              </div>
              <div className="w-full h-1.5 bg-[#151515]">
                <div className={`h-full transition-all duration-1000 ${proc.bar}`} style={{ width: `${dna.procrastinationScore}%` }}></div>
              </div>
              <p className="text-[10px] text-[#666] leading-relaxed">Derived from rescheduled tasks, overdue deadlines, and missed notifications.</p>
            </div>
          </div>
        </div>

      </div>

      {/* Secondary Scores (Circle Gauges) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Metric 1: Task Completion Rate */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-6 flex items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-[#555]">
              <Trophy className="w-3.5 h-3.5 text-indigo-400" />
              <h4 className="text-[10px] uppercase tracking-wider font-mono">Completion Rate</h4>
            </div>
            <p className="text-xs text-[#888] leading-normal">
              Ratio of overall scheduled goals actively completed to dates.
            </p>
          </div>
          <div className="relative flex items-center justify-center w-20 h-20 flex-shrink-0">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="34" stroke="#151515" strokeWidth="4" fill="transparent" />
              <circle cx="40" cy="40" r="34" stroke="rgb(99, 102, 241)" strokeWidth="4" fill="transparent"
                strokeDasharray={`${2 * Math.PI * 34}`}
                strokeDashoffset={`${2 * Math.PI * 34 * (1 - dna.completionRate / 100)}`}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <span className="absolute text-sm font-mono text-white">{dna.completionRate}%</span>
          </div>
        </div>

        {/* Metric 2: Habit Consistency */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-6 flex items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-[#555]">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <h4 className="text-[10px] uppercase tracking-wider font-mono">Habit Consistency</h4>
            </div>
            <p className="text-xs text-[#888] leading-normal">
              Evaluation of streak maintenance and daily checklist check-ins.
            </p>
          </div>
          <div className="relative flex items-center justify-center w-20 h-20 flex-shrink-0">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="34" stroke="#151515" strokeWidth="4" fill="transparent" />
              <circle cx="40" cy="40" r="34" stroke="rgb(249, 115, 22)" strokeWidth="4" fill="transparent"
                strokeDasharray={`${2 * Math.PI * 34}`}
                strokeDashoffset={`${2 * Math.PI * 34 * (1 - dna.habitScore / 100)}`}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <span className="absolute text-sm font-mono text-white">{dna.habitScore}%</span>
          </div>
        </div>

        {/* Metric 3: Focus Reliability */}
        <div className="bg-[#0a0a0a] border border-[#1a1a1a] p-6 flex items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-[#555]">
              <Target className="w-3.5 h-3.5 text-emerald-400" />
              <h4 className="text-[10px] uppercase tracking-wider font-mono">Focus Reliability</h4>
            </div>
            <p className="text-xs text-[#888] leading-normal">
              Success rate of completing initiated 25-minute Pomodoro sessions.
            </p>
          </div>
          <div className="relative flex items-center justify-center w-20 h-20 flex-shrink-0">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="34" stroke="#151515" strokeWidth="4" fill="transparent" />
              <circle cx="40" cy="40" r="34" stroke="rgb(16, 185, 129)" strokeWidth="4" fill="transparent"
                strokeDasharray={`${2 * Math.PI * 34}`}
                strokeDashoffset={`${2 * Math.PI * 34 * (1 - dna.focusScore / 100)}`}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <span className="absolute text-sm font-mono text-white">{dna.focusScore}%</span>
          </div>
        </div>

      </div>

      {/* AI Coach Insights & Recommendations */}
      <div className="bg-[#050505] border border-[#1a1a1a] rounded-none p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-[#111] pb-4">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-none">
              <Sparkles className="w-4 h-4" />
            </span>
            <h3 className="text-lg font-light font-serif italic text-white">Neural Pattern Insights</h3>
          </div>
          <p className="text-[10px] text-[#555] font-mono uppercase tracking-wider">Gemini Behavior Analytics</p>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {Array.isArray(dna.recommendations) && dna.recommendations.length > 0 ? (
            dna.recommendations.map((recommendation, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="p-5 border border-[#111] bg-[#080808] flex gap-4 items-start relative group hover:border-[#222] transition-colors"
              >
                <div className="p-2 bg-indigo-500/5 text-indigo-400 font-mono text-xs border border-indigo-500/10 rounded-none w-8 h-8 flex items-center justify-center flex-shrink-0">
                  {idx + 1}
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-white leading-relaxed font-light">{recommendation}</p>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12 space-y-2">
              <Compass className="w-8 h-8 text-[#333] mx-auto" />
              <p className="text-xs text-[#555] uppercase font-mono">No Behavioral Recommendations Computed Yet</p>
              <p className="text-[10px] text-[#444]">Add more tasks, log reflections, or complete focus sessions to trigger deeper neural insights.</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
