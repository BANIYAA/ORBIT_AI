import React, { useState } from 'react';
import { Terminal, ArrowRight, Loader2 } from 'lucide-react';
import { Task } from '../types';
import { apiFetch } from '../utils/apiFetch';

interface NaturalLanguageCommandProps {
  onCommandResult: (action: string, payload: any) => any;
  tasks: Task[];
}

export default function NaturalLanguageCommand({ onCommandResult, tasks }: NaturalLanguageCommandProps) {
  const [command, setCommand] = useState("");
  const [loading, setLoading] = useState(false);
  const [lastResponse, setLastResponse] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;

    setLoading(true);
    setLastResponse(null);
    try {
      const response = await apiFetch('/api/command', {
        method: 'POST',
        body: JSON.stringify({ command, context: { currentTasks: tasks } })
      });
      const data = await response.json();
      
      setLastResponse(data.responseMessage);
      onCommandResult(data.action, data.payload);
      setCommand("");
    } catch (err) {
      setLastResponse("Failed to process command. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-none p-4 mt-8">
      <div className="flex items-center gap-2 mb-3">
        <Terminal className="w-4 h-4 text-emerald-500" />
        <h3 className="text-white font-bold tracking-widest text-[11px] uppercase">
          AI Command Center
        </h3>
      </div>
      
      <form onSubmit={handleSubmit} className="relative">
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="e.g. 'Add a task to prepare for the exam on Friday'"
          className="w-full bg-[#111] border border-[#222] text-white px-4 py-3 pr-12 text-sm focus:outline-none focus:border-[#444] transition-colors"
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading || !command.trim()}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-[#555] hover:text-white disabled:opacity-50 transition-colors p-1 cursor-pointer"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </form>
      
      {lastResponse && (
        <div className="mt-3 text-[11px] text-emerald-400 tracking-wide font-mono">
          &gt; {lastResponse}
        </div>
      )}
    </div>
  );
}
