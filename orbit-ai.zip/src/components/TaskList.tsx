import React from 'react';
import { CircleCheck, Circle, Trash2, Calendar, Clock, Sparkles, Star, ChevronDown, SquareCheck, ListTodo, Pencil } from 'lucide-react';
import { Task } from '../types';

interface TaskListProps {
  tasks: Task[];
  onToggleComplete: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onEditTask?: (task: Task) => void;
  onBreakDownTask?: (id: string, title: string, description: string) => void;
  onToggleSubtask?: (taskId: string, subtaskId: string) => void;
  hasPrioritized: boolean;
}

export default function TaskList({ 
  tasks, 
  onToggleComplete, 
  onDeleteTask, 
  onEditTask, 
  onBreakDownTask,
  onToggleSubtask,
  hasPrioritized 
}: TaskListProps) {
  const pendingTasks = tasks.filter((t) => !t.completed);
  const completedTasks = tasks.filter((t) => t.completed);

  // Sorting priorities for active tasks
  const sortedPendingTasks = [...pendingTasks].sort((a, b) => {
    // If AI prioritized, sort strictly by AI Rank
    if (a.aiRank !== undefined && b.aiRank !== undefined) {
      return a.aiRank - b.aiRank;
    }
    // Standard heuristic backup sorting
    const impVal = { high: 3, medium: 2, low: 1 };
    const diff = impVal[b.importance] - impVal[a.importance];
    if (diff !== 0) return diff;
    const dateA = a.deadline ? new Date(a.deadline).getTime() : Infinity;
    const dateB = b.deadline ? new Date(b.deadline).getTime() : Infinity;
    const validA = isNaN(dateA) ? Infinity : dateA;
    const validB = isNaN(dateB) ? Infinity : dateB;
    if (validA === Infinity && validB === Infinity) return 0;
    return validA - validB;
  });

  // Completed tasks sorted by completion date
  const sortedCompletedTasks = [...completedTasks].sort((a, b) => {
    const da = a.completedAt ? new Date(a.completedAt).getTime() : 0;
    const db = b.completedAt ? new Date(b.completedAt).getTime() : 0;
    return db - da;
  });

  // Format datetime string human-readably
  const formatDeadline = (isoString: string) => {
    try {
      if (!isoString) return '';
      const date = new Date(isoString);
      if (isNaN(date.getTime())) {
        return isoString || '';
      }
      const now = new Date();
      
      // Calculate day difference
      const diffTime = date.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      if (diffDays === 0) {
        return `Today at ${timeStr}`;
      } else if (diffDays === 1) {
        return `Tomorrow at ${timeStr}`;
      } else if (diffDays === -1) {
        return `Yesterday (Overdue)`;
      } else if (diffDays < 0) {
        return `${Math.abs(diffDays)} days ago (Overdue)`;
      } else if (diffDays < 7) {
        return `${date.toLocaleDateString([], { weekday: 'short' })} at ${timeStr}`;
      } else {
        return `${date.toLocaleDateString()} (${timeStr})`;
      }
    } catch {
      return isoString || '';
    }
  };

  const getImportanceColor = (imp: 'low' | 'medium' | 'high') => {
    switch (imp) {
      case 'high':
        return 'text-red-500 bg-[#1a0f12] border-rose-900/30';
      case 'medium':
        return 'text-amber-500 bg-[#1a150f] border-amber-900/30';
      case 'low':
        return 'text-emerald-500 bg-[#0f1a14] border-emerald-900/30';
    }
  };

  return (
    <div className="space-y-6" id="orbit-tasks-dashboard-list">
      {/* Active Tasks Panel */}
      <div id="active-tasks-container" className="space-y-4">
        <div className="flex items-center justify-between border-b border-[#1a1a1a] pb-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-blue-500 rounded-full shrink-0"></span>
            <h3 className="font-semibold text-xs text-[#e0e0e0] uppercase tracking-widest">Active Directives Queue</h3>
          </div>
          <span className="text-[10px] text-white bg-[#111] border border-[#222] px-2.5 py-0.5 rounded-none font-mono uppercase tracking-wider">
            {pendingTasks.length} Pending
          </span>
        </div>

        {sortedPendingTasks.length === 0 ? (
          <div className="text-center py-12 glass-card border border-white/5 bg-white/[0.01]">
            <SquareCheck className="w-6 h-6 text-white/20 mx-auto mb-2" />
            <p className="text-white/40 text-xs uppercase tracking-widest font-mono">All clear! Add a task to initiate scheduling.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sortedPendingTasks.map((task) => (
              <div
                key={task.id}
                id={`task-item-${task.id}`}
                className={`relative glass-card p-6 rounded-2xl flex flex-col gap-5 border transition-all duration-300 hover:scale-[1.01] hover:shadow-[0_0_25px_rgba(6,182,212,0.15)] group ${
                  task.aiRank === 1
                    ? 'border-cyan-400/45 bg-cyan-950/15 shadow-[0_0_30px_rgba(6,182,212,0.12)]'
                    : 'border-white/5 hover:border-cyan-500/30 bg-white/[0.02]'
                }`}
              >
                {/* Visual Rank Tag in corner */}
                <div className="absolute top-4 right-4 text-xs font-mono font-bold text-white/20 select-none group-hover:text-cyan-400/40 transition-colors">
                  {task.aiRank !== undefined ? `ORD-${String(task.aiRank).padStart(2, '0')}` : 'OBJ-RAW'}
                </div>

                {/* 1. Task Title */}
                <div className="flex items-start gap-3">
                  <div className="flex-1 space-y-1.5">
                    <h4 className="text-base font-semibold text-white tracking-wide leading-snug group-hover:text-cyan-100 transition-colors">
                      {task.title}
                    </h4>
                  </div>
                </div>

                {/* 2. Metadata */}
                <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-white/60 uppercase tracking-wider font-mono">
                  <span className={`px-2.5 py-1 rounded text-[10px] font-bold border ${getImportanceColor(task.importance)}`}>
                    {task.importance} PRIORITY
                  </span>
                  {task.isRescheduled && (
                    <span className="px-2.5 py-1 rounded text-[10px] font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-800/40 animate-pulse">
                      AI RESCHEDULED
                    </span>
                  )}
                  <span className="flex items-center gap-1.5 bg-white/[0.03] border border-white/5 px-2.5 py-1 rounded">
                    <Calendar className="w-3.5 h-3.5 text-cyan-400/70" />
                    DUE: {formatDeadline(task.deadline)}
                  </span>
                  <span className="flex items-center gap-1.5 bg-white/[0.03] border border-white/5 px-2.5 py-1 rounded">
                    <Clock className="w-3.5 h-3.5 text-cyan-400/70" />
                    DURATION: {task.duration}m
                  </span>
                </div>

                {/* 3. Focus Allocation Section */}
                {task.aiPriorityScore !== undefined && (
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-white/70 flex items-center gap-1.5 font-bold uppercase tracking-widest text-[10px] font-mono">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Focus Allocation Index
                      </span>
                      <span className="text-[11px] font-bold font-mono text-cyan-400">
                        SCORE: {task.aiPriorityScore}/100
                      </span>
                    </div>

                    {/* Progress Bar with soft glow */}
                    <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/10">
                      <div
                        className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full shadow-[0_0_10px_rgba(6,182,212,0.5)]"
                        style={{ width: `${task.aiPriorityScore}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* 4. AI Information */}
                {task.aiPriorityScore !== undefined && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white/[0.01] border border-white/5 rounded-xl p-3.5 text-[11px] font-mono tracking-wide uppercase">
                    <div>
                      <span className="text-[9px] font-bold text-white/40 block mb-1">
                        RECOMMENDED WINDOW
                      </span>
                      <span className="text-white font-semibold flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-cyan-400/70" /> {task.aiOptimalTime}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold text-white/40 block mb-1">
                        DYNAMIC CLASSIFICATION
                      </span>
                      <span className="text-white font-semibold flex items-center gap-1.5">
                        <Star className="w-3.5 h-3.5 fill-cyan-400/10 text-cyan-400" /> {task.aiCategory || 'Workload Focus'}
                      </span>
                    </div>
                    {task.aiReasoning && (
                      <div className="col-span-1 sm:col-span-2 pt-2.5 border-t border-white/5 mt-1.5">
                        <span className="text-[9px] font-bold text-white/40 block mb-1">
                          COORDINATOR INSIGHT / REASONING
                        </span>
                        <p className="text-xs text-white/80 font-serif italic normal-case tracking-normal leading-relaxed pl-3 border-l-2 border-cyan-500/30">
                          "{task.aiReasoning}"
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Subtasks rendering */}
                {Array.isArray(task.subtasks) && task.subtasks.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <span className="text-[9px] font-bold text-white/40 uppercase font-mono tracking-wider">
                      SUBTASK PROTOCOLS ({task.subtasks.length})
                    </span>
                    <div className="space-y-1.5">
                      {task.subtasks.map((st) => (
                        <div 
                          key={st.id} 
                          className="flex items-center gap-3 text-xs py-2 px-3 border border-white/5 bg-white/[0.01] rounded-xl hover:bg-white/[0.03] hover:border-white/10 transition-all"
                        >
                          <button 
                            onClick={() => onToggleSubtask?.(task.id, st.id)}
                            className="text-white/40 hover:text-cyan-400 transition-colors p-1 flex items-center justify-center cursor-pointer"
                          >
                            {st.status === 'Completed' ? <CircleCheck className="w-4 h-4 text-cyan-400" /> : <Circle className="w-4 h-4" />}
                          </button>
                          <span className={`flex-1 ${st.status === 'Completed' ? 'text-white/40 line-through' : 'text-white/80 font-light'}`}>
                            {st.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 5. Action Buttons (Integrated control panel) */}
                <div className="flex items-center justify-between gap-3 pt-3 border-t border-white/5 flex-wrap">
                  <button
                    onClick={() => onToggleComplete(task.id)}
                    className="flex-1 md:flex-initial text-center py-2.5 px-4 border border-cyan-500/20 rounded-xl text-xs hover:bg-cyan-500/10 uppercase tracking-widest bg-transparent text-cyan-400 font-bold font-mono transition-all duration-300 cursor-pointer"
                  >
                    Resolve Objective
                  </button>

                  <div className="flex items-center gap-2">
                    {onBreakDownTask && (!task.subtasks || task.subtasks.length === 0) && (
                      <button
                        onClick={() => onBreakDownTask(task.id, task.title, "")}
                        className="text-[10px] uppercase font-bold tracking-widest text-cyan-400 hover:text-white bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-xl px-4 py-2.5 transition-all duration-300 cursor-pointer flex items-center gap-1.5 font-mono"
                        title="Analyze and split into automated subtasks"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Break Down</span>
                      </button>
                    )}
                    {onEditTask && (
                      <button
                        onClick={() => onEditTask(task)}
                        className="text-white/60 hover:text-cyan-400 p-2.5 rounded-xl border border-white/5 hover:border-cyan-500/30 bg-white/[0.01] hover:bg-cyan-950/20 transition-all cursor-pointer"
                        title="Modify baseline objective details"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => onDeleteTask(task.id)}
                      className="text-white/40 hover:text-red-400 p-2.5 rounded-xl border border-white/5 hover:border-red-500/30 bg-white/[0.01] hover:bg-red-950/10 transition-all cursor-pointer"
                      title="Decommission objective record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Completed Tasks Panel */}
      {completedTasks.length > 0 && (
        <div id="completed-tasks-container" className="space-y-3 pt-5 border-t border-white/10">
          <div className="flex items-center justify-between">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-white/40 font-mono">
              Resolved Achievements ({completedTasks.length})
            </h4>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {sortedCompletedTasks.map((task) => (
              <div
                key={task.id}
                className="glass-card p-4 rounded-xl flex items-center justify-between gap-4 bg-white/[0.01] hover:bg-white/[0.03] border border-white/5 opacity-50 hover:opacity-90 transition-all"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onToggleComplete(task.id)}
                    className="text-cyan-400 transition-colors cursor-pointer shrink-0 p-1 flex items-center justify-center"
                    title="Undo achievement completion"
                  >
                    <CircleCheck className="w-5 h-5 text-cyan-400" />
                  </button>
                  <div>
                    <span className="text-xs text-white/50 line-through font-light">
                      {task.title}
                    </span>
                    <span className="text-[9px] text-white/30 uppercase block font-mono mt-0.5">
                      Resolved {(() => {
                        if (!task.completedAt) return '';
                        const d = new Date(task.completedAt);
                        if (isNaN(d.getTime())) return '';
                        try {
                          return d.toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
                        } catch {
                          return '';
                        }
                      })()}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteTask(task.id)}
                  className="text-white/30 hover:text-red-400 p-2 rounded-xl transition-all cursor-pointer"
                  title="Permanently erase task record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
