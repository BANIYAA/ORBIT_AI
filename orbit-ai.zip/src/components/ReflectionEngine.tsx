import React, { useState, useEffect } from 'react';
import { Task, Habit, DailyPlanResponse, ReflectionData, JournalInsight } from '../types';
import { apiFetch } from '../utils/apiFetch';
import { Brain, TrendingUp, TrendingDown, Target, Zap, Clock, ShieldAlert, Award, Sparkles, AlertTriangle, CheckCircle2, ChevronRight, Activity, MessageSquarePlus } from 'lucide-react';

interface ReflectionEngineProps {
  tasks: Task[];
  habits: Habit[];
  dailyPlan: DailyPlanResponse | null;
  onSaveReflection: (reflection: ReflectionData) => void;
  historyReflections: ReflectionData[];
}

export default function ReflectionEngine({ tasks, habits, dailyPlan, onSaveReflection, historyReflections }: ReflectionEngineProps) {
  const [journalEntry, setJournalEntry] = useState('');
  const [reflection, setReflection] = useState<ReflectionData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isAnalyzingJournal, setIsAnalyzingJournal] = useState(false);
  const [journalInsight, setJournalInsight] = useState<JournalInsight | null>(null);
  const [pastInsights, setPastInsights] = useState<JournalInsight[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadPastInsights = async () => {
      try {
        const res = await apiFetch('/api/journal-analysis');
        if (res.ok) {
          const data = await res.json();
          setPastInsights(data);
        }
      } catch (err) {
        console.error('Failed to retrieve journal insights:', err);
      }
    };
    loadPastInsights();
  }, []);

  const selectReflection = (ref: ReflectionData) => {
    setReflection(ref);
    const matched = pastInsights.find(insight => insight.journalId === ref.id);
    if (matched) {
      setJournalInsight(matched);
    } else {
      setJournalInsight(null);
    }
  };

  const generateReflection = async () => {
    setIsLoading(true);
    setError(null);
    setJournalInsight(null);
    try {
      const response = await apiFetch('/api/reflection', {
        method: 'POST',
        body: JSON.stringify({
          tasks,
          habits,
          dailyPlan,
          journalEntry,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate reflection');
      }

      const data = await response.json();
      const reflectionId = `ref-${Date.now()}`;
      const newReflection = {
        ...data.reflection,
        id: reflectionId,
        date: new Date().toISOString()
      };

      if (journalEntry.trim()) {
        setIsAnalyzingJournal(true);
        try {
          const analysisRes = await apiFetch('/api/journal-analysis', {
            method: 'POST',
            body: JSON.stringify({
              journalEntry,
              journalId: reflectionId
            }),
          });
          if (analysisRes.ok) {
            const analysisData = await analysisRes.json();
            setJournalInsight(analysisData);
            setPastInsights(prev => [analysisData, ...prev]);
          }
        } catch (jErr) {
          console.error("Failed to run journal analysis:", jErr);
        } finally {
          setIsAnalyzingJournal(false);
        }
      }

      setReflection(newReflection);
      onSaveReflection(newReflection);
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <div id="reflection-engine-root" className="bg-[#111] border border-[#222] rounded-xl p-6 w-full max-w-4xl mx-auto space-y-6 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500"></div>
      
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-indigo-500/20 rounded-lg">
          <Brain className="w-6 h-6 text-indigo-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Orbit Reflection Engine</h2>
          <p className="text-sm text-gray-400">Deep performance analysis & personalized coaching</p>
        </div>
      </div>

      {!reflection ? (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300 ml-1">Daily Journal (Optional, but recommended)</label>
            <textarea
              id="reflection-journal-textarea"
              value={journalEntry}
              onChange={(e) => setJournalEntry(e.target.value)}
              placeholder="How did today go? What distracted you? What energized you?"
              className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg p-4 text-white placeholder-gray-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors resize-none h-32"
            />
          </div>
          <button
            id="reflection-generate-btn"
            onClick={generateReflection}
            disabled={isLoading}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Analyzing Data Universe...</span>
              </>
            ) : (
              <>
                <Zap className="w-5 h-5" />
                <span>Generate Reflection</span>
              </>
            )}
          </button>
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          
          {historyReflections.length > 0 && (
            <div className="mt-12 space-y-4">
              <h3 className="text-lg font-serif italic text-white mb-4">Past Reflections</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {historyReflections.slice(0, 4).map(ref => (
                  <div key={ref.id} className="bg-[#0a0a0a] border border-[#222] p-4 rounded-lg hover:border-indigo-500/50 transition-colors cursor-pointer" onClick={() => selectReflection(ref)}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-500">{new Date(ref.date).toLocaleDateString()}</span>
                      <span className={`text-xs font-bold ${ref.completionRate >= 100 ? 'text-emerald-400' : ref.completionRate < 70 ? 'text-rose-400' : 'text-blue-400'}`}>{ref.completionRate}%</span>
                    </div>
                    <p className="text-sm text-gray-300 line-clamp-2">{ref.dailyReflection}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          {/* Top Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
              <div className="flex items-center gap-2 text-gray-400 mb-2">
                <Target className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Completion</span>
              </div>
              <div className="flex items-end gap-2">
                <span className={`text-3xl font-bold ${reflection.completionRate >= 100 ? 'text-emerald-400' : reflection.completionRate < 70 ? 'text-rose-400' : 'text-blue-400'}`}>
                  {reflection.completionRate}%
                </span>
                {reflection.completionRate > 100 && <Award className="w-5 h-5 text-emerald-400 mb-1" />}
              </div>
            </div>
            
            <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
              <div className="flex items-center gap-2 text-gray-400 mb-2">
                <TrendingUp className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Habit Consistency</span>
              </div>
              <span className="text-3xl font-bold text-indigo-400">{reflection.habitConsistency}%</span>
            </div>

            <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
              <div className="flex items-center gap-2 text-gray-400 mb-2">
                <Zap className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Momentum</span>
              </div>
              <span className="text-3xl font-bold text-amber-400">{reflection.momentumScore}/100</span>
            </div>

            <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
              <div className="flex items-center gap-2 text-gray-400 mb-2">
                <Clock className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Missed vs Extra</span>
              </div>
              <div className="text-xl font-bold text-white flex gap-3">
                <span className="text-rose-400">-{reflection.missedWork}</span>
                <span className="text-emerald-400">+{reflection.extraWork}</span>
              </div>
            </div>
          </div>

          {/* Main Insights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-[#0a0a0a] p-5 rounded-lg border border-[#333]">
                <h3 className="text-sm uppercase tracking-wider text-indigo-400 font-bold mb-3">Daily Reflection</h3>
                <p className="text-gray-300 text-sm leading-relaxed">{typeof reflection.dailyReflection === 'object' ? JSON.stringify(reflection.dailyReflection) : reflection.dailyReflection}</p>
              </div>

              <div className="bg-[#0a0a0a] p-5 rounded-lg border border-[#333]">
                <h3 className="text-sm uppercase tracking-wider text-amber-400 font-bold mb-3">Performance Analysis</h3>
                <p className="text-gray-300 text-sm leading-relaxed">{typeof reflection.performanceAnalysis === 'object' ? JSON.stringify(reflection.performanceAnalysis) : reflection.performanceAnalysis}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-indigo-500/10 p-5 rounded-lg border border-indigo-500/20">
                <h3 className="text-sm uppercase tracking-wider text-indigo-300 font-bold mb-3 flex items-center gap-2">
                  <Brain className="w-4 h-4" /> AI Coaching
                </h3>
                <p className="text-indigo-100 text-sm leading-relaxed">{typeof reflection.personalizedCoaching === 'object' ? JSON.stringify(reflection.personalizedCoaching) : reflection.personalizedCoaching}</p>
                <div className="mt-4 p-3 bg-emerald-500/10 rounded border border-emerald-500/20 text-emerald-200 text-sm">
                  <strong className="text-emerald-400">Wins:</strong> {typeof reflection.positiveReinforcement === 'object' ? JSON.stringify(reflection.positiveReinforcement) : reflection.positiveReinforcement}
                </div>
              </div>

              <div className="bg-[#0a0a0a] p-5 rounded-lg border border-[#333]">
                <h3 className="text-sm uppercase tracking-wider text-rose-400 font-bold mb-3 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4" /> Improvement Areas
                </h3>
                <ul className="list-disc list-inside text-sm text-gray-300 space-y-1">
                  {Array.isArray(reflection.improvementSuggestions) && reflection.improvementSuggestions.map((s, i) => (
                    <li key={i}>{typeof s === 'object' ? JSON.stringify(s) : s}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Patterns & Trends */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
                <h4 className="text-xs uppercase tracking-wider text-gray-500 font-bold mb-2">Energy Patterns</h4>
                <div className="flex flex-wrap gap-2">
                  {Array.isArray(reflection.energyPatterns) && reflection.energyPatterns.map((p, i) => (
                    <span key={i} className="px-2 py-1 bg-amber-500/10 text-amber-400 rounded text-xs">{p}</span>
                  ))}
                </div>
             </div>
             <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
                <h4 className="text-xs uppercase tracking-wider text-gray-500 font-bold mb-2">Distraction Patterns</h4>
                <div className="flex flex-wrap gap-2">
                  {Array.isArray(reflection.distractionPatterns) && reflection.distractionPatterns.map((p, i) => (
                    <span key={i} className="px-2 py-1 bg-rose-500/10 text-rose-400 rounded text-xs">{p}</span>
                  ))}
                </div>
             </div>
             <div className="bg-[#0a0a0a] p-4 rounded-lg border border-[#222]">
                <h4 className="text-xs uppercase tracking-wider text-gray-500 font-bold mb-2">Tomorrow's Focus</h4>
                <ul className="text-xs text-blue-300 space-y-1">
                  {Array.isArray(reflection.futurePlanningSuggestions) && reflection.futurePlanningSuggestions.map((s, i) => (
                    <li key={i} className="flex gap-1 items-start">
                      <span className="text-blue-500">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
             </div>
          </div>

          {/* Journal Intelligence Analysis */}
          {isAnalyzingJournal ? (
            <div className="bg-[#0c0d12] border border-[#232736]/40 p-6 rounded-xl text-center space-y-3">
              <div className="w-6 h-6 border-2 border-indigo-500/30 border-t-indigo-400 rounded-full animate-spin mx-auto" />
              <p className="text-sm text-gray-400 font-mono tracking-wide">Synthesizing Journal Intelligence & Behavioral Blueprint...</p>
            </div>
          ) : journalInsight ? (
            <div className="bg-gradient-to-br from-[#0c0d12] to-[#07080b] border border-[#232736]/60 p-6 rounded-xl relative overflow-hidden shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5 border-b border-[#1f2231] pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 rounded-lg border border-indigo-500/30">
                    <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-md font-bold text-white tracking-wide uppercase flex items-center gap-2">
                      Journal Intelligence <span className="text-xs text-gray-500 font-mono">v1.2</span>
                    </h3>
                    <p className="text-xs text-gray-400">Cognitive & behavioral performance coaching analysis</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-[#0e0f13] border border-[#222] px-4 py-2 rounded-lg">
                  <div className="text-right">
                    <p className="text-[10px] uppercase text-gray-500 tracking-widest font-mono">Behavioral Score</p>
                    <p className="text-xs text-gray-400 font-semibold">
                      {journalInsight.score >= 75 ? "🎯 Peak Momentum" : "⚠️ Performance Friction"}
                    </p>
                  </div>
                  <div className={`text-2xl font-extrabold px-2 py-0.5 rounded ${
                    journalInsight.score >= 75 ? "text-emerald-400 bg-emerald-500/10" : "text-amber-400 bg-amber-500/10"
                  }`}>
                    {journalInsight.score}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 space-y-4">
                  <div className="space-y-1">
                    <h4 className="text-xs uppercase tracking-wider text-gray-400 font-bold flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5 text-indigo-400" /> Executive Analysis
                    </h4>
                    <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-line bg-[#08090c] p-4 rounded-lg border border-[#161822]">
                      {journalInsight.analysis}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="text-xs uppercase tracking-wider text-gray-400 font-bold flex items-center gap-1.5">
                      {journalInsight.score >= 75 ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Key Growth Factors
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Actionable Recovery Plan
                        </>
                      )}
                    </h4>
                    
                    <div className="space-y-2">
                      {Array.isArray(journalInsight.improvements) && journalInsight.improvements.map((item, idx) => (
                        <div 
                          key={idx} 
                          className={`flex gap-2.5 items-start p-3 rounded-lg border text-xs leading-relaxed ${
                            journalInsight.score >= 75 
                              ? "bg-emerald-500/5 border-emerald-500/10 text-emerald-200" 
                              : "bg-amber-500/5 border-amber-500/10 text-amber-200"
                          }`}
                        >
                          <span className={`font-bold font-mono mt-0.5 px-1.5 py-0.2 rounded text-[10px] ${
                            journalInsight.score >= 75 ? "bg-emerald-500/20 text-emerald-300" : "bg-amber-500/20 text-amber-300"
                          }`}>
                            {idx + 1}
                          </span>
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : null}

          <div className="flex justify-end pt-4">
            <button 
              onClick={() => { setReflection(null); setJournalEntry(''); setJournalInsight(null); }}
              className="text-sm text-gray-500 hover:text-white transition-colors"
            >
              Start New Reflection
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
