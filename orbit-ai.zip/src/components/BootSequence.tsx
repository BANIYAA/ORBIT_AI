import React, { useState, useEffect } from 'react';

export default function BootSequence({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const sequence = [
      { delay: 400, step: 1 }, // AI Core boot
      { delay: 1000, step: 2 }, // Planets forming
      { delay: 1800, step: 3 }, // Orbit calculations
      { delay: 2400, step: 4 }, // Data synchronization
      { delay: 3000, step: 5 }, // Complete
    ];

    const timeouts = sequence.map(item => 
      setTimeout(() => {
        setStep(item.step);
        if (item.step === 5) onComplete();
      }, item.delay)
    );

    return () => timeouts.forEach(clearTimeout);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] bg-black text-white flex flex-col items-center justify-center font-mono text-sm tracking-widest pointer-events-none transition-opacity duration-1000">
      <div className="w-64 space-y-4">
        <div className={`transition-opacity duration-300 ${step >= 0 ? 'opacity-100' : 'opacity-0'}`}>
          <div className="text-blue-500 mb-1">SYSTEM INITIALIZATION</div>
          <div className="h-1 bg-white/10 w-full overflow-hidden rounded-full">
            <div className="h-full bg-blue-500 transition-all duration-[3000ms] ease-linear w-full" style={{ transform: `scaleX(${step === 0 ? 0 : 1})`, transformOrigin: 'left' }} />
          </div>
        </div>
        
        <div className="space-y-2 text-[10px] text-white/50 h-32 flex flex-col justify-end">
          <div className={`transition-all duration-300 ${step >= 1 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>&gt; BOOTING AI NEURAL CORE...</div>
          <div className={`transition-all duration-300 ${step >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>&gt; SYNTHESIZING PROCEDURAL PLANETS...</div>
          <div className={`transition-all duration-300 ${step >= 3 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>&gt; CALCULATING ORBITAL MECHANICS...</div>
          <div className={`transition-all duration-300 ${step >= 4 ? 'opacity-100 translate-y-0 text-green-400' : 'opacity-0 translate-y-2'}`}>&gt; DATA SYNCHRONIZED. SYSTEM READY.</div>
        </div>
      </div>
    </div>
  );
}
