import React, { useState } from 'react';
import OrbitCanvas from '../components/3d/OrbitCanvas';
import TopBar from '../components/3d/ui/TopBar';
import LeftSidebar from '../components/3d/ui/LeftSidebar';
import RightSidebar from '../components/3d/ui/RightSidebar';
import BottomBar from '../components/3d/ui/BottomBar';
import { Task, Habit, DailyPlanResponse, ReflectionData } from '../types';
import { ChevronRight, ChevronLeft } from 'lucide-react';

interface Dashboard3DProps {
  tasks: Task[];
  habits: Habit[];
  dailyPlan: DailyPlanResponse | null;
  reflections: ReflectionData[];
  userSettings: any;
  onNavigate: (tab: string) => void;
  onTaskComplete: (id: string) => void;
  userName?: string;
  onStartFocusMode?: () => void;
  activeTab: string;
  isFocusMode: boolean;
  setIsFocusMode: (focus: boolean) => void;
  onLogout: () => void;
  onCommandResult: (action: string, payload: any) => any;
  productivityScore?: number;
}

export default function Dashboard3D(props: Dashboard3DProps) {
  const [isLeftOpen, setIsLeftOpen] = useState(false);
  const [isRightOpen, setIsRightOpen] = useState(false);

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden font-sans text-white select-none">
      
      {/* 3D Scene Layer */}
      <div className="absolute inset-0 z-0">
        <OrbitCanvas {...props} />
      </div>

      {/* 2D Overlay HUD Layer */}
      <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-4 sm:pb-3 sm:pt-6 sm:px-6 lg:pb-3 lg:pt-8 lg:px-8">
        
        {/* Top Region */}
        <div className="flex justify-between items-start w-full">
          <TopBar 
            userName={props.userName}
            productivityScore={props.productivityScore}
            activeTab={props.activeTab}
            setActiveTab={props.onNavigate}
            isFocusMode={props.isFocusMode}
            setIsFocusMode={props.setIsFocusMode}
            onLogout={props.onLogout}
            tasks={props.tasks}
            habits={props.habits}
            onCommandResult={props.onCommandResult}
          />
        </div>

        {/* Middle Region (Sidebars) */}
        <div className="flex justify-between items-stretch w-full flex-1 min-h-0 my-4 overflow-hidden">
          {/* Left Sidebar - standard on lg, drawer on smaller screens */}
          <LeftSidebar 
            activeTab={props.activeTab} 
            onNavigate={(tab) => {
              props.onNavigate(tab);
              setIsLeftOpen(false);
            }} 
            onStartFocusMode={() => {
              if (props.onStartFocusMode) props.onStartFocusMode();
              setIsLeftOpen(false);
            }} 
            isOpen={isLeftOpen}
            onClose={() => setIsLeftOpen(false)}
          />
          
          {/* Right Sidebar - standard on lg, drawer on smaller screens */}
          <RightSidebar 
            {...props} 
            isOpen={isRightOpen}
            onClose={() => setIsRightOpen(false)}
          />
        </div>

        {/* Bottom Region */}
        <div className="flex justify-center items-end w-full">
          <BottomBar tasks={props.tasks} habits={props.habits} />
        </div>
        
      </div>

      {/* Edge Triggers for Sidebars on Mobile/Tablet screens */}
      {!isLeftOpen && (
        <button 
          onClick={() => setIsLeftOpen(true)}
          className="lg:hidden fixed left-0 top-1/2 -translate-y-1/2 z-30 bg-black/55 hover:bg-cyan-950/65 border-y border-r border-cyan-500/30 text-cyan-400 p-3 rounded-r-xl shadow-[0_0_15px_rgba(6,182,212,0.2)] backdrop-blur-md pointer-events-auto transition-all duration-300 animate-pulse cursor-pointer flex items-center justify-center"
          title="Open Navigation HUD"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      )}

      {!isRightOpen && (
        <button 
          onClick={() => setIsRightOpen(true)}
          className="lg:hidden fixed right-0 top-1/2 -translate-y-1/2 z-30 bg-black/55 hover:bg-cyan-950/65 border-y border-l border-cyan-500/30 text-cyan-400 p-3 rounded-l-xl shadow-[0_0_15px_rgba(6,182,212,0.2)] backdrop-blur-md pointer-events-auto transition-all duration-300 animate-pulse cursor-pointer flex items-center justify-center"
          title="Open AI Command Center & Reminders"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      )}

    </div>
  );
}
