import fs from 'fs';
import path from 'path';
import { Task, Habit, DailyPlanResponse, ReflectionData } from '../types';
import { sessionContext } from './dbService';

const DB_FILE = path.join(process.cwd(), 'db.json');

function getUserId() {
  const store = sessionContext.getStore();
  if (!store || !store.userId) throw new Error("Unauthorized: No user session");
  return store.userId;
}

// Ensure database file exists with initial structure
function initDb() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({
      users: [],
      tasks: [],
      habits: [],
      directives: [],
      dailyPlans: [],
      reflections: [],
      reminders: [],
      focusSessions: [],
      productivityDna: [],
      journalInsights: [],
      userProfileSummary: []
    }, null, 2));
  }
}

initDb();

function readDb(): any {
  try {
    initDb();
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading JSON database fallback:", err);
    return {
      users: [],
      tasks: [],
      habits: [],
      directives: [],
      dailyPlans: [],
      reflections: [],
      reminders: [],
      focusSessions: [],
      productivityDna: [],
      journalInsights: [],
      userProfileSummary: []
    };
  }
}

function writeDb(data: any) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Error writing to JSON database fallback:", err);
  }
}

export const userRepo = {
  async getByEmail(email: string): Promise<any | null> {
    const db = readDb();
    const user = db.users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
    return user || null;
  },

  async getById(id: string): Promise<any | null> {
    const db = readDb();
    const user = db.users.find((u: any) => u.id === id);
    return user || null;
  },

  async create(user: { id: string, name: string, email: string, passwordHash: string, createdAt: string }): Promise<void> {
    const db = readDb();
    db.users.push(user);
    writeDb(db);
  },

  async healthCheck(): Promise<boolean> {
    try {
      readDb();
      return true;
    } catch {
      return false;
    }
  }
};

export const taskRepo = {
  async getAll(): Promise<Task[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.tasks || [])
      .filter((t: any) => t.userId === userId)
      .map((r: any) => ({
        id: r.id,
        title: r.title,
        deadline: r.deadline || '',
        importance: r.importance,
        duration: r.duration,
        completed: r.completed,
        completedAt: r.completedAt || undefined,
        createdAt: r.createdAt,
        aiPriorityScore: r.aiPriorityScore || undefined,
        aiRank: r.aiRank || undefined,
        aiOptimalTime: r.aiOptimalTime || undefined,
        aiReasoning: r.aiReasoning || undefined,
        aiCategory: r.aiCategory || undefined,
        subtasks: r.subtasks || undefined,
        isRescheduled: r.isRescheduled || undefined,
      }));
  },

  async getRecent(days: number): Promise<Task[]> {
    const userId = getUserId();
    const db = readDb();
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffStr = cutoff.toISOString();
    return (db.tasks || [])
      .filter((r: any) => r.userId === userId && (r.createdAt >= cutoffStr || (r.completedAt && r.completedAt >= cutoffStr) || !r.completed))
      .map((r: any) => ({
        id: r.id,
        title: r.title,
        deadline: r.deadline || '',
        importance: r.importance,
        duration: r.duration,
        completed: r.completed,
        completedAt: r.completedAt || undefined,
        createdAt: r.createdAt,
        aiPriorityScore: r.aiPriorityScore || undefined,
        aiRank: r.aiRank || undefined,
        aiOptimalTime: r.aiOptimalTime || undefined,
        aiReasoning: r.aiReasoning || undefined,
        aiCategory: r.aiCategory || undefined,
        subtasks: r.subtasks || undefined,
        isRescheduled: r.isRescheduled || undefined,
      }));
  },

  async getIncomplete(): Promise<Task[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.tasks || [])
      .filter((r: any) => r.userId === userId && !r.completed)
      .map((r: any) => ({
        id: r.id,
        title: r.title,
        deadline: r.deadline || '',
        importance: r.importance,
        duration: r.duration,
        completed: r.completed,
        completedAt: r.completedAt || undefined,
        createdAt: r.createdAt,
        aiPriorityScore: r.aiPriorityScore || undefined,
        aiRank: r.aiRank || undefined,
        aiOptimalTime: r.aiOptimalTime || undefined,
        aiReasoning: r.aiReasoning || undefined,
        aiCategory: r.aiCategory || undefined,
        subtasks: r.subtasks || undefined,
        isRescheduled: r.isRescheduled || undefined,
      }));
  },

  async saveAll(newTasks: Task[]): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const newIds = newTasks.map(t => t.id);
    
    // Delete non-matching tasks for this user
    db.tasks = (db.tasks || []).filter((t: any) => t.userId !== userId || newIds.includes(t.id));

    // Upsert tasks
    newTasks.forEach(t => {
      const existingIdx = db.tasks.findIndex((item: any) => item.id === t.id);
      const record = {
        id: t.id,
        userId: userId,
        title: t.title,
        deadline: t.deadline,
        importance: t.importance,
        duration: t.duration,
        completed: t.completed,
        completedAt: t.completedAt || null,
        createdAt: t.createdAt,
        aiPriorityScore: t.aiPriorityScore || null,
        aiRank: t.aiRank || null,
        aiOptimalTime: t.aiOptimalTime || null,
        aiReasoning: t.aiReasoning || null,
        aiCategory: t.aiCategory || null,
        subtasks: t.subtasks || [],
        isRescheduled: t.isRescheduled || false,
      };

      if (existingIdx >= 0) {
        db.tasks[existingIdx] = record;
      } else {
        db.tasks.push(record);
      }
    });

    writeDb(db);
  }
};

export const habitRepo = {
  async getAll(): Promise<Habit[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.habits || [])
      .filter((r: any) => r.userId === userId)
      .map((r: any) => ({
        id: r.id,
        title: r.title,
        frequency: r.frequency,
        createdAt: r.createdAt,
        completedDays: r.completedDays || [],
        streak: r.streak || 0,
        bestStreak: r.bestStreak || 0
      }));
  },

  async getActive(): Promise<Habit[]> {
    return this.getAll();
  },

  async saveAll(newHabits: Habit[]): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const newIds = newHabits.map(h => h.id);

    // Delete non-matching habits for this user
    db.habits = (db.habits || []).filter((h: any) => h.userId !== userId || newIds.includes(h.id));

    // Upsert habits
    newHabits.forEach(h => {
      const existingIdx = db.habits.findIndex((item: any) => item.id === h.id);
      const record = {
        id: h.id,
        userId: userId,
        title: h.title,
        frequency: h.frequency,
        createdAt: h.createdAt,
        completedDays: h.completedDays || [],
        streak: h.streak || 0,
        bestStreak: h.bestStreak || 0
      };

      if (existingIdx >= 0) {
        db.habits[existingIdx] = record;
      } else {
        db.habits.push(record);
      }
    });

    writeDb(db);
  }
};

export const directiveRepo = {
  async get(): Promise<string> {
    const userId = getUserId();
    const db = readDb();
    const record = (db.directives || []).find((d: any) => d.userId === userId);
    return record ? record.directive : "";
  },

  async save(directive: string): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const existingIdx = (db.directives || []).findIndex((d: any) => d.userId === userId);
    
    if (existingIdx >= 0) {
      db.directives[existingIdx].directive = directive;
    } else {
      db.directives.push({ id: `default_${userId}`, userId, directive });
    }
    writeDb(db);
  }
};

export const dailyPlanRepo = {
  async getLatest(): Promise<any | null> {
    const userId = getUserId();
    const db = readDb();
    const records = (db.dailyPlans || []).filter((p: any) => p.userId === userId);
    if (records.length === 0) return null;
    return records.sort((a: any, b: any) => b.date.localeCompare(a.date))[0];
  },

  async save(plan: any): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const id = `plan_${userId}_${plan.date}`;
    const existingIdx = (db.dailyPlans || []).findIndex((p: any) => p.id === id);

    const record = {
      id,
      userId,
      date: plan.date,
      events: plan.events || [],
      insights: plan.insights || "",
      productivityScore: plan.productivityScore || 78,
      productivityTrend: plan.productivityTrend || "neutral"
    };

    if (existingIdx >= 0) {
      db.dailyPlans[existingIdx] = record;
    } else {
      db.dailyPlans.push(record);
    }
    writeDb(db);
  }
};

export const reflectionRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.reflections || []).filter((r: any) => r.userId === userId);
  },

  async getRecent(days: number): Promise<any[]> {
    const userId = getUserId();
    const db = readDb();
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffStr = cutoff.toISOString().split('T')[0];
    return (db.reflections || []).filter((r: any) => r.userId === userId && r.date >= cutoffStr);
  },

  async save(reflection: any): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const id = reflection.id || `ref_${reflection.date || new Date().toISOString().split('T')[0]}_${Date.now()}`;
    const existingIdx = (db.reflections || []).findIndex((r: any) => r.id === id);

    const record = {
      id,
      userId,
      date: reflection.date || new Date().toISOString().split('T')[0],
      completionRate: reflection.completionRate || 0,
      habitConsistency: reflection.habitConsistency || 0,
      focusScore: reflection.focusScore || 0,
      momentumScore: reflection.momentumScore || 0,
      missedWork: reflection.missedWork || 0,
      extraWork: reflection.extraWork || 0,
      dailyReflection: reflection.dailyReflection || "",
      performanceAnalysis: reflection.performanceAnalysis || "",
      improvementSuggestions: reflection.improvementSuggestions || [],
      personalizedCoaching: reflection.personalizedCoaching || "",
      positiveReinforcement: reflection.positiveReinforcement || "",
      futurePlanningSuggestions: reflection.futurePlanningSuggestions || [],
      distractionPatterns: reflection.distractionPatterns || [],
      energyPatterns: reflection.energyPatterns || [],
      weeklyTrends: reflection.weeklyTrends || ""
    };

    if (existingIdx >= 0) {
      db.reflections[existingIdx] = record;
    } else {
      db.reflections.push(record);
    }
    writeDb(db);
  }
};

export const reminderRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.reminders || []).filter((r: any) => r.userId === userId);
  },

  async save(reminder: { id?: string, taskId?: string, type: string, sentAt: string }): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const id = reminder.id || `rem_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

    const record = {
      id,
      userId,
      taskId: reminder.taskId || null,
      type: reminder.type,
      sentAt: reminder.sentAt
    };

    db.reminders.push(record);
    writeDb(db);
  }
};

export const focusSessionRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.focusSessions || []).filter((s: any) => s.userId === userId);
  },

  async getRecentFocusSessions(days: number): Promise<any[]> {
    const userId = getUserId();
    const db = readDb();
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffStr = cutoff.toISOString();
    return (db.focusSessions || []).filter((r: any) => r.userId === userId && (r.createdAt >= cutoffStr || r.startTime >= cutoffStr));
  },

  async save(session: any): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const existingIdx = (db.focusSessions || []).findIndex((s: any) => s.id === session.id);

    const record = {
      id: session.id,
      userId,
      taskId: session.taskId || null,
      startTime: session.startTime,
      endTime: session.endTime || null,
      durationMinutes: session.durationMinutes,
      completed: session.completed,
      createdAt: session.createdAt || new Date().toISOString()
    };

    if (existingIdx >= 0) {
      db.focusSessions[existingIdx] = record;
    } else {
      db.focusSessions.push(record);
    }
    writeDb(db);
  }
};

export const productivityDnaRepo = {
  async getLatest(): Promise<any | null> {
    const userId = getUserId();
    const db = readDb();
    const records = (db.productivityDna || []).filter((d: any) => d.userId === userId);
    if (records.length === 0) return null;
    return records.sort((a: any, b: any) => b.analysisDate.localeCompare(a.analysisDate))[0];
  },

  async save(dna: any): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const id = dna.id || `dna_${dna.analysisDate || new Date().toISOString().split('T')[0]}_${userId}`;
    const existingIdx = (db.productivityDna || []).findIndex((d: any) => d.id === id);

    const record = {
      id,
      userId,
      analysisDate: dna.analysisDate || new Date().toISOString().split('T')[0],
      bestWorkHours: dna.bestWorkHours,
      productiveDay: dna.productiveDay,
      completionRate: dna.completionRate,
      focusScore: dna.focusScore,
      habitScore: dna.habitScore,
      procrastinationScore: dna.procrastinationScore,
      recommendations: dna.recommendations || []
    };

    if (existingIdx >= 0) {
      db.productivityDna[existingIdx] = record;
    } else {
      db.productivityDna.push(record);
    }
    writeDb(db);
  }
};

export const journalInsightsRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    const db = readDb();
    return (db.journalInsights || []).filter((j: any) => j.userId === userId);
  },

  async getByJournalId(journalId: string): Promise<any | null> {
    const userId = getUserId();
    const db = readDb();
    const records = (db.journalInsights || []).filter((j: any) => j.journalId === journalId && j.userId === userId);
    return records.length > 0 ? records[0] : null;
  },

  async save(insight: any): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const id = insight.id || `insight_${Date.now()}`;
    const existingIdx = (db.journalInsights || []).findIndex((j: any) => j.id === id);

    const record = {
      id,
      userId,
      journalId: insight.journalId,
      analysis: insight.analysis,
      improvements: insight.improvements || [],
      score: insight.score,
      createdAt: insight.createdAt || new Date().toISOString()
    };

    if (existingIdx >= 0) {
      db.journalInsights[existingIdx] = record;
    } else {
      db.journalInsights.push(record);
    }
    writeDb(db);
  }
};

export const userProfileSummaryRepo = {
  async get(): Promise<any | null> {
    const userId = getUserId();
    const db = readDb();
    const id = `default_${userId}`;
    const record = (db.userProfileSummary || []).find((s: any) => s.id === id);
    return record ? record.summary : null;
  },

  async save(summary: any): Promise<void> {
    const userId = getUserId();
    const db = readDb();
    const id = `default_${userId}`;
    const existingIdx = (db.userProfileSummary || []).findIndex((s: any) => s.id === id);

    const record = {
      id,
      userId,
      summary,
      updatedAt: new Date().toISOString()
    };

    if (existingIdx >= 0) {
      db.userProfileSummary[existingIdx] = record;
    } else {
      db.userProfileSummary.push(record);
    }
    writeDb(db);
  }
};
