import { UserSettings } from '../types';

// Singleton Voice Manager to coordinate speech across the application
class VoiceManager {
  private static instance: VoiceManager;
  private queue: { message: string; settings: UserSettings | null }[] = [];
  private isSpeaking: boolean = false;
  private voices: SpeechSynthesisVoice[] = [];
  private initialized: boolean = false;
  private activeUtterance: SpeechSynthesisUtterance | null = null;

  private constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.init();
    }
  }

  public static getInstance(): VoiceManager {
    if (typeof window === 'undefined') {
      return {} as VoiceManager;
    }
    // Prevent duplicate initialization under React Strict Mode or hot-reloading
    if (!(window as any)._voiceManagerInstance) {
      (window as any)._voiceManagerInstance = new VoiceManager();
    }
    return (window as any)._voiceManagerInstance;
  }

  private init() {
    if (this.initialized) return;
    this.initialized = true;

    const loadVoices = () => {
      this.voices = window.speechSynthesis.getVoices();
      console.log(`[VoiceManager] Loaded ${this.voices.length} voices.`);
    };

    // Attempt to load voices immediately
    loadVoices();

    // Listen to voiceschanged event to ensure voices are populated correctly when ready
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    } else {
      window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    }
  }

  public speak(message: string, settings: UserSettings | null = null) {
    const enabled = settings ? settings.voiceEnabled : true;
    if (!enabled || !('speechSynthesis' in window)) {
      console.warn("[VoiceManager] Speech synthesis not enabled or not supported in this window context.");
      return;
    }

    // Add request to the speech queue
    this.queue.push({ message, settings });
    this.processQueue();
  }

  private processQueue() {
    // Only process next item if not currently speaking and queue has elements
    if (this.isSpeaking || this.queue.length === 0) {
      return;
    }

    const next = this.queue.shift();
    if (!next) return;

    this.speakUtterance(next.message, next.settings);
  }

  private speakUtterance(message: string, settings: UserSettings | null) {
    try {
      // Resume if engine is stuck in paused state
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const utterance = new SpeechSynthesisUtterance(message);
      this.activeUtterance = utterance;
      this.isSpeaking = true;

      // Keep reference globally to prevent garbage collection in Chrome
      if (typeof window !== 'undefined') {
        (window as any)._activeUtterances = (window as any)._activeUtterances || [];
        (window as any)._activeUtterances.push(utterance);
      }

      const cleanUp = (shouldProcessNext = true) => {
        this.isSpeaking = false;
        this.activeUtterance = null;
        
        if (typeof window !== 'undefined' && (window as any)._activeUtterances) {
          const index = (window as any)._activeUtterances.indexOf(utterance);
          if (index > -1) {
            (window as any)._activeUtterances.splice(index, 1);
          }
        }

        if (shouldProcessNext) {
          this.processQueue();
        }
      };

      utterance.onstart = () => {
        console.log("[VoiceManager] Utterance started speaking:", message.substring(0, 40) + "...");
      };

      utterance.onend = () => {
        console.log("[VoiceManager] Utterance ended speaking successfully.");
        cleanUp(true);
      };

      utterance.onerror = (e) => {
        if (e.error !== 'interrupted') {
          console.warn("[VoiceManager] Utterance error event:", e.error, e);
          cleanUp(true);
        } else {
          console.log("[VoiceManager] Utterance was interrupted.");
          // Clear remaining queue if interrupted externally
          this.queue = [];
          cleanUp(false);
        }
      };

      // Select voice dynamically from loaded voices
      const voices = this.voices;
      let preferredVoice = null;

      const isFemaleRequested = settings?.voiceGender === 'female';

      if (isFemaleRequested) {
        // Try to find a pleasant female voice
        preferredVoice = voices.find(v => 
          v.name.includes('Samantha') || 
          v.name.includes('Female') || 
          v.name.includes('Zira') || 
          (v.name.includes('Google') && !v.name.includes('Male') && v.lang.startsWith('en'))
        );
      } else {
        // Default / Male voice: "Jarvis" style (Sophisticated, smooth British Male)
        // 1. Prioritize Daniel (iOS / macOS premium British Male)
        preferredVoice = voices.find(v => v.name.includes('Daniel'));
        
        // 2. Prioritize Google UK English Male
        if (!preferredVoice) {
          preferredVoice = voices.find(v => v.name.includes('Google UK English Male'));
        }
        
        // 3. Try to find any en-GB (UK English) male voice
        if (!preferredVoice) {
          preferredVoice = voices.find(v => 
            v.lang.toLowerCase().startsWith('en-gb') && 
            (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('guy') || v.name.toLowerCase().includes('george'))
          );
        }

        // 4. Try any UK English voice (which could be smooth British)
        if (!preferredVoice) {
          preferredVoice = voices.find(v => v.lang.toLowerCase().startsWith('en-gb'));
        }

        // 5. Try Google US English Male or any Google Male voice
        if (!preferredVoice) {
          preferredVoice = voices.find(v => 
            v.name.toLowerCase().includes('google') && 
            v.name.toLowerCase().includes('male') && 
            v.lang.toLowerCase().startsWith('en')
          );
        }

        // 6. Microsoft David or standard David (often smooth US male voice)
        if (!preferredVoice) {
          preferredVoice = voices.find(v => v.name.includes('David') || v.name.includes('Microsoft David'));
        }

        // 7. General Male voice fallback
        if (!preferredVoice) {
          preferredVoice = voices.find(v => 
            v.name.toLowerCase().includes('male') && 
            v.lang.toLowerCase().startsWith('en')
          );
        }
      }

      // Final ultimate English voice fallback if nothing matched
      if (!preferredVoice) {
        preferredVoice = voices.find(v => v.lang.toLowerCase().startsWith('en'));
      }

      if (preferredVoice) {
        utterance.voice = preferredVoice;
        console.log(`[VoiceManager] Selected voice: ${preferredVoice.name} (${preferredVoice.lang})`);
      }

      // Set voice options
      // A slightly slower rate (0.92) and slightly lower pitch (0.95) sounds more elegant, poised, and deep, like Jarvis.
      utterance.rate = settings?.voiceSpeed ?? 0.92; 
      utterance.pitch = 0.95;
      utterance.volume = settings?.voiceVolume ?? 1.0;

      // Speak directly using onstart/onend/onerror listeners to manage the cycle
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error("[VoiceManager] Speech Synthesis critical failure:", err);
      this.isSpeaking = false;
      this.activeUtterance = null;
      this.processQueue();
    }
  }
}

// Global user gesture unlocker to prime SpeechSynthesis and bypass browser autoplay blockages
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  const unlockSpeech = () => {
    try {
      const silentUtterance = new SpeechSynthesisUtterance('');
      silentUtterance.volume = 0;
      window.speechSynthesis.speak(silentUtterance);
      
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
      console.log("[VoiceService] Web Speech API unlocked successfully via initial user gesture.");
      
      // Cleanup event listeners
      window.removeEventListener('click', unlockSpeech);
      window.removeEventListener('keydown', unlockSpeech);
      window.removeEventListener('touchstart', unlockSpeech);
    } catch (e) {
      console.warn("[VoiceService] Failed to unlock speech synthesis on user gesture:", e);
    }
  };

  window.addEventListener('click', unlockSpeech, { once: true, capture: true });
  window.addEventListener('keydown', unlockSpeech, { once: true, capture: true });
  window.addEventListener('touchstart', unlockSpeech, { once: true, capture: true });
}

// Preserve existing public API
export const speak = (message: string, settings: UserSettings | null = null) => {
  VoiceManager.getInstance().speak(message, settings);
};

export const notify = (title: string, body: string, enabled: boolean = true) => {
  if (!enabled || !('Notification' in window)) return;
  
  const triggerNotification = () => {
    try {
      new Notification(title, {
        body,
        icon: '/vite.svg', // generic fallback icon
        silent: true // We'll handle audio via TTS
      });
    } catch (err) {
      console.error("[VoiceService] Failed to create Notification instance:", err);
    }
  };

  if (Notification.permission === 'granted') {
    triggerNotification();
  } else if (Notification.permission === 'default') {
    Notification.requestPermission().then(permission => {
      if (permission === 'granted') {
        triggerNotification();
      }
    });
  }
};
