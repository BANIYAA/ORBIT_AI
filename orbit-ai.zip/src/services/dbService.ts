import { eq, sql, notInArray, and } from 'drizzle-orm';
import { db } from '../db';
import { tasks, habits, dailyPlans, reflections, reminders, directives, focusSessions, productivityDna, journalInsights, userProfileSummary, users } from '../db/schema';
import { Task, Habit, DailyPlanResponse, ReflectionData } from '../types';
import { AsyncLocalStorage } from 'async_hooks';
import * as jsonRepos from './jsonDbService';

export const sessionContext = new AsyncLocalStorage<{ userId: string }>();

function getUserId() {
  const store = sessionContext.getStore();
  if (!store || !store.userId) throw new Error("Unauthorized: No user session");
  return store.userId;
}

// Proxy delegate helper for routing to JSON database when process.env.DATABASE_MODE === 'json'
const delegate = <T extends object>(pgRepo: T, jsonRepoName: string): T => {
  return new Proxy(pgRepo, {
    get(target, prop, receiver) {
      if (process.env.DATABASE_MODE === 'json') {
        const jsonRepo = (jsonRepos as any)[jsonRepoName];
        if (!jsonRepo) {
          throw new Error(`JSON repository ${jsonRepoName} not found`);
        }
        const val = jsonRepo[prop];
        if (typeof val === 'function') {
          return val.bind(jsonRepo);
        }
        return val;
      }
      return Reflect.get(target, prop, receiver);
    }
  }) as T;
};

// Users repository
const pgUserRepo = {
  async getByEmail(email: string) {
    const records = await db.select().from(users).where(eq(users.email, email));
    return records[0] || null;
  },
  async getById(id: string) {
    const records = await db.select().from(users).where(eq(users.id, id));
    return records[0] || null;
  },
  async create(user: any) {
    await db.insert(users).values(user);
  },
  async healthCheck() {
    await db.select().from(users).limit(1);
    return true;
  }
};

export const userRepo = delegate(pgUserRepo, 'userRepo');

// Tasks repository
const pgTaskRepo = {
  async getAll(): Promise<Task[]> {
    const userId = getUserId();
    const records = await db.select().from(tasks).where(eq(tasks.userId, userId));
    return records.map(r => ({
      id: r.id,
      title: r.title,
      deadline: r.deadline ?? '',
      importance: r.importance as 'high' | 'medium' | 'low',
      duration: r.duration,
      completed: r.completed,
      completedAt: r.completedAt ?? undefined,
      createdAt: r.createdAt,
      aiPriorityScore: r.aiPriorityScore ?? undefined,
      aiRank: r.aiRank ?? undefined,
      aiOptimalTime: r.aiOptimalTime ?? undefined,
      aiReasoning: r.aiReasoning ?? undefined,
      aiCategory: r.aiCategory ?? undefined,
      subtasks: r.subtasks as any[] ?? undefined,
      isRescheduled: r.isRescheduled ?? undefined,
    }));
  },

  async getRecent(days: number): Promise<Task[]> {
    const userId = getUserId();
    const records = await db.select().from(tasks).where(eq(tasks.userId, userId));
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffStr = cutoff.toISOString();
    return records
      .filter(r => r.createdAt >= cutoffStr || (r.completedAt && r.completedAt >= cutoffStr) || !r.completed)
      .map(r => ({
      id: r.id,
      title: r.title,
      deadline: r.deadline ?? '',
      importance: r.importance as 'high' | 'medium' | 'low',
      duration: r.duration,
      completed: r.completed,
      completedAt: r.completedAt ?? undefined,
      createdAt: r.createdAt,
      aiPriorityScore: r.aiPriorityScore ?? undefined,
      aiRank: r.aiRank ?? undefined,
      aiOptimalTime: r.aiOptimalTime ?? undefined,
      aiReasoning: r.aiReasoning ?? undefined,
      aiCategory: r.aiCategory ?? undefined,
      subtasks: r.subtasks as any[] ?? undefined,
      isRescheduled: r.isRescheduled ?? undefined,
    }));
  },

  async getIncomplete(): Promise<Task[]> {
    const userId = getUserId();
    const records = await db.select().from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.completed, false)));
    return records.map(r => ({
      id: r.id,
      title: r.title,
      deadline: r.deadline ?? '',
      importance: r.importance as 'high' | 'medium' | 'low',
      duration: r.duration,
      completed: r.completed,
      completedAt: r.completedAt ?? undefined,
      createdAt: r.createdAt,
      aiPriorityScore: r.aiPriorityScore ?? undefined,
      aiRank: r.aiRank ?? undefined,
      aiOptimalTime: r.aiOptimalTime ?? undefined,
      aiReasoning: r.aiReasoning ?? undefined,
      aiCategory: r.aiCategory ?? undefined,
      subtasks: r.subtasks as any[] ?? undefined,
      isRescheduled: r.isRescheduled ?? undefined,
    }));
  },

  async saveAll(newTasks: Task[]): Promise<void> {
    const userId = getUserId();
    await db.transaction(async (tx) => {
      // Lock table to prevent deadlocks on concurrent bulk updates
      await tx.execute(sql`LOCK TABLE tasks IN EXCLUSIVE MODE`);
      
      const newIds = newTasks.map(t => t.id);
      if (newIds.length > 0) {
        await tx.delete(tasks).where(and(eq(tasks.userId, userId), notInArray(tasks.id, newIds)));
      } else {
        await tx.delete(tasks).where(eq(tasks.userId, userId));
      }

      if (newTasks.length > 0) {
        const chunkSize = 500;
        for (let i = 0; i < newTasks.length; i += chunkSize) {
          const chunk = newTasks.slice(i, i + chunkSize);
          await tx.insert(tasks).values(
            chunk.map(t => ({
              id: t.id,
              userId: userId,
              title: t.title,
              deadline: t.deadline,
              importance: t.importance,
              duration: t.duration,
              completed: t.completed,
              completedAt: t.completedAt,
              createdAt: t.createdAt,
              aiPriorityScore: t.aiPriorityScore,
              aiRank: t.aiRank,
              aiOptimalTime: t.aiOptimalTime,
              aiReasoning: t.aiReasoning,
              aiCategory: t.aiCategory,
              subtasks: t.subtasks,
              isRescheduled: t.isRescheduled,
            }))
          ).onConflictDoUpdate({
            target: tasks.id,
            set: {
              title: sql`EXCLUDED.title`,
              deadline: sql`EXCLUDED.deadline`,
              importance: sql`EXCLUDED.importance`,
              duration: sql`EXCLUDED.duration`,
              completed: sql`EXCLUDED.completed`,
              completedAt: sql`EXCLUDED.completed_at`,
              createdAt: sql`EXCLUDED.created_at`,
              aiPriorityScore: sql`EXCLUDED.ai_priority_score`,
              aiRank: sql`EXCLUDED.ai_rank`,
              aiOptimalTime: sql`EXCLUDED.ai_optimal_time`,
              aiReasoning: sql`EXCLUDED.ai_reasoning`,
              aiCategory: sql`EXCLUDED.ai_category`,
              subtasks: sql`EXCLUDED.subtasks`,
              isRescheduled: sql`EXCLUDED.is_rescheduled`,
            }
          });
        }
      }
    });
  }
};

export const taskRepo = delegate(pgTaskRepo, 'taskRepo');

// Habits repository
const pgHabitRepo = {
  async getAll(): Promise<Habit[]> {
    const userId = getUserId();
    const records = await db.select().from(habits).where(eq(habits.userId, userId));
    return records.map(r => ({
      id: r.id,
      title: r.title,
      frequency: r.frequency as 'daily' | 'weekly',
      createdAt: r.createdAt,
      completedDays: r.completedDays || [],
      streak: r.streak,
      bestStreak: r.bestStreak
    }));
  },

  async getActive(): Promise<Habit[]> {
    return this.getAll();
  },

  async saveAll(newHabits: Habit[]): Promise<void> {
    const userId = getUserId();
    await db.transaction(async (tx) => {
      await tx.execute(sql`LOCK TABLE habits IN EXCLUSIVE MODE`);
      
      const newIds = newHabits.map(h => h.id);
      if (newIds.length > 0) {
        await tx.delete(habits).where(and(eq(habits.userId, userId), notInArray(habits.id, newIds)));
      } else {
        await tx.delete(habits).where(eq(habits.userId, userId));
      }

      if (newHabits.length > 0) {
        const chunkSize = 500;
        for (let i = 0; i < newHabits.length; i += chunkSize) {
          const chunk = newHabits.slice(i, i + chunkSize);
          await tx.insert(habits).values(
            chunk.map(h => ({
              id: h.id,
              userId: userId,
              title: h.title,
              frequency: h.frequency,
              createdAt: h.createdAt,
              completedDays: h.completedDays,
              streak: h.streak,
              bestStreak: h.bestStreak
            }))
          ).onConflictDoUpdate({
            target: habits.id,
            set: {
              title: sql`EXCLUDED.title`,
              frequency: sql`EXCLUDED.frequency`,
              createdAt: sql`EXCLUDED.created_at`,
              completedDays: sql`EXCLUDED.completed_days`,
              streak: sql`EXCLUDED.streak`,
              bestStreak: sql`EXCLUDED.best_streak`
            }
          });
        }
      }
    });
  }
};

export const habitRepo = delegate(pgHabitRepo, 'habitRepo');

// Directives repository
const pgDirectiveRepo = {
  async get(): Promise<string> {
    const userId = getUserId();
    const id = `default_${userId}`;
    const records = await db.select().from(directives).where(eq(directives.id, id));
    return records.length > 0 ? records[0].directive : "";
  },

  async save(directive: string): Promise<void> {
    const userId = getUserId();
    const id = `default_${userId}`;
    await db.insert(directives)
      .values({ id, userId, directive })
      .onConflictDoUpdate({
        target: directives.id,
        set: { directive }
      });
  }
};

export const directiveRepo = delegate(pgDirectiveRepo, 'directiveRepo');

// Daily Plans repository
const pgDailyPlanRepo = {
  async getLatest(): Promise<any | null> {
    const userId = getUserId();
    const records = await db.select().from(dailyPlans).where(eq(dailyPlans.userId, userId));
    if (records.length === 0) return null;
    return records.sort((a, b) => b.date.localeCompare(a.date))[0];
  },
  async save(plan: any): Promise<void> {
    const userId = getUserId();
    const id = `plan_${userId}_${plan.date}`;
    await db.insert(dailyPlans)
      .values({
        id,
        userId,
        date: plan.date,
        events: plan.events,
        insights: plan.insights,
        productivityScore: plan.productivityScore,
        productivityTrend: plan.productivityTrend
      })
      .onConflictDoUpdate({
        target: dailyPlans.id,
        set: {
          events: plan.events,
          insights: plan.insights,
          productivityScore: plan.productivityScore,
          productivityTrend: plan.productivityTrend
        }
      });
  }
};

export const dailyPlanRepo = delegate(pgDailyPlanRepo, 'dailyPlanRepo');

// Reflections repository
const pgReflectionRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    return await db.select().from(reflections).where(eq(reflections.userId, userId));
  },

  async getRecent(days: number): Promise<any[]> {
    const userId = getUserId();
    const records = await db.select().from(reflections).where(eq(reflections.userId, userId));
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffStr = cutoff.toISOString().split('T')[0];
    return records.filter(r => r.date >= cutoffStr);
  },

  async save(reflection: any): Promise<void> {
    const userId = getUserId();
    const id = reflection.id || `ref_${reflection.date || new Date().toISOString().split('T')[0]}_${Date.now()}`;
    await db.insert(reflections)
      .values({
        id,
        userId,
        date: reflection.date || new Date().toISOString().split('T')[0],
        completionRate: reflection.completionRate || 0,
        habitConsistency: reflection.habitConsistency || 0,
        focusScore: reflection.focusScore || 0,
        momentumScore: reflection.momentumScore || 0,
        missedWork: reflection.missedWork || 0,
        extraWork: reflection.extraWork || 0,
        dailyReflection: reflection.dailyReflection || "",
        performanceAnalysis: reflection.performanceAnalysis || "",
        improvementSuggestions: reflection.improvementSuggestions || [],
        personalizedCoaching: reflection.personalizedCoaching || "",
        positiveReinforcement: reflection.positiveReinforcement || "",
        futurePlanningSuggestions: reflection.futurePlanningSuggestions || [],
        distractionPatterns: reflection.distractionPatterns || [],
        energyPatterns: reflection.energyPatterns || [],
        weeklyTrends: reflection.weeklyTrends || ""
      })
      .onConflictDoUpdate({
        target: reflections.id,
        set: {
          date: reflection.date || new Date().toISOString().split('T')[0],
          completionRate: reflection.completionRate || 0,
          habitConsistency: reflection.habitConsistency || 0,
          focusScore: reflection.focusScore || 0,
          momentumScore: reflection.momentumScore || 0,
          missedWork: reflection.missedWork || 0,
          extraWork: reflection.extraWork || 0,
          dailyReflection: reflection.dailyReflection || "",
          performanceAnalysis: reflection.performanceAnalysis || "",
          improvementSuggestions: reflection.improvementSuggestions || [],
          personalizedCoaching: reflection.personalizedCoaching || "",
          positiveReinforcement: reflection.positiveReinforcement || "",
          futurePlanningSuggestions: reflection.futurePlanningSuggestions || [],
          distractionPatterns: reflection.distractionPatterns || [],
          energyPatterns: reflection.energyPatterns || [],
          weeklyTrends: reflection.weeklyTrends || ""
        }
      });
  }
};

export const reflectionRepo = delegate(pgReflectionRepo, 'reflectionRepo');

// Reminders repository
const pgReminderRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    return await db.select().from(reminders).where(eq(reminders.userId, userId));
  },

  async save(reminder: { id?: string, taskId?: string, type: string, sentAt: string }): Promise<void> {
    const userId = getUserId();
    const id = reminder.id || `rem_${Date.now()}_${Math.floor(Math.random()*1000)}`;
    
    let finalTaskId = reminder.taskId || null;
    if (finalTaskId) {
      const existingTask = await db.select({ id: tasks.id }).from(tasks).where(eq(tasks.id, finalTaskId)).limit(1);
      if (existingTask.length === 0) {
        finalTaskId = null;
      }
    }

    await db.insert(reminders).values({
      id,
      userId,
      taskId: finalTaskId,
      type: reminder.type,
      sentAt: reminder.sentAt
    });
  }
};

export const reminderRepo = delegate(pgReminderRepo, 'reminderRepo');

// Focus Sessions repository
const pgFocusSessionRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    const records = await db.select().from(focusSessions).where(eq(focusSessions.userId, userId));
    return records;
  },

  async getRecentFocusSessions(days: number): Promise<any[]> {
    const userId = getUserId();
    const records = await db.select().from(focusSessions).where(eq(focusSessions.userId, userId));
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    const cutoffStr = cutoff.toISOString();
    return records.filter(r => r.createdAt >= cutoffStr || r.startTime >= cutoffStr);
  },

  async save(session: any): Promise<void> {
    const userId = getUserId();
    
    let finalTaskId = session.taskId || null;
    if (finalTaskId) {
      const existingTask = await db.select({ id: tasks.id }).from(tasks).where(eq(tasks.id, finalTaskId)).limit(1);
      if (existingTask.length === 0) {
        finalTaskId = null;
      }
    }

    await db.insert(focusSessions)
      .values({
        id: session.id,
        userId,
        taskId: finalTaskId,
        startTime: session.startTime,
        endTime: session.endTime || null,
        durationMinutes: session.durationMinutes,
        completed: session.completed,
        createdAt: session.createdAt || new Date().toISOString()
      })
      .onConflictDoUpdate({
        target: focusSessions.id,
        set: {
          endTime: session.endTime || null,
          durationMinutes: session.durationMinutes,
          completed: session.completed
        }
      });
  }
};

export const focusSessionRepo = delegate(pgFocusSessionRepo, 'focusSessionRepo');

// Productivity DNA repository
const pgProductivityDnaRepo = {
  async getLatest(): Promise<any | null> {
    const userId = getUserId();
    const records = await db.select().from(productivityDna).where(eq(productivityDna.userId, userId));
    if (records.length === 0) return null;
    return records.sort((a, b) => b.analysisDate.localeCompare(a.analysisDate))[0];
  },

  async save(dna: any): Promise<void> {
    const userId = getUserId();
    const id = dna.id || `dna_${dna.analysisDate || new Date().toISOString().split('T')[0]}_${userId}`;
    await db.insert(productivityDna)
      .values({
        id,
        userId,
        analysisDate: dna.analysisDate || new Date().toISOString().split('T')[0],
        bestWorkHours: dna.bestWorkHours,
        productiveDay: dna.productiveDay,
        completionRate: dna.completionRate,
        focusScore: dna.focusScore,
        habitScore: dna.habitScore,
        procrastinationScore: dna.procrastinationScore,
        recommendations: dna.recommendations || []
      })
      .onConflictDoUpdate({
        target: productivityDna.id,
        set: {
          analysisDate: dna.analysisDate || new Date().toISOString().split('T')[0],
          bestWorkHours: dna.bestWorkHours,
          productiveDay: dna.productiveDay,
          completionRate: dna.completionRate,
          focusScore: dna.focusScore,
          habitScore: dna.habitScore,
          procrastinationScore: dna.procrastinationScore,
          recommendations: dna.recommendations || []
        }
      });
  }
};

export const productivityDnaRepo = delegate(pgProductivityDnaRepo, 'productivityDnaRepo');

// Journal Insights repository
const pgJournalInsightsRepo = {
  async getAll(): Promise<any[]> {
    const userId = getUserId();
    return await db.select().from(journalInsights).where(eq(journalInsights.userId, userId));
  },

  async getByJournalId(journalId: string): Promise<any | null> {
    const userId = getUserId();
    const records = await db.select().from(journalInsights).where(and(eq(journalInsights.journalId, journalId), eq(journalInsights.userId, userId)));
    if (records.length === 0) return null;
    return records[0];
  },

  async save(insight: any): Promise<void> {
    const userId = getUserId();
    const id = insight.id || `insight_${Date.now()}`;
    await db.insert(journalInsights)
      .values({
        id,
        userId,
        journalId: insight.journalId,
        analysis: insight.analysis,
        improvements: insight.improvements || [],
        score: insight.score,
        createdAt: insight.createdAt || new Date().toISOString()
      })
      .onConflictDoUpdate({
        target: journalInsights.id,
        set: {
          journalId: insight.journalId,
          analysis: insight.analysis,
          improvements: insight.improvements || [],
          score: insight.score,
          createdAt: insight.createdAt || new Date().toISOString()
        }
      });
  }
};

export const journalInsightsRepo = delegate(pgJournalInsightsRepo, 'journalInsightsRepo');

// User Profile Summary repository
const pgUserProfileSummaryRepo = {
  async get(): Promise<any | null> {
    const userId = getUserId();
    const id = `default_${userId}`;
    const records = await db.select().from(userProfileSummary).where(eq(userProfileSummary.id, id));
    if (records.length === 0) return null;
    return records[0].summary;
  },

  async save(summary: any): Promise<void> {
    const userId = getUserId();
    const id = `default_${userId}`;
    await db.insert(userProfileSummary)
      .values({
        id,
        userId,
        summary,
        updatedAt: new Date().toISOString()
      })
      .onConflictDoUpdate({
        target: userProfileSummary.id,
        set: {
          summary,
          updatedAt: new Date().toISOString()
        }
      });
  }
};

export const userProfileSummaryRepo = delegate(pgUserProfileSummaryRepo, 'userProfileSummaryRepo');
