export function sanitizeText(input: string | undefined | null): string {
  if (!input) return "";
  
  // Strip HTML and scripts
  let sanitized = input.replace(/<[^>]*>?/gm, '');
  
  // Basic prompt injection mitigation: 
  // Remove or encode common injection triggers if needed, 
  // but for now, limiting system instruction override keywords:
  const injectionKeywords = [
    "Ignore all previous instructions",
    "System override",
    "You are now",
    "Disregard previous",
    "Forget instructions"
  ];
  
  for (const keyword of injectionKeywords) {
    const regex = new RegExp(keyword, 'gi');
    sanitized = sanitized.replace(regex, '[REDACTED]');
  }
  
  return sanitized.trim();
}

export function sanitizeTask(task: any) {
  if (!task) return task;
  return {
    ...task,
    title: sanitizeText(task.title),
    description: sanitizeText(task.description),
    aiReasoning: sanitizeText(task.aiReasoning),
  };
}

export function sanitizeHabit(habit: any) {
  if (!habit) return habit;
  return {
    ...habit,
    title: sanitizeText(habit.title),
    name: sanitizeText(habit.name),
  };
}

export function sanitizeJournal(journal: string | undefined) {
  return sanitizeText(journal);
}
