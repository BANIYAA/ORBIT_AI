export async function apiFetch(url: string | URL, options: RequestInit = {}): Promise<Response> {
  const token = localStorage.getItem('orbit_token');
  const googleToken = localStorage.getItem('google_token');
  const headers = new Headers(options.headers || {});

  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  if (googleToken && !headers.has('x-goog-workspace-access-token')) {
    headers.set('x-goog-workspace-access-token', googleToken);
  }

  // Ensure JSON requests have Content-Type: application/json if we are sending a body and it's not FormData
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const mergedOptions: RequestInit = {
    ...options,
    headers,
  };

  const maxRetries = 3;
  let delay = 1000;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, mergedOptions);
      if (response.status === 401) {
        const storedToken = localStorage.getItem('orbit_token');
        if (storedToken) {
          console.warn("[apiFetch] Token expired or invalid (401). Performing graceful logout.");
          localStorage.removeItem('orbit_token');
          localStorage.removeItem('google_token');
          localStorage.removeItem('orbit_user');
          localStorage.removeItem('orbit_onboarding_completed');
          window.location.reload();
        }
      }
      return response;
    } catch (error) {
      if (attempt === maxRetries) {
        console.warn(`[apiFetch Info] Request to ${url} failed after ${maxRetries} attempts:`, error);
        throw error;
      }
      console.warn(`[apiFetch Info] Request to ${url} failed (attempt ${attempt}/${maxRetries}). Retrying in ${delay}ms...`, error);
      await new Promise(resolve => setTimeout(resolve, delay));
      delay *= 2;
    }
  }
  throw new Error("apiFetch failed unexpectedly");
}
