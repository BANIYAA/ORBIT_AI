import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Orbit, 
  Sparkles, 
  Activity, 
  Trash2, 
  CalendarHeart, 
  Clock, 
  Flame, 
  ListTodo, 
  Shuffle, 
  LayoutDashboard,
  CircleHelp,
  RefreshCw,
  TriangleAlert,
  Brain,
  Settings,
  Cpu,
  Compass,
  MessageSquare,
  CircleCheck,
  Circle,
  Calendar
} from 'lucide-react';

import { Task, Habit, AIAnalysisResponse, DailyPlanResponse, ReflectionData, UserSettings, AuthState, User } from './types';
import { apiFetch } from './utils/apiFetch';
import TaskForm from './components/TaskForm';
import HabitForm from './components/HabitForm';
import MetricCards from './components/MetricCards';
import AIHeader from './components/AIHeader';
import OrbitTopBar from './components/OrbitTopBar';
import TaskList from './components/TaskList';
import HabitList from './components/HabitList';
import TodaysMission from './components/TodaysMission';
import DailyPlanView from './components/DailyPlanView';
import AICoachCard from './components/AICoachCard';
import NaturalLanguageCommand from './components/NaturalLanguageCommand';
import VoiceAssistant from './components/VoiceAssistant';
import SolarSystem from './components/SolarSystem';
import ReflectionEngine from './components/ReflectionEngine';
import AIHealthMonitor from './components/AIHealthMonitor';
import SettingsPanel from './components/SettingsPanel';
import SmartReminderEngine from './components/SmartReminderEngine';
import FocusMode from './components/FocusMode';
import ProductivityDnaView from './components/ProductivityDnaView';
import ProductivityIntelligenceView from './components/ProductivityIntelligenceView';
import HoloPanel from './components/3d/ui/HoloPanel';
import AuthScreen from './components/AuthScreen';
import OnboardingScreen from './components/OnboardingScreen';

import Dashboard3D from './pages/Dashboard3D';

// Helper to format ISO YYYY-MM-DD
const toDateKey = (date: Date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

// Precise streak calculation utility starting from today/yesterday backwards (safe loop)
const calculateHabitStreak = (completedDays: string[]): number => {
  if (completedDays.length === 0) return 0;
  
  const visited = new Set(completedDays);
  let streakCount = 0;
  const checkDate = new Date(); // Start checking from today
  
  // Guard max iterations to prevent any potential infinite loops
  const maxIterations = Math.max(365, completedDays.length * 2);
  
  // Decide start date based on whether today or yesterday is completed
  const todayKey = toDateKey(checkDate);
  if (visited.has(todayKey)) {
    for (let i = 0; i < maxIterations; i++) {
      const key = toDateKey(checkDate);
      if (visited.has(key)) {
        streakCount++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  } else {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayKey = toDateKey(yesterday);
    if (visited.has(yesterdayKey)) {
      checkDate.setDate(checkDate.getDate() - 1); // Point to yesterday
      for (let i = 0; i < maxIterations; i++) {
        const key = toDateKey(checkDate);
        if (visited.has(key)) {
          streakCount++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      }
    }
  }
  
  return streakCount;
};

// Safe LocalStorage helpers to avoid SecurityError crashes in restricted webview/iframes
const safeGetItem = (key: string): string | null => {
  try {
    return localStorage.getItem(key);
  } catch (e) {
    console.warn(`localStorage read failed for key ${key}:`, e);
    return null;
  }
};

const safeSetItem = (key: string, value: string): void => {
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.warn(`localStorage write failed for key ${key}:`, e);
  }
};

const safeClear = (): void => {
  try {
    localStorage.clear();
  } catch (e) {
    console.warn("localStorage clear failed:", e);
  }
};

// Sanitization utilities to validate tasks and habits structure
const sanitizeTasks = (raw: any): Task[] => {
  if (!Array.isArray(raw)) return [];
  return raw.map(item => {
    if (!item || typeof item !== 'object') return null;
    return {
      id: String(item.id || `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`),
      title: String(item.title || 'Untitled Task'),
      deadline: String(item.deadline || new Date().toISOString().slice(0, 16)),
      importance: (item.importance === 'low' || item.importance === 'medium' || item.importance === 'high') ? item.importance : 'medium',
      duration: typeof item.duration === 'number' && !isNaN(item.duration) ? item.duration : 30,
      completed: Boolean(item.completed),
      completedAt: item.completedAt ? String(item.completedAt) : undefined,
      createdAt: String(item.createdAt || new Date().toISOString()),
      aiPriorityScore: typeof item.aiPriorityScore === 'number' ? item.aiPriorityScore : undefined,
      aiRank: typeof item.aiRank === 'number' ? item.aiRank : undefined,
      aiOptimalTime: item.aiOptimalTime ? String(item.aiOptimalTime) : undefined,
      aiReasoning: item.aiReasoning ? String(item.aiReasoning) : undefined,
      aiCategory: item.aiCategory ? String(item.aiCategory) : undefined,
      subtasks: Array.isArray(item.subtasks) ? item.subtasks : undefined,
      isRescheduled: Boolean(item.isRescheduled)
    } as Task;
  }).filter((t): t is Task => t !== null);
};

const sanitizeHabits = (raw: any): Habit[] => {
  if (!Array.isArray(raw)) return [];
  return raw.map(item => {
    if (!item || typeof item !== 'object') return null;
    const completedDays = Array.isArray(item.completedDays) ? item.completedDays.map(String) : [];
    return {
      id: String(item.id || `habit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`),
      title: String(item.title || 'Untitled Habit'),
      frequency: (item.frequency === 'daily' || item.frequency === 'weekly') ? item.frequency : 'daily',
      createdAt: String(item.createdAt || new Date().toISOString()),
      completedDays,
      streak: typeof item.streak === 'number' && !isNaN(item.streak) ? item.streak : 0,
      bestStreak: typeof item.bestStreak === 'number' && !isNaN(item.bestStreak) ? item.bestStreak : 0,
    } as Habit;
  }).filter((h): h is Habit => h !== null);
};

import BootSequence from './components/BootSequence';
import LogoutSequence from './components/LogoutSequence';

export default function App() {
  const [isBooting, setIsBooting] = useState(true);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [authState, setAuthState] = useState<AuthState>(() => {
    const token = safeGetItem('orbit_token');
    const user = safeGetItem('orbit_user');
    const isOnboardingCompleted = safeGetItem('orbit_onboarding_completed') === 'true';
    if (token && user) {
      return { isAuthenticated: true, token, user: JSON.parse(user), isOnboardingCompleted };
    }
    return { isAuthenticated: false, token: null, user: null, isOnboardingCompleted: false };
  });

  // Auth handlers moved downwards to be able to reset state locally

  // 1. Initial State from localStorage
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = safeGetItem('orbit_tasks');
    let parsed: Task[] | null = null;
    if (saved) {
      try {
        parsed = JSON.parse(saved);
      } catch (e) {
        console.warn("Failed to parse orbit_tasks key, returning defaults:", e);
      }
    }
    
    // If we have saved data (even an empty list), return it directly to avoid forcefully re-inserting default tasks on refresh
    if (parsed && Array.isArray(parsed)) {
      return sanitizeTasks(parsed);
    }

    const defaultTasks: Task[] = [
      {
        id: 'task-investor-presentation',
        title: 'Prepare Investor Presentation',
        deadline: '2026-06-24T17:00', // Tomorrow 5 PM
        importance: 'high',
        duration: 120,
        completed: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'init-task-1',
        title: 'Review executive system overview guidelines',
        deadline: new Date(Date.now() + 1000 * 60 * 60 * 3).toISOString().slice(0, 16), // 3 hours from now
        importance: 'high',
        duration: 45,
        completed: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'init-task-2',
        title: 'Formulate Q2 strategic OKR deliverables',
        deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString().slice(0, 16), // 2 days from now
        importance: 'medium',
        duration: 90,
        completed: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'init-task-3',
        title: 'Clean administrative inbox',
        deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 4).toISOString().slice(0, 16), // 4 days from now
        importance: 'low',
        duration: 15,
        completed: false,
        createdAt: new Date().toISOString(),
      }
    ];

    const tonight = new Date();
    tonight.setHours(21, 0, 0, 0);
    const readTask: Task = {
      id: 'task-read-30-min',
      title: 'Read 30 Minutes',
      deadline: tonight.toISOString().slice(0, 16),
      importance: 'medium',
      duration: 30,
      completed: false,
      createdAt: new Date().toISOString()
    };

    const initialTasks = [readTask, ...defaultTasks];

    const seenIds = new Set<string>();
    const uniqueTasks: Task[] = [];
    for (const t of initialTasks) {
      if (t && t.id && !seenIds.has(t.id)) {
        seenIds.add(t.id);
        uniqueTasks.push(t);
      }
    }

    return sanitizeTasks(uniqueTasks);
  });

  // 1.5 Runtime Tasks Deduplication Guard
  useEffect(() => {
    if (!Array.isArray(tasks)) return;
    const seen = new Set<string>();
    let hasDuplicate = false;
    for (const t of tasks) {
      if (seen.has(t.id)) {
        hasDuplicate = true;
        break;
      }
      seen.add(t.id);
    }
    if (hasDuplicate) {
      const unique: Task[] = [];
      const seenIds = new Set<string>();
      for (const t of tasks) {
        if (!seenIds.has(t.id)) {
          seenIds.add(t.id);
          unique.push(t);
        }
      }
      setTasks(unique);
    }
  }, [tasks]);

  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = safeGetItem('orbit_habits');
    let parsed: Habit[] | null = null;
    if (saved) {
      try {
        parsed = JSON.parse(saved);
      } catch (e) {
        console.warn("Failed to parse orbit_habits key, returning defaults:", e);
      }
    }
    return (parsed && Array.isArray(parsed)) ? sanitizeHabits(parsed) : [
      {
        id: 'init-habit-1',
        title: 'Deep technical reading & skill updates',
        frequency: 'daily',
        createdAt: new Date().toISOString(),
        completedDays: [toDateKey(new Date())], // auto-complete today for demo
        streak: 1,
        bestStreak: 1
      },
      {
        id: 'init-habit-2',
        title: 'Strategic reflection & workout log',
        frequency: 'daily',
        createdAt: new Date().toISOString(),
        completedDays: [],
        streak: 0,
        bestStreak: 3
      }
    ];
  });

  const [dailyDirective, setDailyDirective] = useState<string>(() => {
    return safeGetItem('orbit_directive') || 
      "Initiate prioritization engine alignment to formulate your primary executive action directive.";
  });

  const [isPrioritizing, setIsPrioritizing] = useState(false);
  const [isFallbackMode, setIsFallbackMode] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tasks' | 'habits' | 'reflection' | 'settings' | 'dna' | 'aiCoach'>('dashboard');
  const handleNavigate = (tab: string) => {
    if (tab === 'dashboard' || tab === 'tasks' || tab === 'habits' || tab === 'reflection' || tab === 'settings' || tab === 'dna' || tab === 'aiCoach') {
      setActiveTab(tab);
    }
  };
  const [prioritizeTriggerCount, setPrioritizeTriggerCount] = useState(0);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const [dailyPlan, setDailyPlan] = useState<DailyPlanResponse | null>(() => {
    const saved = safeGetItem('orbit_daily_plan');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [reflections, setReflections] = useState<ReflectionData[]>(() => {
    const saved = safeGetItem('orbit_reflections');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });
  const [isPlanningDay, setIsPlanningDay] = useState(false);
  const [isSyncingCalendar, setIsSyncingCalendar] = useState(false);
  const [isSyncingFit, setIsSyncingFit] = useState(false);
  const [isSyncingMail, setIsSyncingMail] = useState(false);
  const [isFocusMode, setIsFocusMode] = useState(false);

  // Sync emails from Gmail as Tasks
  const handleSyncMail = async () => {
    setIsSyncingMail(true);
    try {
      const response = await apiFetch('/api/mail/sync', { method: 'POST' });
      if (response.status === 401) {
        alert("OAuth token missing. Please reload the applet environment.");
        return;
      }
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to sync mail');
      
      if (data.newTasks && data.newTasks.length > 0) {
        setTasks(prev => {
          const combined = [...data.newTasks, ...prev];
          // deduplicate
          const seen = new Set();
          return combined.filter(t => {
            if (seen.has(t.id)) return false;
            seen.add(t.id);
            return true;
          });
        });
      }
      alert(data.message || `Successfully synced Gmail.`);
    } catch (err: any) {
      console.warn("Mail sync error:", err);
      alert(`Mail Sync Error: ${err.message}`);
    } finally {
      setIsSyncingMail(false);
    }
  };

  // Sync habits to Google Fit
  const handleSyncFit = async () => {
    setIsSyncingFit(true);
    try {
      const response = await apiFetch('/api/fit/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ habits }),
      });
      if (response.status === 401) {
        alert("OAuth token missing. Please reload the applet environment.");
        return;
      }
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to sync');
      
      if (data.updatedHabits) {
        setHabits(prev => prev.map(h => {
          const updated = data.updatedHabits.find((uh: any) => uh.id === h.id);
          if (updated && updated.currentStreak > h.streak) {
            const todayK = toDateKey(new Date());
            const days = h.completedDays.includes(todayK) ? h.completedDays : [...h.completedDays, todayK];
            return {
              ...h,
              streak: updated.currentStreak,
              bestStreak: Math.max(h.bestStreak, updated.currentStreak),
              completedDays: days
            };
          }
          return h;
        }));
      }
      alert(data.message || `Successfully synced with Google Fit.`);
    } catch (err: any) {
      console.warn("Fit sync error:", err);
      alert(`Fit Sync Error: ${err.message}`);
    } finally {
      setIsSyncingFit(false);
    }
  };

  // Sync tasks to Google Calendar
  const handleSyncCalendar = async () => {
    setIsSyncingCalendar(true);
    try {
      const response = await apiFetch('/api/calendar/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks }),
      });
      if (response.status === 401) {
        alert("OAuth token missing. Please reload the applet environment.");
        return;
      }
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to sync');
      alert(`Successfully synced ${data.syncedCount} new upcoming tasks to Google Calendar.`);
    } catch (err: any) {
      console.warn("Calendar sync error:", err);
      alert(`Calendar Sync Error: ${err.message}`);
    } finally {
      setIsSyncingCalendar(false);
    }
  };

  // Loading latch to coordinate state fetching before starting to save/sync back
  const [isInitialLoadDone, setIsInitialLoadDone] = useState(false);
  const [userSettings, setUserSettings] = useState<UserSettings>(() => {
    const saved = safeGetItem('orbit_settings');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      voiceEnabled: true,
      notificationsEnabled: false, // Wait for permission
      reminderFrequency: 'medium',
      morningBriefingEnabled: true,
      eveningReviewEnabled: true,
      voiceSpeed: 1.0,
      voiceVolume: 1.0,
      voiceGender: 'neutral',
    };
  });

  // 1.8 Initial Backend Load and Bootstrap Sync
  useEffect(() => {
    if (!authState.isAuthenticated) {
      setIsInitialLoadDone(true);
      return;
    }
    async function loadData() {
      try {
        const [tasksRes, habitsRes, directiveRes, planRes, reflectionsRes] = await Promise.all([
          apiFetch('/api/tasks').catch(() => null),
          apiFetch('/api/habits').catch(() => null),
          apiFetch('/api/directive').catch(() => null),
          apiFetch('/api/daily-plan').catch(() => null),
          apiFetch('/api/reflection').catch(() => null)
        ]);
        
        if (tasksRes && tasksRes.ok) {
          const contentType = tasksRes.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await tasksRes.json().catch(() => null);
            if (data && data.tasks && Array.isArray(data.tasks)) {
              setTasks(sanitizeTasks(data.tasks));
            }
          }
        }
        if (habitsRes && habitsRes.ok) {
          const contentType = habitsRes.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await habitsRes.json().catch(() => null);
            if (data && data.habits && Array.isArray(data.habits)) {
              setHabits(sanitizeHabits(data.habits));
            }
          }
        }
        if (directiveRes && directiveRes.ok) {
          const contentType = directiveRes.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await directiveRes.json().catch(() => null);
            if (data && data.dailyDirective) {
              setDailyDirective(data.dailyDirective);
            }
          }
        }
        if (planRes && planRes.ok) {
          const contentType = planRes.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await planRes.json().catch(() => null);
            if (data && data.plan) {
              setDailyPlan(data.plan);
            }
          }
        }
        if (reflectionsRes && reflectionsRes.ok) {
          const contentType = reflectionsRes.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            const data = await reflectionsRes.json().catch(() => null);
            if (data && data.reflections && Array.isArray(data.reflections)) {
              setReflections(data.reflections);
            }
          }
        }
      } catch (err) {
        console.warn("Failed to load initial data from server, relying on local state:", err);
      } finally {
        setIsInitialLoadDone(true);
      }
    }
    loadData();
  }, [authState.isAuthenticated]);

  // 2. Synchronize collections to browser localStorage & backend server file DB
  useEffect(() => {
    if (!authState.isAuthenticated || !isInitialLoadDone) return;
    safeSetItem('orbit_tasks', JSON.stringify(tasks));
    
    const timeoutId = setTimeout(() => {
      apiFetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks }),
      }).catch(err => console.warn("Failed to sync tasks to server:", err));
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [tasks, isInitialLoadDone, authState.isAuthenticated]);

  useEffect(() => {
    if (!authState.isAuthenticated || !isInitialLoadDone) return;
    safeSetItem('orbit_habits', JSON.stringify(habits));
    
    const timeoutId = setTimeout(() => {
      apiFetch('/api/habits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ habits }),
      }).catch(err => console.warn("Failed to sync habits to server:", err));
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [habits, isInitialLoadDone, authState.isAuthenticated]);

  useEffect(() => {
    if (!isInitialLoadDone) return;
    safeSetItem('orbit_settings', JSON.stringify(userSettings));
  }, [userSettings, isInitialLoadDone]);

  useEffect(() => {
    if (!authState.isAuthenticated || !isInitialLoadDone) return;
    safeSetItem('orbit_directive', dailyDirective);
    
    const timeoutId = setTimeout(() => {
      apiFetch('/api/directive', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dailyDirective }),
      }).catch(err => console.warn("Failed to sync directive to server:", err));
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [dailyDirective, isInitialLoadDone, authState.isAuthenticated]);

  useEffect(() => {
    if (!isInitialLoadDone) return;
    if (dailyPlan) safeSetItem('orbit_daily_plan', JSON.stringify(dailyPlan));
  }, [dailyPlan, isInitialLoadDone]);

  useEffect(() => {
    if (!isInitialLoadDone) return;
    safeSetItem('orbit_reflections', JSON.stringify(reflections));
  }, [reflections, isInitialLoadDone]);

  // Autonomous Replanning
  const prevDataHash = useRef("");
  useEffect(() => {
    if (!isInitialLoadDone) return;
    
    // Hash based on state that SHOULD trigger a replan
    // Only tasks: id, completed, deadline, duration, importance (NOT ai* fields)
    const activeTasks = tasks.filter(t => !t.completed);
    const hash = JSON.stringify({
      tasks: activeTasks.map(t => ({ id: t.id, d: t.deadline, dur: t.duration, imp: t.importance })),
      habits: habits.map(h => ({ id: h.id, streak: h.streak }))
    });

    if (prevDataHash.current && prevDataHash.current !== hash) {
      if (activeTasks.length > 0) {
        prioritizeTasksWithAI();
      }
    }
    prevDataHash.current = hash;
  }, [tasks, habits, isInitialLoadDone]);

  // 3. Automated Prioritization logic triggering the express proxy GEMINI endpoint
  const prioritizeTasksWithAI = async () => {
    const activeTasks = tasks.filter(t => !t.completed);
    if (activeTasks.length === 0) return;

    setIsPrioritizing(true);
    setIsFallbackMode(false);

    try {
      const response = await apiFetch('/api/prioritize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tasks: activeTasks }),
      });

      if (!response.ok) {
        throw new Error(`API returned status ${response.status}`);
      }

      const data: AIAnalysisResponse & { isFallback?: boolean, fallbackMessage?: string } = await response.json();
      const rankedTasks = Array.isArray(data?.rankedTasks) ? data.rankedTasks : [];

      // Update mapping fields on all active tasks with response priority fields
      setTasks(currentTasks => {
        return currentTasks.map(task => {
          // Find original match
          const matchingAIResult = rankedTasks.find(aiTask => aiTask.id === task.id);
          if (matchingAIResult && !task.completed) {
            return {
              ...task,
              aiPriorityScore: matchingAIResult.priorityScore,
              aiRank: matchingAIResult.rank,
              aiOptimalTime: matchingAIResult.optimalTime,
              aiReasoning: matchingAIResult.reasoning,
              aiCategory: matchingAIResult.category,
              isRescheduled: matchingAIResult.isRescheduled,
            };
          }
          return task;
        });
      });

      setDailyDirective(data.priorityReason || "Focus on the highest leverage task.");
      if (data.isFallback) {
        setIsFallbackMode(true);
      }
      setPrioritizeTriggerCount(prev => prev + 1);
    } catch (err: any) {
      console.warn("Prioritizing Error, resorting to client calculations:", err);
      setIsFallbackMode(true);
      
      // Fallback local calculations in case server fails catastrophically
      setTasks(currentTasks => {
        const sortedActive = currentTasks
          .filter(t => !t.completed)
          .sort((a, b) => {
            const impMap = { high: 3, medium: 2, low: 1 };
            const diff = impMap[b.importance] - impMap[a.importance];
            if (diff !== 0) return diff;
            const dateA = a.deadline ? new Date(a.deadline).getTime() : Infinity;
            const dateB = b.deadline ? new Date(b.deadline).getTime() : Infinity;
            const validA = isNaN(dateA) ? Infinity : dateA;
            const validB = isNaN(dateB) ? Infinity : dateB;
            if (validA === Infinity && validB === Infinity) return 0;
            return validA - validB;
          });

        return currentTasks.map(task => {
          if (task.completed) return task;
          const idx = sortedActive.findIndex(s => s.id === task.id);
          const mult = { high: 90, medium: 60, low: 30 }[task.importance] || 30;
          const score = Math.max(10, Math.min(100, Math.round(mult - idx * 6)));
          
          return {
            ...task,
            aiPriorityScore: score,
            aiRank: idx + 1,
            aiOptimalTime: task.importance === 'high' ? 'First focus morning block' : 'Cognitive mid-afternoon slot',
            aiReasoning: 'Computed via local offline ranking heuristics due to gateway availability constraints.',
            aiCategory: task.duration <= 15 ? 'Quick Win' : 'Operational Focus',
          };
        });
      });

      setDailyDirective("Analyzing timelines with local scheduling engine. Align key benchmarks to optimize performance.");
    } finally {
      setIsPrioritizing(false);
    }
  };

  const planMyDay = async () => {
    setIsPlanningDay(true);
    try {
      const activeTasks = tasks.filter(t => !t.completed);
      const response = await apiFetch('/api/plan-day', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks: activeTasks, habits })
      });
      if (!response.ok) throw new Error("Plan Day API Error");
      const data = await response.json();
      setDailyPlan(data);
    } catch (err) {
      console.warn("Failed to plan day:", err);
      // alert("Failed to plan day via AI");  // Disabled to prevent iframe script errors
    } finally {
      setIsPlanningDay(false);
    }
  };

  const handleBreakDownTask = async (id: string, title: string, description: string) => {
    try {
      const response = await apiFetch('/api/breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description })
      });
      if (!response.ok) throw new Error("Breakdown API Error");
      const resData = await response.json();
      const rawSubtasks = Array.isArray(resData?.subtasks) ? resData.subtasks : [];
      
      setTasks(prev => prev.map(t => {
        if (t.id === id) {
          return {
            ...t,
            subtasks: rawSubtasks.map((st: string, idx: number) => ({
              id: `subtask-${Date.now()}-${idx}`,
              title: st,
              status: 'Pending'
            }))
          };
        }
        return t;
      }));
    } catch(err) {
      console.warn("Failed to breakdown task", err);
    }
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId && t.subtasks) {
        return {
          ...t,
          subtasks: t.subtasks.map(st => 
            st.id === subtaskId ? { ...st, status: st.status === 'Pending' ? 'Completed' : 'Pending' } : st
          )
        };
      }
      return t;
    }));
  };

  const handleCommandResult = (action: string, payload: any): { success: boolean; error?: string; message?: string; payload?: any } => {
    try {
      if (action === "ADD_TASK" && payload && payload.title) {
        console.log("[AgentController] Step 1: Creating task...");
        const newTaskId = `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const newTask: Task = {
          title: payload.title,
          deadline: payload.deadline || new Date().toISOString().slice(0, 16),
          importance: payload.priority || payload.importance || 'medium',
          duration: payload.duration || 30,
          id: newTaskId,
          completed: false,
          createdAt: new Date().toISOString()
        };
        
        setTasks(prev => [...prev, newTask]);
        console.log(`[AgentController] Step 2: Task created with ID ${newTaskId}`);
        console.log("[AgentController] Step 3: Refreshing Task Store...");
        console.log("[AgentController] Step 4: Recalculating Sun Task...");
        console.log("[AgentController] Step 5: Updating Orbit Dashboard...");
        
        setActiveTab('tasks');
        return { success: true, message: `Task '${payload.title}' added successfully.`, payload: newTask };
      } else if (action === "COMPLETE_ALL_TASKS") {
        setTasks(prev => prev.map(t => ({
          ...t,
          completed: true,
          completedAt: new Date().toISOString(),
          aiRank: undefined,
          aiPriorityScore: undefined
        })));
        return { success: true, message: `All tasks have been successfully marked as completed.` };
      } else if (action === "CREATE_REMINDER") {
        return { success: true, message: `Reminder scheduled successfully.` };
      } else if ((action === "ADD_HABIT" || action === "CREATE_HABIT") && payload && payload.title) {
        handleAddHabit({
          title: payload.title,
          frequency: payload.frequency || 'daily'
        });
        setActiveTab('habits');
        return { success: true, message: `Habit '${payload.title}' added.`, payload: { title: payload.title } };
      } else if (action === "COMPLETE_TASK" && payload && payload.id) {
        handleToggleCompleteTask(payload.id);
        return { success: true, message: `Task marked as complete.` };
      } else if (action === "DELETE_TASK" && payload && payload.id) {
        handleDeleteTask(payload.id);
        return { success: true, message: `Task deleted.` };
      } else if (action === "UPDATE_TASK" && payload && payload.id) {
        setTasks(prev => prev.map(t => {
          if (t.id === payload.id) {
            return {
              ...t,
              title: (payload.title && payload.title.trim() !== "") ? payload.title : t.title,
              deadline: payload.deadline !== undefined ? payload.deadline : t.deadline,
              importance: payload.priority !== undefined ? payload.priority : (payload.importance !== undefined ? payload.importance : t.importance),
              duration: payload.duration !== undefined ? payload.duration : t.duration
            };
          }
          return t;
        }));
        return { success: true, message: `Task updated.` };
      } else if (action === "PLAN_DAY") {
        planMyDay();
        return { success: true, message: `Day planning initiated.` };
      } else if (action === "REPRIORITIZE") {
        prioritizeTasksWithAI();
        return { success: true, message: `Reprioritization triggered.` };
      } else if (action === "BREAKDOWN_TASK" && payload && payload.id) {
        const task = tasks.find(t => t.id === payload.id);
        if (task) {
          handleBreakDownTask(task.id, task.title, task.aiReasoning || '');
          return { success: true, message: `Task breakdown initiated.` };
        }
        return { success: false, error: "Task not found for breakdown." };
      } else if (action === "SHOW_PROGRESS") {
        setActiveTab('dashboard');
        return { success: true, message: `Navigated to dashboard.` };
      } else if (action === "FOCUS_NOW") {
        setIsFocusMode(true);
        window.dispatchEvent(new CustomEvent('FOCUS_COMMAND', { detail: { intent: 'FOCUS_NOW' } }));
        return { success: true, message: `Starting focus mode.` };
      } else if (action === "FOCUS_PAUSE") {
        window.dispatchEvent(new CustomEvent('FOCUS_COMMAND', { detail: { intent: 'FOCUS_PAUSE' } }));
        return { success: true, message: `Pausing focus mode.` };
      } else if (action === "FOCUS_RESUME") {
        window.dispatchEvent(new CustomEvent('FOCUS_COMMAND', { detail: { intent: 'FOCUS_RESUME' } }));
        return { success: true, message: `Resuming focus mode.` };
      } else if (action === "FOCUS_END") {
        window.dispatchEvent(new CustomEvent('FOCUS_COMMAND', { detail: { intent: 'FOCUS_END' } }));
        return { success: true, message: `Ending focus mode.` };
      } else if (action === "GET_COACHING") {
        setActiveTab('dashboard');
        return { success: true, message: `Navigated to coach.` };
      } else if (action === "ADD_JOURNAL" && payload && payload.text) {
        const newReflection: ReflectionData = {
          id: `ref-${Date.now()}`,
          date: new Date().toISOString().slice(0, 10),
          completionRate: 100,
          habitConsistency: 100,
          focusScore: 100,
          momentumScore: 100,
          missedWork: 0,
          extraWork: 0,
          dailyReflection: payload.text,
          performanceAnalysis: "Logged via Voice/NL Command.",
          improvementSuggestions: ["Continue with your routine"],
          personalizedCoaching: "Great job capturing your thoughts.",
          positiveReinforcement: "You are making excellent progress.",
          futurePlanningSuggestions: [],
          distractionPatterns: [],
          energyPatterns: [],
          weeklyTrends: "Stable"
        };
        setReflections(prev => [...prev, newReflection]);
        setActiveTab('reflection');
        return { success: true, message: `Journal entry added.` };
      } else if (action === "UNKNOWN") {
        return { success: false, error: "Unknown intent." };
      }
      return { success: false, error: `Unhandled action or missing payload: ${action}` };
    } catch (error: any) {
      console.error("[AgentController] Error:", error);
      return { success: false, error: error.message || String(error) };
    }
  };

  // 4. Task Operations Handlers
  const handleAddTask = (taskData: Omit<Task, 'id' | 'completed' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      completed: false,
      createdAt: new Date().toISOString(),
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleToggleCompleteTask = (id: string) => {
    setTasks(prev => prev.map(task => {
      if (task.id === id) {
        const nextState = !task.completed;
        return {
          ...task,
          completed: nextState,
          completedAt: nextState ? new Date().toISOString() : undefined,
          // Clear priority ranking metrics on completion because they are no longer in active queue
          aiRank: nextState ? undefined : task.aiRank,
          aiPriorityScore: nextState ? undefined : task.aiPriorityScore,
        };
      }
      return task;
    }));
  };

  const handleDeleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
    if (editingTask && editingTask.id === id) {
      setEditingTask(null);
    }
  };

  const handleUpdateTask = (id: string, updatedData: Omit<Task, 'id' | 'completed' | 'createdAt'>) => {
    setTasks(prev => prev.map(task => {
      if (task.id === id) {
        return {
          ...task,
          ...updatedData,
        };
      }
      return task;
    }));
    setEditingTask(null);
  };

  // 5. Habit Operations Handlers
  const handleAddHabit = (habitData: Omit<Habit, 'id' | 'createdAt' | 'completedDays' | 'streak' | 'bestStreak'>) => {
    const newHabit: Habit = {
      ...habitData,
      id: `habit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString(),
      completedDays: [],
      streak: 0,
      bestStreak: 0
    };
    setHabits(prev => [newHabit, ...prev]);
  };

  const handleToggleHabitDay = (habitId: string, dateStr: string) => {
    setHabits(prev => prev.map(habit => {
      if (habit.id === habitId) {
        const alreadyDone = habit.completedDays.includes(dateStr);
        let updatedDays = [...habit.completedDays];
        
        if (alreadyDone) {
          updatedDays = updatedDays.filter(d => d !== dateStr);
        } else {
          updatedDays.push(dateStr);
        }

        const calculatedStreak = calculateHabitStreak(updatedDays);
        const best = Math.max(habit.bestStreak, calculatedStreak);

        return {
          ...habit,
          completedDays: updatedDays,
          streak: calculatedStreak,
          bestStreak: best
        };
      }
      return habit;
    }));
  };

  const handleDeleteHabit = (id: string) => {
    setHabits(prev => prev.filter(habit => habit.id !== id));
  };

  const resetAllAppLogs = () => {
    // Disabled confirm() as it throws in some iframes. Auto resetting.
    safeClear();
    Promise.all([
      apiFetch('/api/tasks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tasks: [] }) }),
      apiFetch('/api/habits', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ habits: [] }) }),
      apiFetch('/api/directive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ dailyDirective: "" }) })
    ]).finally(() => {
        setTasks([]);
        setHabits([]);
        setDailyDirective('');
        setDailyPlan(null);
    });
  };

  const handleLogin = (token: string, user: User, onboardingCompleted?: boolean) => {
    safeSetItem('orbit_token', token);
    safeSetItem('orbit_user', JSON.stringify(user));
    if (onboardingCompleted) {
      safeSetItem('orbit_onboarding_completed', 'true');
    } else {
      localStorage.removeItem('orbit_onboarding_completed');
    }
    setAuthState({ isAuthenticated: true, token, user, isOnboardingCompleted: !!onboardingCompleted });
    setIsInitialLoadDone(false); // Trigger data fetch
  };

  const handleDemoLogin = async () => {
    try {
      const res = await apiFetch('/api/auth/demo', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        safeSetItem('orbit_token', data.token);
        safeSetItem('orbit_user', JSON.stringify(data.user));
        safeSetItem('orbit_onboarding_completed', 'true');
        setAuthState({ isAuthenticated: true, token: data.token, user: data.user, isOnboardingCompleted: true });
        setIsInitialLoadDone(false);
      }
    } catch (e) {}
  };

  const handleOnboardingComplete = (preferences: any) => {
    safeSetItem('orbit_onboarding_completed', 'true');
    setAuthState(prev => ({ ...prev, isOnboardingCompleted: true }));
  };

  const handleLogout = () => {
    setIsLoggingOut(true);
  };

  const executeLogout = () => {
    safeClear();
    setAuthState({ isAuthenticated: false, token: null, user: null, isOnboardingCompleted: false });
    setTasks([]);
    setHabits([]);
    setDailyDirective('');
    setDailyPlan(null);
    setReflections([]);
    setIsInitialLoadDone(false);
    setIsLoggingOut(false);
  };

  const hasPrioritized = tasks.some(t => t.aiPriorityScore !== undefined);

  if (!authState.isAuthenticated) {
    return <AuthScreen onLogin={handleLogin} onDemoLogin={handleDemoLogin} />;
  }

  if (!authState.isOnboardingCompleted) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  if (isLoggingOut) {
    return <LogoutSequence onComplete={executeLogout} />;
  }

  return (
    <div className="relative min-h-screen bg-[#000000] text-[#e0e0e0] flex flex-col font-sans selection:bg-white/10 antialiased overflow-hidden">
      {isBooting && <BootSequence onComplete={() => setIsBooting(false)} />}
      
      <VoiceAssistant 
        tasks={tasks} 
        habits={habits}
        dailyPlan={dailyPlan}
        sunTask={tasks.filter(t => !t.completed && t.aiPriorityScore !== undefined).sort((a,b) => b.aiPriorityScore! - a.aiPriorityScore!)[0] || null}
        onCommandResult={handleCommandResult} 
        hideFloatingButton={true}
        settings={userSettings}
        onUpdateSettings={setUserSettings}
      />
      
      {/* Background 3D Layer Always Active */}
      <div className="absolute inset-0 z-0">
        <Dashboard3D 
          tasks={tasks}
          habits={habits}
          dailyPlan={dailyPlan}
          reflections={reflections}
          userSettings={userSettings}
          onNavigate={handleNavigate}
          onTaskComplete={handleToggleCompleteTask}
          userName={authState.user?.name}
          onStartFocusMode={() => setIsFocusMode(true)}
          activeTab={activeTab}
          isFocusMode={isFocusMode}
          setIsFocusMode={setIsFocusMode}
          onLogout={handleLogout}
          onCommandResult={handleCommandResult}
          productivityScore={dailyPlan?.productivityScore || 78}
        />
      </div>

      {/* Global Focus Mode Overlay */}
      {isFocusMode && (
        <div className="relative z-[100] pointer-events-auto">
          <FocusMode 
            tasks={tasks}
            habits={habits}
            sunTaskId={tasks.filter(t => !t.completed && t.aiPriorityScore !== undefined).sort((a,b) => b.aiPriorityScore! - a.aiPriorityScore!)[0]?.id || null}
            onCompleteTask={handleToggleCompleteTask}
            onExit={() => setIsFocusMode(false)}
            userName={authState.user?.name}
            productivityScore={dailyPlan?.productivityScore || 78}
            activeTab={activeTab}
            setActiveTab={handleNavigate}
            isFocusMode={isFocusMode}
            setIsFocusMode={setIsFocusMode}
            onLogout={handleLogout}
            onCommandResult={handleCommandResult}
          />
        </div>
      )}

      {/* Legacy overlays for specific modules, hidden if 'dashboard' */}
      {activeTab !== 'dashboard' && (
        <div className="relative z-20 flex flex-col h-screen pointer-events-none overflow-hidden bg-black/60 backdrop-blur-[6px]">
          
          {/* Unified High-Fidelity OrbitTopBar Navigation */}
          <OrbitTopBar
            userName={authState.user?.name}
            productivityScore={dailyPlan?.productivityScore || 78}
            activeTab={activeTab}
            setActiveTab={handleNavigate}
            isFocusMode={isFocusMode}
            setIsFocusMode={setIsFocusMode}
            onLogout={handleLogout}
            tasks={tasks}
            habits={habits}
            onCommandResult={handleCommandResult}
          />

      {/* Main Command Console Space */}
      <main className="flex-1 overflow-y-auto pointer-events-auto w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-4">

        {/* Metric Cards Banner */}
        <MetricCards tasks={tasks} habits={habits} />

        {/* Strategic Header & Orbit Prioritizer Controls */}
        <AIHeader
          dailyDirective={dailyDirective}
          isPrioritizing={isPrioritizing}
          isFallbackMode={isFallbackMode}
          onPrioritize={prioritizeTasksWithAI}
          hasTasks={tasks.filter(t => !t.completed).length > 0}
        />

        {/* Dual Column Command Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start pointer-events-none">
          
          {/* LEFT PANEL: Setup Forms */}
          <section className="lg:col-span-4 space-y-4 pointer-events-auto">
            
            {/* AI Command Center */}
            <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 rounded-2xl overflow-hidden">
              <NaturalLanguageCommand onCommandResult={handleCommandResult} tasks={tasks} />
            </div>

            {/* Conditional Display to focus views, or show always on dashboard */}
            {((activeTab as string) === 'dashboard' || activeTab === 'tasks') && (
              <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 p-4 rounded-2xl">
                <TaskForm 
                  onAddTask={handleAddTask} 
                  editingTask={editingTask}
                  onCancelEdit={() => setEditingTask(null)}
                  onUpdateTask={handleUpdateTask}
                />
              </div>
            )}

            {((activeTab as string) === 'dashboard' || activeTab === 'habits') && (
              <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 p-4 rounded-2xl">
                <HabitForm onAddHabit={handleAddHabit} />
              </div>
            )}

            {/* Utility system actions */}
            <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 p-3 rounded-2xl flex items-center justify-between text-[10px] uppercase tracking-wider text-[#bbb] gap-4">
              <span className="font-mono truncate">Cache storage ready</span>
              <div className="flex items-center gap-4 shrink-0">
                <button
                  onClick={handleSyncMail}
                  disabled={isSyncingMail}
                  className="text-yellow-500 hover:text-yellow-400 disabled:opacity-50 hover:underline transition-colors font-mono cursor-pointer"
                >
                  {isSyncingMail ? 'Syncing...' : 'Sync Mail'}
                </button>
                <button
                  onClick={handleSyncFit}
                  disabled={isSyncingFit}
                  className="text-green-500 hover:text-green-400 disabled:opacity-50 hover:underline transition-colors font-mono cursor-pointer"
                >
                  {isSyncingFit ? 'Syncing...' : 'Sync Fit Data'}
                </button>
                <button
                  onClick={handleSyncCalendar}
                  disabled={isSyncingCalendar}
                  className="text-blue-500 hover:text-blue-400 disabled:opacity-50 hover:underline transition-colors font-mono cursor-pointer"
                >
                  {isSyncingCalendar ? 'Syncing...' : 'Sync to Calendar'}
                </button>
                <button
                  onClick={resetAllAppLogs}
                  className="text-red-500 hover:text-red-400 hover:underline transition-colors font-mono cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 rounded-2xl overflow-hidden">
              <AICoachCard tasks={tasks} habits={habits} />
            </div>
          </section>

          {/* RIGHT PANEL: Execution Lists */}
          <section className="lg:col-span-8 space-y-6 pointer-events-auto" id="orbit-execution-logs">
            
            <AnimatePresence mode="wait">
              {((activeTab as string) === 'dashboard') && (
                <motion.div 
                  key="dashboard"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25, ease: "easeInOut" }}
                  className="space-y-6"
                >
                  
                  {hasPrioritized && (
                    <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 rounded-2xl overflow-hidden">
                      <TodaysMission 
                        task={tasks.filter(t => !t.completed && t.aiPriorityScore !== undefined).sort((a,b) => b.aiPriorityScore! - a.aiPriorityScore!)[0]} 
                      />
                    </div>
                  )}
                  
                  <div className="bg-white/5 backdrop-blur-[20px] border border-white/10 p-6 rounded-2xl">
                    <DailyPlanView 
                      plan={dailyPlan} 
                      isPlanningDay={isPlanningDay} 
                      onPlanDay={planMyDay} 
                    />
                  </div>

                  <div className="space-y-6 bg-white/5 backdrop-blur-[20px] border border-white/10 p-6 rounded-2xl">
                    <div className="flex items-center justify-between border-b border-white/10 pb-4">
                      <h2 className="text-xl font-light font-serif italic text-white">Orbit Primary Mission Console</h2>
                      <span className="text-[10px] uppercase font-bold text-white bg-black/50 border border-white/20 px-2.5 py-0.5 rounded font-mono tracking-wider">
                        Sync On
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Task Module preview */}
                      <div className="space-y-3">
                        <TaskList 
                          tasks={tasks}
                          onToggleComplete={handleToggleCompleteTask}
                          onDeleteTask={handleDeleteTask}
                          onEditTask={setEditingTask}
                          onBreakDownTask={handleBreakDownTask}
                          onToggleSubtask={handleToggleSubtask}
                          hasPrioritized={hasPrioritized}
                        />
                      </div>

                      {/* Habits Module preview */}
                      <div className="space-y-3 border-t md:border-t-0 md:border-l border-white/10 md:pl-8 pt-6 md:pt-0">
                        <HabitList 
                          habits={habits}
                          onToggleHabitDay={handleToggleHabitDay}
                          onDeleteHabit={handleDeleteHabit}
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'tasks' && (
                <motion.div 
                  key="tasks-view"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="glass-card p-6 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <ListTodo className="w-5 h-5 text-blue-400" />
                      <h2 className="text-xl font-light font-serif italic text-white">Focus Objective Management</h2>
                    </div>
                    <button 
                      onClick={() => setActiveTab('dashboard')}
                      className="text-cyan-400/75 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
                    >
                      Return to Console
                    </button>
                  </div>

                  <TaskList 
                    tasks={tasks}
                    onToggleComplete={handleToggleCompleteTask}
                    onDeleteTask={handleDeleteTask}
                    onEditTask={setEditingTask}
                    onBreakDownTask={handleBreakDownTask}
                    onToggleSubtask={handleToggleSubtask}
                    hasPrioritized={hasPrioritized}
                  />
                </motion.div>
              )}

              {activeTab === 'habits' && (
                <motion.div 
                  key="habits-view"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="glass-card p-6 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <Activity className="w-5 h-5 text-purple-400" />
                      <h2 className="text-xl font-light font-serif italic text-white">Habit Cycles & Rituals</h2>
                    </div>
                    <button 
                      onClick={() => setActiveTab('dashboard')}
                      className="text-cyan-400/75 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
                    >
                      Return to Console
                    </button>
                  </div>

                  <HabitList 
                    habits={habits}
                    onToggleHabitDay={handleToggleHabitDay}
                    onDeleteHabit={handleDeleteHabit}
                  />
                </motion.div>
              )}

              {activeTab === 'reflection' && (
                <motion.div 
                  key="reflection-view"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="glass-card p-6 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <Brain className="w-5 h-5 text-emerald-400" />
                      <h2 className="text-xl font-light font-serif italic text-white">Strategic Reflection Terminal</h2>
                    </div>
                    <button 
                      onClick={() => setActiveTab('dashboard')}
                      className="text-cyan-400/75 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
                    >
                      Return to Console
                    </button>
                  </div>

                  <ReflectionEngine 
                    tasks={tasks}
                    habits={habits}
                    dailyPlan={dailyPlan}
                    historyReflections={reflections}
                    onSaveReflection={(newRef) => setReflections(prev => [newRef, ...prev])}
                  />
                </motion.div>
              )}

              {activeTab === 'dna' && (
                <motion.div 
                  key="dna-view"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="glass-card p-6 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <Compass className="w-5 h-5 text-cyan-400" />
                      <h2 className="text-xl font-light font-serif italic text-white">Productivity DNA Lab</h2>
                    </div>
                    <button 
                      onClick={() => setActiveTab('dashboard')}
                      className="text-cyan-400/75 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
                    >
                      Return to Console
                    </button>
                  </div>

                  <ProductivityIntelligenceView />
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div 
                  key="settings-view"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="glass-card p-6 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <Settings className="w-5 h-5 text-slate-400" />
                      <h2 className="text-xl font-light font-serif italic text-white">Neural Core Settings</h2>
                    </div>
                    <button 
                      onClick={() => setActiveTab('dashboard')}
                      className="text-cyan-400/75 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
                    >
                      Return to Console
                    </button>
                  </div>

                  <SettingsPanel 
                    settings={userSettings}
                    onUpdate={setUserSettings}
                  />
                </motion.div>
              )}

              {activeTab === 'aiCoach' && (
                <motion.div 
                  key="aiCoach-view"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="glass-card p-6 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-2.5">
                      <Cpu className="w-5 h-5 text-pink-400" />
                      <h2 className="text-xl font-light font-serif italic text-white">AI Neural Coach Advisor</h2>
                    </div>
                    <button 
                      onClick={() => setActiveTab('dashboard')}
                      className="text-cyan-400/75 hover:text-cyan-300 bg-cyan-950/20 hover:bg-cyan-950/40 border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg px-3 py-1.5 text-xs font-mono uppercase tracking-wider transition-all duration-300 cursor-pointer"
                    >
                      Return to Console
                    </button>
                  </div>

                  <AICoachCard tasks={tasks} habits={habits} />
                </motion.div>
              )}
            </AnimatePresence>

          </section>

        </div>
        </div>
      </main>

      <SmartReminderEngine 
        tasks={tasks}
        habits={habits}
        dailyPlan={dailyPlan}
        settings={userSettings}
        reflections={reflections}
      />

      {/* OS Footer */}
      <footer className="pointer-events-auto bg-white/5 backdrop-blur-[20px] border-t border-white/10 text-[#777] py-3 text-center text-[10px] space-y-1 uppercase tracking-widest relative z-10">
        <p className="font-mono text-white/50">ORBIT OS v2.0.0 — INTEGRATED NEURAL CORE PROXY SCHEDULER</p>
        <p className="opacity-40 text-[9px]">Offline consistency backup active &bull; local caching enabled &bull; Spatial UI Active</p>
      </footer>

      <div className="pointer-events-auto">
        <AIHealthMonitor />
      </div>
        </div>
      )}
    </div>
  );
}
