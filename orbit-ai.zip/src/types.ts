export interface Subtask {
  id: string;
  title: string;
  status: 'Pending' | 'Completed';
}

export interface User {
  id: string;
  name: string;
  email: string;
  preferences?: any;
}

export interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  user: User | null;
  isOnboardingCompleted: boolean;
}

export interface Task {
  id: string;
  title: string;
  deadline: string; // ISO connection string (YYYY-MM-DDTHH:mm)
  importance: 'low' | 'medium' | 'high';
  duration: number; // Estimated duration in minutes
  completed: boolean;
  completedAt?: string;
  createdAt: string;

  // AI-generated prioritized fields
  aiPriorityScore?: number;
  aiRank?: number;
  aiOptimalTime?: string;
  aiReasoning?: string;
  aiCategory?: string;

  // New for Phase 4
  subtasks?: Subtask[];
  isRescheduled?: boolean;
}

export interface Habit {
  id: string;
  title: string;
  frequency: 'daily' | 'weekly';
  createdAt: string;
  completedDays: string[]; // Days on which habit was marked completed (YYYY-MM-DD)
  streak: number; // Continuous count of active completions
  bestStreak: number; // Historical peak streak count
}

export interface PrioritizedTaskResult {
  id: string;
  priorityScore: number;
  rank: number;
  optimalTime: string;
  reasoning: string;
  category: string;
  isRescheduled?: boolean;
}

export interface AIAnalysisResponse {
  sunTask: string | null;
  priorityReason: string;
  rankedTasks: PrioritizedTaskResult[];
}

export interface ScheduleEvent {
  id: string;
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  title: string;
  type: 'Task' | 'Habit' | 'Break';
  referenceId?: string; // id of task or habit
}

export interface JournalEntry {
  id: string;
  date: string; // YYYY-MM-DD
  content: string;
}

export interface ReflectionData {
  id: string;
  date: string;
  completionRate: number; // 0-100 (can be > 100)
  habitConsistency: number; // 0-100
  focusScore: number;
  momentumScore: number;
  missedWork: number;
  extraWork: number;
  dailyReflection: string;
  performanceAnalysis: string;
  improvementSuggestions: string[];
  personalizedCoaching: string;
  positiveReinforcement: string;
  futurePlanningSuggestions: string[];
  distractionPatterns: string[];
  energyPatterns: string[];
  weeklyTrends: string;
}

export interface UserSettings {
  voiceEnabled: boolean;
  notificationsEnabled: boolean;
  reminderFrequency: 'high' | 'medium' | 'low';
  morningBriefingEnabled: boolean;
  eveningReviewEnabled: boolean;
  voiceSpeed: number; // 0.5 to 2.0
  voiceVolume: number; // 0.0 to 1.0
  voiceGender: 'male' | 'female' | 'neutral';
}

export interface DailyPlanResponse {
  date: string;
  events: ScheduleEvent[];
  insights: string[];
  productivityScore: number;
  productivityTrend: 'Improving' | 'Stable' | 'Declining';
}

export interface ProductivityDna {
  id: string;
  analysisDate: string;
  bestWorkHours: string;
  productiveDay: string;
  completionRate: number;
  focusScore: number;
  habitScore: number;
  procrastinationScore: number;
  recommendations: string[];
}

export interface JournalInsight {
  id: string;
  journalId: string;
  analysis: string;
  improvements: string[];
  score: number;
  createdAt: string;
}


