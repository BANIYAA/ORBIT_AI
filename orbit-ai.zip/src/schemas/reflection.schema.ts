import { z } from 'zod';
import { taskSchema } from './task.schema';
import { habitSchema } from './habit.schema';

export const reflectionRequestSchema = z.object({
  tasks: z.array(taskSchema).optional(),
  habits: z.array(habitSchema).optional(),
  dailyPlan: z.any().optional(),
  journalEntry: z.string().min(1, "Journal cannot be empty").optional(),
  journal: z.string().min(1, "Journal cannot be empty").optional(),
  mood: z.string().optional(),
  productivityScore: z.number().optional(),
  reflectionDate: z.string().optional()
}).refine(data => (data.journalEntry && data.journalEntry.trim().length > 0) || (data.journal && data.journal.trim().length > 0), {
  message: "Journal cannot be empty",
  path: ["journalEntry"]
});
