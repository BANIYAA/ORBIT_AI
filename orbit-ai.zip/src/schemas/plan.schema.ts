import { z } from 'zod';
import { taskSchema } from './task.schema';
import { habitSchema } from './habit.schema';

export const planRequestSchema = z.object({
  tasks: z.array(taskSchema).min(0),
  habits: z.array(habitSchema).min(0),
  // Additional fields requested by user, even if we don't use them currently
  taskList: z.array(taskSchema).optional(),
  priorities: z.array(z.string()).optional(),
  timeBlocks: z.array(z.any()).optional()
});
