import { z } from 'zod';

export const habitSchema = z.object({
  id: z.string().min(1),
  title: z.string().optional(),
  name: z.string().optional(),
  frequency: z.enum(['daily', 'weekly']),
  createdAt: z.string().optional(),
  completedDays: z.array(z.string()).optional(),
  completedDates: z.array(z.string()).optional(),
  streak: z.number().min(0),
  bestStreak: z.number().min(0).optional(),
}).refine(data => data.title !== undefined || data.name !== undefined, {
  message: "Either title or name must be provided",
  path: ["title"]
});

export const habitListRequestSchema = z.object({
  habits: z.array(habitSchema)
});
