import { z } from 'zod';
import { taskSchema } from './task.schema';
import { habitSchema } from './habit.schema';
import { reflectionRequestSchema } from './reflection.schema';

export const coachRequestSchema = z.object({
  tasks: z.array(taskSchema).min(0),
  habits: z.array(habitSchema).min(0),
  reflections: z.array(z.any()).optional() // User requested reflections validation
});
