import { z } from 'zod';
import { taskSchema } from './task.schema';

export const reminderSchema = z.object({
  taskId: z.string().optional(),
  reminderType: z.enum(['briefing', 'review', 'task_overdue', 'task_upcoming']).optional(),
  reminderTime: z.string().optional(),
});

export const briefingRequestSchema = z.object({
  tasks: z.array(taskSchema),
  dailyPlan: z.any().optional()
});

export const reviewRequestSchema = z.object({
  tasks: z.array(taskSchema),
  habits: z.array(z.any()).optional()
});

export const taskReminderRequestSchema = z.object({
  task: taskSchema,
  isOverdue: z.boolean().optional()
});
