import { z } from 'zod';

export const subtaskSchema = z.object({
  id: z.string(),
  title: z.string(),
  status: z.enum(['Pending', 'Completed'])
});

export const taskSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(3).max(200),
  description: z.string().optional(),
  deadline: z.string().nullable().optional(),
  importance: z.enum(['low', 'medium', 'high', 'critical']).optional(),
  priority: z.enum(['low', 'medium', 'high', 'critical']).optional(),
  duration: z.number().nonnegative().optional(),
  estimatedDuration: z.number().nonnegative().optional(),
  completed: z.boolean(),
  completedAt: z.string().optional(),
  createdAt: z.string(),
  updatedAt: z.string().optional(),
  aiPriorityScore: z.number().optional(),
  aiRank: z.number().optional(),
  aiOptimalTime: z.string().nullable().optional(),
  aiReasoning: z.string().nullable().optional(),
  aiCategory: z.string().nullable().optional(),
  subtasks: z.array(subtaskSchema).nullable().optional(),
  isRescheduled: z.boolean().nullable().optional(),
});

export const taskListRequestSchema = z.object({
  tasks: z.array(taskSchema)
});
