import dotenv from "dotenv";
dotenv.config();

export async function generateOpenRouterResponse(
  model: string,
  prompt: string,
  schema?: any
): Promise<string> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": process.env.APP_URL || "http://localhost:3000",
      "X-Title": "Orbit AI"
    },
    body: JSON.stringify({
      model: model,
      messages: [{ role: "user", content: prompt }],
      response_format: schema ? { type: "json_object" } : undefined
    })
  });

  if (!response.ok) {
    let errMessage = `OpenRouter API error: ${response.status}`;
    try {
        const errorData = await response.json();
        if (errorData.error && errorData.error.message) {
            errMessage += ` - ${errorData.error.message}`;
        }
    } catch(e) {}
    throw new Error(errMessage);
  }

  const data = await response.json();
  if (data.choices && data.choices.length > 0) {
    return data.choices[0].message.content;
  }
  throw new Error("Invalid response from OpenRouter");
}

export async function testOpenRouterConnection(): Promise<{ healthy: boolean, latency: number }> {
    const start = Date.now();
    try {
        await generateOpenRouterResponse(
            "openrouter/free", 
            "Respond with a JSON object containing the status: 'OK'. Example: {\"status\": \"OK\"}",
            {
                type: "object",
                properties: { status: { type: "string" } },
                required: ["status"]
            }
        );
        return { healthy: true, latency: Date.now() - start };
    } catch (e) {
        return { healthy: false, latency: Date.now() - start };
    }
}
