import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClientInstance: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClientInstance) {
    const apiKey = process.env.USER_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY is not configured or contains placeholder values. Please check Settings > Secrets.");
    }
    aiClientInstance = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClientInstance;
}

export function getAiClient(): GoogleGenAI {
  return getGeminiClient();
}

export function cleanErrorMessage(err: any): string {
  const rawMsg = err?.message || "";
  try {
    const trimmed = rawMsg.trim();
    if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
      const parsed = JSON.parse(trimmed);
      if (parsed.error && parsed.error.message) {
        return parsed.error.message;
      }
      if (parsed.message) {
        return parsed.message;
      }
    }
  } catch (e) {
    // Fall back to raw message if parsing fails
  }
  return rawMsg;
}

// Wrapper to retry API calls on 503 Service Unavailable or transient errors
export async function retryStreamGenerateContent(requestOptions: any, maxRetries = 3) {
  const ai = getGeminiClient();
  let attempt = 0;
  while (attempt < maxRetries) {
    try {
      return await ai.models.generateContentStream(requestOptions);
    } catch (err: any) {
      attempt++;
      const msg = err.message || "";
      const cleanMsg = cleanErrorMessage(err);
      const isTransient = msg.includes("503") || msg.includes("UNAVAILABLE") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED") || msg.includes("quota") || msg.includes("limit");
      
      if (isTransient) {
        console.log(`[Gemini Service] Transient streaming delay (attempt ${attempt}/${maxRetries}): ${cleanMsg}`);
        
        const hasRetryIn = msg.includes("Please retry in");
        const isDailyLimit = (msg.includes("GenerateRequestsPerDay") || msg.includes("Daily") || msg.includes("per day") || msg.includes("limit: 0")) && !hasRetryIn;
        const isQuotaExceeded = (msg.includes("quota exceeded") || msg.includes("billing") || msg.includes("CREDIT_LIMIT") || msg.includes("quota limit") || msg.includes("exceeded your quota")) && !hasRetryIn;
        
        if (isDailyLimit || isQuotaExceeded) {
          throw err;
        }

        if (attempt >= maxRetries) throw err;

        let waitMs = Math.pow(2, attempt) * 1000;
        const retryMatch = msg.match(/Please retry in (\d+(\.\d+)?)\s*s/i);
        if (retryMatch && retryMatch[1]) {
          const seconds = parseFloat(retryMatch[1]);
          if (seconds > 15) throw err;
          waitMs = Math.ceil(seconds * 1000) + 500;
        }

        await new Promise(res => setTimeout(res, waitMs));
      } else {
        throw err;
      }
    }
  }
  throw new Error("Max retries exceeded");
}
export async function retryGenerateContent(requestOptions: any, maxRetries = 3) {
  const ai = getGeminiClient();
  let attempt = 0;
  while (attempt < maxRetries) {
    try {
      return await ai.models.generateContent(requestOptions);
    } catch (err: any) {
      attempt++;
      const msg = err.message || "";
      const cleanMsg = cleanErrorMessage(err);
      const isTransient = msg.includes("503") || msg.includes("UNAVAILABLE") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED") || msg.includes("quota") || msg.includes("limit");
      
      if (isTransient) {
        console.log(`[Gemini Service] Transient delay (attempt ${attempt}/${maxRetries}): ${cleanMsg}`);
        
        const hasRetryIn = msg.includes("Please retry in");
        const isDailyLimit = (msg.includes("GenerateRequestsPerDay") || msg.includes("Daily") || msg.includes("per day") || msg.includes("limit: 0")) && !hasRetryIn;
        const isQuotaExceeded = (msg.includes("quota exceeded") || msg.includes("billing") || msg.includes("CREDIT_LIMIT") || msg.includes("quota limit") || msg.includes("exceeded your quota")) && !hasRetryIn;
        
        if (isDailyLimit || isQuotaExceeded) {
          throw err;
        }

        if (attempt >= maxRetries) throw err;

        let waitMs = Math.pow(2, attempt) * 1000;
        const retryMatch = msg.match(/Please retry in (\d+(\.\d+)?)\s*s/i);
        if (retryMatch && retryMatch[1]) {
          const seconds = parseFloat(retryMatch[1]);
          if (seconds > 15) throw err;
          waitMs = Math.ceil(seconds * 1000) + 500;
        }

        await new Promise(res => setTimeout(res, waitMs));
      } else {
        throw err;
      }
    }
  }
  throw new Error("Max retries exceeded");
}
