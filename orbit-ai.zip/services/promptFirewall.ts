import { logger } from "./logger";

export interface FirewallReport {
  score: number; // 0 to 100 risk score
  passed: boolean;
  blockedKeywords: string[];
  suggestedAction: "allow" | "sanitize" | "block";
  originalInput: string;
  sanitizedInput: string;
}

const INJECTION_PATTERNS = [
  /ignore\s+all\s+(previous|prior)\s+instructions/i,
  /system\s+override/i,
  /you\s+are\s+now\s+a\s+/i,
  /disregard\s+all\s+(previous|prior)/i,
  /forget\s+(your)?\s+instructions/i,
  /instead\s+of\s+what\s+you\s+were\s+doing/i,
  /jailbreak/i,
  /system\s+prompt/i,
  /reveal\s+(your)?\s+system/i,
  /output\s+the\s+above/i,
  /print\s+the\s+instructions/i,
  /dan\s+mode/i,
  /do\s+anything\s+now/i,
  /roleplay/i,
  /acting\s+as\s+a/i,
  /new\s+rule/i,
  /stop\s+following/i,
  /override\s+personality/i
];

const MALICIOUS_COMMANDS = [
  /drop\s+table/i,
  /delete\s+from/i,
  /rm\s+-rf/i,
  /eval\(/i,
  /exec\(/i,
  /<script>/i,
  /javascript:/i
];

export const PromptFirewall = {
  /**
   * Evaluates input prompts against security rules.
   * Returns a complete FirewallReport containing a risk score.
   */
  auditInput(input: string): FirewallReport {
    if (!input) {
      return {
        score: 0,
        passed: true,
        blockedKeywords: [],
        suggestedAction: "allow",
        originalInput: "",
        sanitizedInput: ""
      };
    }

    let score = 0;
    const blockedKeywords: string[] = [];
    let sanitized = input;

    // 1. Check for prompt injection patterns
    for (const pattern of INJECTION_PATTERNS) {
      if (pattern.test(input)) {
        score += 35;
        const matched = input.match(pattern);
        if (matched) blockedKeywords.push(matched[0]);
      }
    }

    // 2. Check for malicious scripting or SQL commands
    for (const pattern of MALICIOUS_COMMANDS) {
      if (pattern.test(input)) {
        score += 50;
        const matched = input.match(pattern);
        if (matched) blockedKeywords.push(matched[0]);
      }
    }

    // 3. Length checks (excessive size might suggest resource exfiltration or buffer overflow attempts)
    if (input.length > 5000) {
      score += 15;
      blockedKeywords.push("excessive_length");
    }

    // 4. Sanitize HTML tags
    sanitized = sanitized.replace(/<[^>]*>?/gm, '[STRIPPED_TAG]');

    // 5. Redact dangerous keywords from the input if score is medium
    if (score > 0 && score < 70) {
      for (const pattern of INJECTION_PATTERNS) {
        sanitized = sanitized.replace(pattern, "[REDACTED_INJECTION]");
      }
      for (const pattern of MALICIOUS_COMMANDS) {
        sanitized = sanitized.replace(pattern, "[REDACTED_COMMAND]");
      }
    }

    // Determine suggestion action
    let suggestedAction: "allow" | "sanitize" | "block" = "allow";
    if (score >= 70) {
      suggestedAction = "block";
    } else if (score > 0) {
      suggestedAction = "sanitize";
    }

    const report: FirewallReport = {
      score,
      passed: score < 70,
      blockedKeywords,
      suggestedAction,
      originalInput: input,
      sanitizedInput: sanitized
    };

    // Log the firewall outcome
    if (score >= 70) {
      logger.error("AI_ROUTER", `[FIREWALL] BLOCK - Input blocked with high risk score: ${score}`, { blockedKeywords });
    } else if (score > 0) {
      logger.log("AI_ROUTER", `[FIREWALL] SANITIZE - Input sanitized with risk score: ${score}`, { blockedKeywords });
    } else {
      logger.log("AI_ROUTER", `[FIREWALL] PASS - Input verified clean`);
    }

    return report;
  },

  /**
   * Evaluates AI model outputs for leaked security prompts, system prompt fragments, or system keywords.
   */
  auditOutput(output: string): string {
    if (!output) return "";
    
    let sanitized = output;

    // Check for obvious leakage signs
    const leakSignatures = [
      "I am an AI assistant designed to",
      "As an AI,",
      "My system instructions",
      "Under no circumstances will I",
      "Here is the system prompt:",
      "You are Orbit AI, a smart assistant"
    ];

    let leakDetected = false;
    for (const signature of leakSignatures) {
      if (sanitized.includes(signature)) {
        leakDetected = true;
        sanitized = sanitized.replace(signature, "[REDACTED SYSTEM CONTEXT]");
      }
    }

    if (leakDetected) {
      logger.error("AI_ROUTER", "[FIREWALL] OUTPUT LEAK DETECTED and redacted successfully.");
    }

    return sanitized;
  }
};
