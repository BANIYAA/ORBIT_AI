import { Type } from "@google/genai";
import { getAiClient, retryGenerateContent, cleanErrorMessage } from "./geminiService";
import { generateOpenRouterResponse } from "./openRouterService";
import { logger } from "./logger";
import { PromptFirewall } from "./promptFirewall";

export interface AIResponse {
  source: "gemini" | "openrouter" | "mistral" | "rule_engine";
  modelName: string;
  data: any;
  latencyMs?: number;
}

export function extractJSON(text: string): string {
  if (!text) return "";
  
  // 1. Try to see if there is a markdown code block
  const codeBlockRegex = /```(?:json)?\s*([\s\S]*?)\s*```/gi;
  const matches = [...text.matchAll(codeBlockRegex)];
  if (matches.length > 0) {
    return matches[0][1].trim();
  }

  // 2. Find first index of '{' or '[' and last index of '}' or ']'
  const firstBrace = text.indexOf('{');
  const firstBracket = text.indexOf('[');
  
  let startIdx = -1;
  let endChar = '';
  
  if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
    startIdx = firstBrace;
    endChar = '}';
  } else if (firstBracket !== -1) {
    startIdx = firstBracket;
    endChar = ']';
  }
  
  if (startIdx !== -1) {
    const endIdx = text.lastIndexOf(endChar);
    if (endIdx > startIdx) {
      return text.substring(startIdx, endIdx + 1).trim();
    }
  }
  
  return text.trim();
}

// Track AI metrics
export const aiMetrics = {
  requests: 0,
  geminiSuccess: 0,
  openrouterSuccess: 0,
  mistralSuccess: 0,
  ruleEngineFallback: 0,
  totalLatency: 0,
  failures: 0
};

// Simple rule engine parser for NLP
export function parseWithRuleEngine(command: string, context?: any): any {
  const normalized = command.toLowerCase().trim();
  
  // Helper to find task id by fuzzy matching title
  const findTaskId = (titleFragment: string) => {
    if (!context || !context.tasks) return undefined;
    const cleanFrag = titleFragment.replace(/^(the|a|an)\s+/i, '').replace(/\b(task|is|done|finished)\b/gi, '').trim();
    if (!cleanFrag) return undefined;
    
    // Exact match
    const exactMatch = context.tasks.find((t: any) => t.title.toLowerCase() === cleanFrag);
    if (exactMatch) return exactMatch.id;
    
    // Partial match
    const partialMatch = context.tasks.find((t: any) => t.title.toLowerCase().includes(cleanFrag) || cleanFrag.includes(t.title.toLowerCase()));
    if (partialMatch) return partialMatch.id;
    
    // Just find any task if we have words in common
    const words = cleanFrag.split(/\s+/);
    for (const w of words) {
       if (w.length > 2) {
         const wordMatch = context.tasks.find((t: any) => t.title.toLowerCase().includes(w));
         if (wordMatch) return wordMatch.id;
       }
    }
    return undefined;
  };

  // Priority 1: ADD_TASK (Explicit prefix forces creation, bypassing completion logic)
  const isAddTaskPrefix = 
    normalized.startsWith("create task") ||
    normalized.startsWith("add task") ||
    normalized.startsWith("new task") ||
    normalized.startsWith("schedule task") ||
    normalized.startsWith("create a task") ||
    normalized.startsWith("add a task") ||
    normalized.startsWith("schedule a task");

  if (isAddTaskPrefix) {
    let title = normalized
      .replace(/^(create task|add task|new task|schedule task|create a task|add a task|schedule a task)\b/gi, "")
      .trim();
    title = title.replace(/^(a|to|about)\b/gi, "").replace(/^:/, "").trim();
    if (!title) title = "New Task";
    return {
      intent: "ADD_TASK",
      action: { title },
      confidence: 1.0,
      response: `Created task: ${title}`
    };
  }

  // Helper to check if a sentence contains any action validation keywords
  const containsBlockKeywords = 
    normalized.includes("complete") || 
    normalized.includes("finish") || 
    normalized.includes("done") || 
    normalized.includes("mark completed") || 
    normalized.includes("mark done") ||
    normalized.includes("completed");

  // Priority 2: COMPLETE_ALL_TASKS
  const completeAllPhrases = [
    "complete all tasks",
    "complete every task",
    "finish all tasks",
    "finish every task",
    "mark all tasks completed",
    "mark all tasks done",
    "mark everything done",
    "complete today's tasks",
    "finish today's tasks",
    "mark all completed",
    "mark all done",
    "mark every task done",
    "mark every task completed"
  ];
  const isCompleteAll = completeAllPhrases.some(phrase => normalized.includes(phrase)) || 
                        /complete\s+(all\s+tasks|every\s+task|everything|today's\s+tasks)/i.test(normalized) ||
                        /finish\s+(all\s+tasks|every\s+task|everything|today's\s+tasks)/i.test(normalized) ||
                        /mark\s+(all\s+tasks|every\s+task|everything)\s+(completed|done)/i.test(normalized);

  if (isCompleteAll) {
    return {
      intent: "COMPLETE_ALL_TASKS",
      action: {},
      confidence: 1.0,
      response: "I have marked all of today's tasks as completed."
    };
  }

  // Priority 2: COMPLETE_TASK
  if (containsBlockKeywords) {
    let titleFragment = normalized
      .replace(/^(mark|complete|finish|i finished|i completed|i've finished|the|i've|i|mark task|complete task|finish task)\b/gi, "")
      .replace(/\b(is|done|as|complete|finished|completed|task)\b/gi, "")
      .trim();
    
    const id = findTaskId(titleFragment);
    return {
      intent: "COMPLETE_TASK",
      action: { id, title: titleFragment || normalized },
      confidence: id ? 1.0 : 0.85,
      response: id ? `Completed task` : `Which task would you like to mark as complete?`
    };
  }

  // Priority 3: DELETE_TASK
  if (normalized.match(/^(delete|remove|erase|cancel)\b/i)) {
    let titleFragment = normalized.replace(/^(delete|remove|erase|cancel)\b/i, "").replace(/\btask\b/gi, "").trim();
    const id = findTaskId(titleFragment);
    return {
      intent: "DELETE_TASK",
      action: { id, title: titleFragment || normalized },
      confidence: id ? 1.0 : 0.85,
      response: id ? `Deleted task.` : `I couldn't find a task matching "${titleFragment}" to delete.`
    };
  }

  // Priority 5: CREATE_HABIT (or ADD_HABIT)
  if (normalized.match(/^(create|add|start).*habit/i) || normalized.match(/^i want to habituate/i) || normalized.includes("new habit") || normalized.includes("schedule habit")) {
    const title = normalized
      .replace(/^(create|add|start|new|schedule|i want to|habituate)\b/gi, "")
      .replace(/\b(a|new|daily|habit|to)\b/gi, "")
      .replace(/^:/, "")
      .trim();
    if (title) {
      return {
        intent: "CREATE_HABIT",
        action: { title },
        confidence: 1.0,
        response: `Habit created: ${title}`
      };
    }
  }

  // Priority 6: CREATE_REMINDER
  if (normalized.match(/^(create|add|set|new|schedule)?\s*reminder/i) || normalized.includes("remind me") || normalized.match(/^remind\s/i)) {
    const title = normalized
      .replace(/^(create|add|set|new|schedule|remind me to|remind me|remind)\b/gi, "")
      .replace(/\b(a|reminder|to|about)\b/gi, "")
      .replace(/^:/, "")
      .trim();
    if (title) {
      return {
        intent: "CREATE_REMINDER",
        action: { title },
        confidence: 1.0,
        response: `Reminder created: ${title}`
      };
    }
  }

  // Priority 7: ADD_JOURNAL
  if (normalized.match(/^(add a journal entry|log in my journal|write in journal|add entry|journal:|log:|add to journal|write journal|journal entry|log)\b/i) || normalized.startsWith("journal")) {
    const text = normalized
      .replace(/^(add a journal entry|log in my journal|write in journal|add entry|journal:|log:|add to journal|write journal|journal entry|log)\b/gi, "")
      .trim();
    return {
      intent: "ADD_JOURNAL",
      action: { text: text || normalized },
      confidence: 1.0,
      response: "Journal entry added."
    };
  }

  // Priority 8: GET_COACHING
  if (normalized.match(/^(give me some coaching|get coaching|coach me|show insights|productivity insights|insights)\b/i)) {
    return {
      intent: "GET_COACHING",
      action: {},
      confidence: 1.0,
      response: "Here is your coaching and productivity insights."
    };
  }

  // General conversational fallbacks
  if (normalized.match(/^(what should i do next|what is my next priority|what am i behind on|help me prioritize|i don't know what to do)/i)) {
    return { intent: "REPRIORITIZE", action: {}, confidence: 1.0, response: "Here is what you should focus on." };
  }
  if (normalized.match(/^(plan my day|plan my tomorrow)/i)) {
    return { intent: "PLAN_DAY", action: {}, confidence: 1.0, response: "Planning your day." };
  }
  if (normalized.match(/^(show my progress|show my weekly progress)/i)) {
    return { intent: "SHOW_PROGRESS", action: {}, confidence: 1.0, response: "Here is your progress." };
  }
  if (normalized.match(/^(focus mode|start focus|start session)/i)) {
    return { intent: "FOCUS_NOW", action: {}, confidence: 1.0, response: "Starting focus mode." };
  }
  if (normalized.match(/^(pause focus|pause session)/i)) {
    return { intent: "FOCUS_PAUSE", action: {}, confidence: 1.0, response: "Pausing focus mode." };
  }
  if (normalized.match(/^(resume focus|resume session)/i)) {
    return { intent: "FOCUS_RESUME", action: {}, confidence: 1.0, response: "Resuming focus mode." };
  }
  if (normalized.match(/^(end focus|end session|stop focus|stop session)/i)) {
    return { intent: "FOCUS_END", action: {}, confidence: 1.0, response: "Ending focus mode." };
  }

  return null; // Not deterministic
}

let geminiOfflineUntil = 0;
let mistralOfflineUntil = 0;
let openrouterOfflineUntil = 0;

export function resetAiCooldowns() {
  geminiOfflineUntil = 0;
  mistralOfflineUntil = 0;
  openrouterOfflineUntil = 0;
}

export async function routeGenerativeRequest(
  prompt: string, 
  schema: any, 
  fallbackResponse: any
): Promise<AIResponse> {
  const start = Date.now();
  aiMetrics.requests++;

  // Run Prompt Firewall Audit
  const firewallReport = PromptFirewall.auditInput(prompt);
  if (!firewallReport.passed) {
    logger.error("AI_ROUTER", `[FIREWALL] Input blocked or high risk prompt rejected (score ${firewallReport.score}). Routing to local engine fallback.`);
    aiMetrics.ruleEngineFallback++;
    const latencyMs = Date.now() - start;
    logger.recordAiRouter("rule_engine", latencyMs, true);
    return {
      source: "rule_engine",
      modelName: "orbit-local-rule-engine",
      data: fallbackResponse,
      latencyMs
    };
  }

  // Use the sanitized prompt for generation
  const activePrompt = firewallReport.sanitizedInput;

  // 1. Try Primary: Gemini
  if (Date.now() < geminiOfflineUntil) {
    console.log("[Router] Gemini is currently in offline/cooldown mode due to previous rate limits or 503 errors. Skipping to next tier.");
  } else {
    const geminiModels = [
      "gemini-3.1-flash-lite",
      "gemini-2.5-flash",
      "gemini-2.5-flash-lite",
      "gemini-2.0-flash-lite",
      "gemini-1.5-flash"
    ];

    let lastError: any = null;
    let success = false;

    for (const modelName of geminiModels) {
      try {
        console.log(`[Router] Trying Gemini model: ${modelName}`);
        const response = await retryGenerateContent({
          model: modelName,
          contents: activePrompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: schema || undefined
          }
        });
        
        const latencyMs = Date.now() - start;
        if (latencyMs > 10000) {
          console.log(`[Router] Gemini latency high (${modelName}): ${latencyMs}ms`);
        }

        const jsonText = extractJSON(response.text?.trim() || "{}");
        const auditedJsonText = PromptFirewall.auditOutput(jsonText);
        const data = JSON.parse(auditedJsonText);
        // Basic validation
        if (data) {
          aiMetrics.geminiSuccess++;
          aiMetrics.totalLatency += latencyMs;
          logger.recordAiRouter("gemini", latencyMs, true);
          logger.log("AI_ROUTER", `Gemini response success: model ${modelName} in ${latencyMs}ms`);
          return {
            source: "gemini",
            modelName,
            data,
            latencyMs
          };
        }
      } catch (error: any) {
        lastError = error;
        const cleanMsg = cleanErrorMessage(error);
        logger.recordAiRouter("gemini", 0, false, cleanMsg);
        logger.error("AI_ROUTER", `Gemini model ${modelName} failed: ${cleanMsg}`);
        console.warn(`[Router] Gemini model ${modelName} failed: ${cleanMsg}`);
        // If it is a schema validation error (SyntaxError or similar) that is NOT a rate-limit/503/offline error, 
        // we should probably stop or let it log and try next model.
      }
    }

    if (lastError) {
      const errorMsg = lastError.message || "";
      const cleanMsg = cleanErrorMessage(lastError);
      const isRateLimit = errorMsg.includes("429") || errorMsg.includes("quota") || errorMsg.includes("RESOURCE_EXHAUSTED") || errorMsg.includes("limit");
      const hasRetryIn = errorMsg.includes("Please retry in");
      const isQuotaExceeded = (errorMsg.includes("exceeded your current quota") || errorMsg.includes("quota exceeded") || errorMsg.includes("billing") || errorMsg.includes("CREDIT_LIMIT") || errorMsg.includes("quota limit") || errorMsg.includes("exceeded your quota")) && !hasRetryIn;
      const isUnavailable = errorMsg.includes("503") || errorMsg.includes("UNAVAILABLE") || errorMsg.includes("high demand") || errorMsg.includes("temporary") || errorMsg.includes("overloaded");
      const isMissingKey = errorMsg.includes("GEMINI_API_KEY");
      
      if (isRateLimit || isUnavailable || isMissingKey) {
        let cooldownMs = isRateLimit ? 30 * 1000 : 15 * 1000; 
        
        const retryMatch = errorMsg.match(/Please retry in (\d+(\.\d+)?)\s*s/i);
        if (retryMatch && retryMatch[1]) {
          const seconds = parseFloat(retryMatch[1]);
          cooldownMs = Math.ceil(seconds * 1000) + 1500; // 1.5s extra buffer
          console.log(`[Router] Gemini API Rate Limit (429) Transient. Retry match found. Triggering dynamic cooldown of ${seconds}s. Reason: ${cleanMsg}`);
        } else if (isQuotaExceeded) {
          cooldownMs = 15 * 60 * 1000;
          console.log(`[Router] Gemini API Hard Quota / Billing limit reached. Triggering a 15-minute persistent cooldown. Reason: ${cleanMsg}`);
        } else if (isMissingKey) {
          cooldownMs = 5 * 1000; // Only 5s cooldown for missing key so user can add it
          console.log(`[Router] Gemini API Key Missing. Triggering 5s cooldown.`);
        } else {
          console.log(`[Router] Gemini API ${isRateLimit ? 'Rate Limit (429)' : 'Temporary Service Outage (503)'}. Triggering cooldown of ${cooldownMs / 1000}s. Reason: ${cleanMsg}`);
        }
        geminiOfflineUntil = Date.now() + cooldownMs;
      } else {
        console.log("[Router] Primary (Gemini) All Models Failed:", errorMsg, lastError);
      }
      aiMetrics.failures++;
    }
  }

  // 2. Try Secondary: OpenRouter
  if (Date.now() < openrouterOfflineUntil) {
    console.log("[Router] OpenRouter is currently in offline/cooldown mode. Skipping to next tier.");
  } else {
      try {
          if (process.env.OPENROUTER_API_KEY) {
              // Retry loop for OpenRouter
              let attempt = 0;
              let content = "";
              while (attempt < 3) {
                  try {
                      content = await generateOpenRouterResponse(
                          "openrouter/free", 
                          schema ? `${activePrompt}\n\nExpected JSON Schema:\n${JSON.stringify(schema, null, 2)}` : activePrompt, 
                          schema
                      );
                      break;
                  } catch (e: any) {
                      attempt++;
                      const msg = e.message || "";
                      const isTransient = msg.includes("429") || msg.includes("503") || msg.includes("504") || msg.includes("timeout") || msg.includes("limit");
                      if (attempt >= 3 || !isTransient) {
                          throw e;
                      }
                      await new Promise(r => setTimeout(r, Math.pow(2, attempt-1) * 1000));
                  }
              }

              const jsonText = extractJSON(content);
              const auditedJsonText = PromptFirewall.auditOutput(jsonText);
              const data = JSON.parse(auditedJsonText);
              if (data) {
                  const latencyMs = Date.now() - start;
                  aiMetrics.openrouterSuccess++;
                  aiMetrics.totalLatency += latencyMs;
                  logger.recordAiRouter("openrouter", latencyMs, true);
                  logger.log("AI_ROUTER", `OpenRouter response success in ${latencyMs}ms`);
                  return {
                      source: "openrouter",
                      modelName: "openrouter/free",
                      data,
                      latencyMs
                  };
              }
          } else {
              console.log("[Router] Secondary (OpenRouter) skipped (no API key).");
          }
      } catch (error: any) {
          console.log("[Router] Secondary (OpenRouter) Failed:", error.message);
          aiMetrics.failures++;
          logger.recordAiRouter("openrouter", 0, false, error.message);
          logger.error("AI_ROUTER", `OpenRouter failed: ${error.message}`);
          if (error.message.includes("429") || error.message.includes("503")) {
              openrouterOfflineUntil = Date.now() + 60 * 1000;
          }
      }
  }

  // 3. Try Tertiary: Mistral
  if (Date.now() < mistralOfflineUntil) {
    console.log("[Router] Mistral is currently in offline/cooldown mode due to previous rate limits. Skipping to local rule engine.");
  } else {
    try {
      const mistralKey = process.env.MISTRAL_API_KEY;
      if (mistralKey) {
        let attempt = 0;
        let content = "";
        while(attempt < 3) {
          try {
            const mistralRes = await fetch("https://api.mistral.ai/v1/chat/completions", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${mistralKey}`
              },
              body: JSON.stringify({
                model: "mistral-large-latest",
                response_format: { type: "json_object" },
                messages: [
                  { role: "system", content: "You must return JSON ONLY. No markdown formatting. Adhere to the provided JSON schema." },
                  { role: "user", content: schema ? `${activePrompt}\n\nExpected JSON Schema:\n${JSON.stringify(schema, null, 2)}` : activePrompt }
                ]
              })
            });
            
            if (!mistralRes.ok) {
              const errorText = await mistralRes.text();
              if (mistralRes.status === 429) {
                console.warn("[Router] Mistral API Rate Limit (429) reached. Triggering 5-minute cooldown.");
                mistralOfflineUntil = Date.now() + 5 * 60 * 1000;
              }
              throw new Error(`Mistral API Error: ${mistralRes.statusText} - ${errorText}`);
            }
            const data = await mistralRes.json();
            content = data.choices[0].message.content;
            break;
          } catch(e: any) {
            attempt++;
            const msg = e.message || "";
            const isTransient = msg.includes("429") || msg.includes("503") || msg.includes("504") || msg.includes("timeout");
            if (attempt >= 3 || !isTransient) {
               throw e;
            }
            await new Promise(r => setTimeout(r, Math.pow(2, attempt-1) * 1000));
          }
        }
        
        const jsonText = extractJSON(content);
        const auditedJsonText = PromptFirewall.auditOutput(jsonText);
        const data = JSON.parse(auditedJsonText);
        if (data) {
          const latencyMs = Date.now() - start;
          aiMetrics.mistralSuccess++;
          aiMetrics.totalLatency += latencyMs;
          logger.recordAiRouter("mistral", latencyMs, true);
          logger.log("AI_ROUTER", `Mistral response success in ${latencyMs}ms`);
          
          return {
            source: "mistral",
            modelName: "mistral-large-latest",
            data,
            latencyMs
          };
        }
      } else {
        console.log("[Router] Tertiary (Mistral) skipped (no API key).");
      }
    } catch (error: any) {
      console.log("[Router] Tertiary (Mistral) Failed:", error.message);
      aiMetrics.failures++;
      logger.recordAiRouter("mistral", 0, false, error.message);
      logger.error("AI_ROUTER", `Mistral failed: ${error.message}`);
    }
  }

  // 4. Fallback: Rule Engine / Default Fallback
  console.log("[Router] All AI models failed. Using Offline Rule Engine.");
  aiMetrics.ruleEngineFallback++;
  const latencyMs = Date.now() - start;
  aiMetrics.totalLatency += latencyMs;
  logger.recordAiRouter("rule_engine", latencyMs, true);
  logger.log("AI_ROUTER", `Offline local rule engine fallback triggered in ${latencyMs}ms`);
  
  return {
    source: "rule_engine",
    modelName: "orbit-local-rule-engine",
    data: fallbackResponse,
    latencyMs
  };
}
