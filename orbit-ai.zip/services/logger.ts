// Structured Logger and Observability Registry
export interface LogMetrics {
  auth: {
    loginSuccess: number;
    loginFailure: number;
    sessionExpired: number;
    logout: number;
    tokenRefresh: number;
  };
  api: {
    requestVolume: number;
    failureCount: number;
    requests: Record<string, { count: number; totalTimeMs: number; lastStatus: number }>;
  };
  database: {
    queryCount: number;
    writeCount: number;
    slowQueries: number;
    failedQueries: number;
    totalTimeMs: number;
  };
  aiRouter: {
    requests: number;
    selectedProvider: Record<string, number>;
    fallbackCount: number;
    failures: number;
    latencySumMs: number;
    quotaErrors: number;
    errors: string[];
  };
}

export const metricsRegistry: LogMetrics = {
  auth: {
    loginSuccess: 0,
    loginFailure: 0,
    sessionExpired: 0,
    logout: 0,
    tokenRefresh: 0
  },
  api: {
    requestVolume: 0,
    failureCount: 0,
    requests: {}
  },
  database: {
    queryCount: 0,
    writeCount: 0,
    slowQueries: 0,
    failedQueries: 0,
    totalTimeMs: 0
  },
  aiRouter: {
    requests: 0,
    selectedProvider: {
      gemini: 0,
      openrouter: 0,
      mistral: 0,
      rule_engine: 0
    },
    fallbackCount: 0,
    failures: 0,
    latencySumMs: 0,
    quotaErrors: 0,
    errors: []
  }
};

type LogTag = "AUTH" | "API" | "DATABASE" | "AI_ROUTER" | "VOICE" | "DNA" | "STARTUP";

export const logger = {
  log(tag: LogTag, message: string, meta?: any) {
    const timestamp = new Date().toISOString();
    const metaStr = meta ? ` | Meta: ${JSON.stringify(meta)}` : "";
    console.log(`[${timestamp}] [${tag}] ${message}${metaStr}`);
  },
  
  error(tag: LogTag, message: string, error?: any) {
    const timestamp = new Date().toISOString();
    const errorDetails = error ? ` | Error: ${error.message || error}` : "";
    console.error(`[${timestamp}] [${tag}] ❌ ERROR: ${message}${errorDetails}`);
  },

  // Helpers to register events
  recordAuth(event: keyof LogMetrics["auth"]) {
    metricsRegistry.auth[event]++;
    this.log("AUTH", `Auth event recorded: ${event}`);
  },

  recordApi(path: string, status: number, durationMs: number) {
    metricsRegistry.api.requestVolume++;
    if (status >= 400) {
      metricsRegistry.api.failureCount++;
    }
    if (!metricsRegistry.api.requests[path]) {
      metricsRegistry.api.requests[path] = { count: 0, totalTimeMs: 0, lastStatus: status };
    }
    metricsRegistry.api.requests[path].count++;
    metricsRegistry.api.requests[path].totalTimeMs += durationMs;
    metricsRegistry.api.requests[path].lastStatus = status;

    this.log("API", `HTTP ${status} - ${path} (${durationMs}ms)`);
  },

  recordDatabase(type: "query" | "write", durationMs: number, success: boolean = true) {
    if (type === "query") {
      metricsRegistry.database.queryCount++;
    } else {
      metricsRegistry.database.writeCount++;
    }

    if (!success) {
      metricsRegistry.database.failedQueries++;
    }

    metricsRegistry.database.totalTimeMs += durationMs;
    if (durationMs > 200) {
      metricsRegistry.database.slowQueries++;
      this.log("DATABASE", `Slow query detected (${durationMs}ms)`);
    }
  },

  recordAiRouter(provider: "gemini" | "openrouter" | "mistral" | "rule_engine", latencyMs: number, success: boolean, errorMsg?: string) {
    metricsRegistry.aiRouter.requests++;
    if (success) {
      metricsRegistry.aiRouter.selectedProvider[provider]++;
      metricsRegistry.aiRouter.latencySumMs += latencyMs;
    } else {
      metricsRegistry.aiRouter.failures++;
      if (errorMsg) {
        metricsRegistry.aiRouter.errors.push(errorMsg);
        if (errorMsg.toLowerCase().includes("quota") || errorMsg.toLowerCase().includes("429") || errorMsg.toLowerCase().includes("limit")) {
          metricsRegistry.aiRouter.quotaErrors++;
        }
      }
    }
  }
};
